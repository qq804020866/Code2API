import numpy as np
import pandas as pd

def add_empty_column_to_dataframe(df, column_name):
    df[column_name] = ""
    return df
