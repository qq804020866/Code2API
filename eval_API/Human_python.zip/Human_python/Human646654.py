def get_last_items_in_list(lst, n):
    return a[-n:]
