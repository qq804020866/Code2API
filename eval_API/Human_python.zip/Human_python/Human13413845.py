import pandas as pd

def drop_nan_rows(df,column_name):
    df = df[df[column_name].notna()]
    return df
