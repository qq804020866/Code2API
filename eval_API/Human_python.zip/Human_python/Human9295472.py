from numpy import random
import matplotlib.pyplot as plt

def remove_default element_and_save_image(data, outputname):
    img = plt.imshow(data, interpolation='nearest')
    img.set_cmap('hot')
    plt.axis('off')
    plt.savefig(outputname, bbox_inches='tight')
