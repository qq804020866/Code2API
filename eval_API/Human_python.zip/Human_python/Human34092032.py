import pandas as pd

def add_header_to_dataframe(file_path, sep, col_names):
    Cov = pd.read_csv(file_path, sep=sep, names=col_names)
    return Cov
