def append_values_to_list(lst, single_values=None, multiple_values=None):
    if single_values:
        for value in single_values:
            lst.append(value)
    if multiple_values:
        for values in multiple_values:
            lst.extend(values)
    return lst