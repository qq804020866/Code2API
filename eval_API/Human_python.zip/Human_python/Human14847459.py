import numpy as np

def get_matrix_dimensions(A):
    return A.shape
