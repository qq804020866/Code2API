from numpy import genfromtxt

def read_csv_into_numpy_array(file_path):
    my_data = genfromtxt(file_path, delimiter=',')
    return my_data
