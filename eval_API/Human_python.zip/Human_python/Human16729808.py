import pandas as pd

def get_value_from_dataframe_cell(df, column_name):
    return df.iloc[0][column_name]
