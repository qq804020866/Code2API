import numpy

def calculate_euclidean_distance_with_numpy(a, b):
    dist = numpy.linalg.norm(a-b)
    return dist
