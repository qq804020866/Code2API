def check_if_list_empty(lst):
    if not lst:
        return True
    else:
        return False
