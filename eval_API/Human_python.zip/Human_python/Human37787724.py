import pandas as pd

def sort_pd_dataframe_by_column(df, column_name):
    df.sort_values(column_name)
    return df
