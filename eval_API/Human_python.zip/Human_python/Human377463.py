from time import sleep

def sleep_for_milliseconds(milliseconds):
    sleep(milliseconds / 1000)
