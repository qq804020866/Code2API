def check_if_int(userInput):
    try:
        val = int(userInput)
        return True
    except ValueError:
        print("That's not an int!")
        return False
