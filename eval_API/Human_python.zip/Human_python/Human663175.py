def get_substring(s, start, end):
    return s[start:end]
