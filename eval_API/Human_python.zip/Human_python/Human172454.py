def split_multiline_string(inputString):
    return inputString.splitlines()
