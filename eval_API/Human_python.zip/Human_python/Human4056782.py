def create_zero_array(size):
    a = [0] * size
    return a
