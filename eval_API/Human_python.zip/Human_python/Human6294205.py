def find_all_occurrences_indices(my_list, element):
    indices = [i for i, x in enumerate(my_list) if x == element]
    return indices
