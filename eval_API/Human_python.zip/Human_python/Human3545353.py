def print_dict_keys_values(mydictionary):
    for key in mydictionary:
        print "key: %s , value: %s" % (key, mydictionary[key])
