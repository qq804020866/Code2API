def extract_positive integers_from_string(s):
    return [int(sub_s) for sub_s in s.split() if sub_s.isdigit()]
