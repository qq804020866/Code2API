import math

def isnan(x):
    return math.isnan(x)
