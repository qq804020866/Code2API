import pandas as pd

def set_index_name(df, new_index_name):
    df.index.name = new_index_name
    return df
