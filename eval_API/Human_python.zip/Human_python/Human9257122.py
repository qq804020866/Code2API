def uppercase_string(s):
    return s.upper()
