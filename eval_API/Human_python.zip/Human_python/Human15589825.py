import cv2

def crop_image(img_path, x, y, h, w):
    img = cv2.imread(img_path)
    crop_img = img[y:y+h, x:x+w]
    cv2.imshow("cropped", crop_img)
    cv2.waitKey(0)
    return crop_img
