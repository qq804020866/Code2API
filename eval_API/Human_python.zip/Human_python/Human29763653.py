import pandas as pd

def select_all_columns_except_one(df, col):
    return df.loc[:, df.columns != col]
