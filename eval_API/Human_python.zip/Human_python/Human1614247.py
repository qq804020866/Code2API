def convert_list_items_to_float(lst):
    return [float(i) for i in lst]
