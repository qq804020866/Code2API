import pandas as pd
import numpy as np

def create_pd_dataframe_from_numpy(data):
    df = pd.DataFrame(data=data[1:,1:],    # values
                      index=data[1:,0],    # 1st column as index
                      columns=data[0,1:])  # 1st row as the column names
    return df
