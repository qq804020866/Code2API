def format_float_with_two_decimal(num):
    return '%.2f' % num
