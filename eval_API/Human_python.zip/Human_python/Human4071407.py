def split_and_strip_string(s, sep):
    result = [x.strip() for x in s.split(sep)]
    return result
