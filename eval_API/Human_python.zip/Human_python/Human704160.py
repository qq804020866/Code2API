def convert_char_int_each_other(input):
    if type(input) == str:
        return ord(input)
    if type(input) == int:
        return chr(input)

