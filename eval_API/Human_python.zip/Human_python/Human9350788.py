import os

def get_script_dir():
    return os.path.dirname(os.path.realpath(__file__))
