def get_weekday_of_date(date):
    return date.weekday()
