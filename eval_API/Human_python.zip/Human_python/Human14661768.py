import pandas as pd

def drop_rows(df, index_list):
    df = df.drop(index=index_list)
    return df
