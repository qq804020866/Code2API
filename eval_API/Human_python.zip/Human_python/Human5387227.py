def convert_string_to_list(string, sep):
    str_lst= string.split(sep)
    return str_lst
