def string_to_binary(s):
    return ' '.join(format(ord(x), 'b') for x in s)
