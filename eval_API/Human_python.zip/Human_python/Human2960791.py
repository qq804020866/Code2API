import matplotlib.pyplot as plot

def save_plot_with_num(num):
    plot.savefig('%d.pdf' % num)
