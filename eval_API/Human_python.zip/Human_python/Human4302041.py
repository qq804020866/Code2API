import webbrowser

def open_url_in_browser(url):
    return webbrowser.open(url)
