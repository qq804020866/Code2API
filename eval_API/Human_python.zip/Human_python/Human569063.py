import numpy as np

def create_and_fill_array(shape, rows):
    a = np.zeros(shape=shape)
    for i, row in enumerate(rows):
        a[i] = value
    return a
