def check_key_in_dict(key, dictionary):
    return key in dictionary
