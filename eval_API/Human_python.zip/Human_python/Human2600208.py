def count_list_item(lst, item):
    return lst.count(item)
