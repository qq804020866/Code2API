def fill_string_with_spaces(s, width):
    return s.ljust(width)
