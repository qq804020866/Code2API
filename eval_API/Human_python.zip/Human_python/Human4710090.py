def delete_specific_line(file_name, line_to_delete):
    with open(file_name, "r") as f:
        lines = f.readlines()
    with open(file_name, "w") as f:
        for line in lines:
            if line.strip("\n") != line_to_delete:
                f.write(line)
