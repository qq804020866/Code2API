def check_string_contains_element_from_list(s, lst):
    if any(i in s for i in lst):
        return True
    else:
        return False
