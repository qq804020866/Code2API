def split_string_into_list(s):
    lst= s.split()
    return lst
