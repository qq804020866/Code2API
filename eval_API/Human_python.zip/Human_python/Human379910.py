def parse_string_to_float_and_int(s):
    float_val = float(s)
    int_val = int(float_val)
    return float_val, int_val
