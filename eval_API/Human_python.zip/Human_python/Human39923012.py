import pandas as pd

def group_by_sum(df,col1,col2):
    return df.groupby([col1,col2]).sum()
