def read_large_file_line_by_line(file_path):
    with open(file_path) as f:
        for line in f:
            # Do something with 'line'
            pass
