import os

def create_folder(newpath):
    if not os.path.exists(newpath):
        os.makedirs(newpath)
