def make_dict_from_lists(keys, values):
    dictionary = dict(zip(keys, values))
    return dictionary
