def convert_int_to_hex(num):
    hex_str = hex(num)
    return hex_str
