def print_dataframe_columns(df):
    for column in df:
        print(df[column])
