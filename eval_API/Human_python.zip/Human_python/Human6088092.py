import random

def get_random_float(a, b):
    return random.uniform(a, b)
