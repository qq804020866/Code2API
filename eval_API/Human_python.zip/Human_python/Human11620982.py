import numpy

def remove_nan_values_from_nparray(x):
    x = x[~numpy.isnan(x)]
    return x
