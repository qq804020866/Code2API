import os
import shutil

def move_file(source_path, destination_path):
    os.rename(source_path, destination_path)
    os.replace(source_path, destination_path)
    shutil.move(source_path, destination_path)
