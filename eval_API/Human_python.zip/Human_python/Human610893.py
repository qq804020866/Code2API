def check_object_has_attribute(obj, attr):
    if hasattr(obj, attr):
        return getattr(obj, attr_name)
    return None
