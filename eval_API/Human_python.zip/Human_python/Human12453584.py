def concatenate_list_to_string(lst, delimiter):
    return delimiter.join(lst)
