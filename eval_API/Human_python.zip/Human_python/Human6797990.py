def lowercase_string(s):
    return s.lower()
