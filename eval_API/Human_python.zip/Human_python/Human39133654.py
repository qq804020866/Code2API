import matplotlib.pyplot as plt

def add_titles_to_subplots(title1, title2, title3, title4):
    fig = plt.figure()
    ax1 = fig.add_subplot(221)
    ax2 = fig.add_subplot(222)
    ax3 = fig.add_subplot(223)
    ax4 = fig.add_subplot(224)
    ax1.title.set_text(title1)
    ax2.title.set_text(title2)
    ax3.title.set_text(title3)
    ax4.title.set_text(title4)
    plt.show()
