def get_list_length(lst):
    return len(lst)
