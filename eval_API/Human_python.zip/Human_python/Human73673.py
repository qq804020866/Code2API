import sys

def terminate_script(arg=0):
    sys.exit(arg)
