def count_equal_pairs(x, y):
    shared_items = {k: x[k] for k in x if k in y and x[k] == y[k]}
    return len(shared_items)
