def check_none(variable):
    if variable is None:
        return True
    else:
        return False
