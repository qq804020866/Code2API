import sys
import numpy

def print_full_numpy_array():
    numpy.set_printoptions(threshold=sys.maxsize)
