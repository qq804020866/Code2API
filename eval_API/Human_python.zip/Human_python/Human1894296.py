import ast

def convert_str_to_list(str_list):
    x = ast.literal_eval(str_list)
    x = [n.strip() for n in x]
    return x
