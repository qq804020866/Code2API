import psutil

def get_cpu_ram_info():
    cpu_usage = psutil.cpu_percent()
    virtual_memory = psutil.virtual_memory()
    memory_dict = dict(virtual_memory._asdict())
    percent_used_ram = virtual_memory.percent
    percent_available_memory = virtual_memory.available * 100 / virtual_memory.total

    return {
        'cpu_usage': cpu_usage,
        'virtual_memory': memory_dict,
        'percent_used_ram': percent_used_ram,
        'percent_available_memory': percent_available_memory
    }
