def get_values_from_dict(d):
    return list(d.values())
