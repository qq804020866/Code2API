def add_key_to_dict(d, new_key, new_value):
    d[new_key] = new_value
    return d
