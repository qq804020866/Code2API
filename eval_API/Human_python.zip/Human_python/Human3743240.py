import datetime

def convert_datetime_to_date(dt):
    return dt.date()
