from dateutil import parser

def parse_iso8601_date(datestring):
    yourdate = parser.parse(datestring)
    return yourdate
