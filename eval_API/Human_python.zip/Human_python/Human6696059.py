def split_elements_in_list(lst, sub_string):
    return [i.split(sub_string, 1)[0] for i in lst]
