import pandas as pd

def print_specific_row(df, index):
    print(df.loc[[index]])
