def round_to_two_decimals(number):
    return str(round(number, 2))
