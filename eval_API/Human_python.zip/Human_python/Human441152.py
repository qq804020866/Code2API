from datetime import datetime, timedelta

def subtract_day_from_date(day_to_subtract):
    d = datetime.today() - timedelta(days=day_to_subtract)
    return d
