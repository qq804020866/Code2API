def check_items_in_list(items, lst):
    result = [i for i in items if i in lst]
    return result
