def append_to_file(file_name, text_to_append):
    with open(file_name, "a") as f:
        f.write(text_to_append)