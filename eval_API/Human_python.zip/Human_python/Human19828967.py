import pandas as pd

def check_if_dataframe_empty(df):
    if df.empty:
        return True
    else:
        return False
