import time

def convert_local_time_to_utc(local_time_str):
    utc_time_str = time.strftime("%Y-%m-%d %H:%M:%S", 
                                 time.gmtime(time.mktime(time.strptime(local_time_str, 
                                                                       "%Y-%m-%d %H:%M:%S"))))
    return utc_time_str
