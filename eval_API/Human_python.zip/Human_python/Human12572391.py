def get_string_after_substring(string, sub_string):
    return string.split(sub_string, 1)[1]
