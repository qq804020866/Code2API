import os

def set_working_directory(path):
    os.chdir(path)
