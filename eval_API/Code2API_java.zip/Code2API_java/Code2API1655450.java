package com.code2api.api;
import java.util.Calendar;

public class Code2API1655450 {
    public static Date getFutureTime() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.SECOND, 5);
        return calendar.getTime();
    }
}
