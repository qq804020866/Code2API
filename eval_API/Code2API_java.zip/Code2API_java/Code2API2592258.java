package com.code2api.api;
import javax.swing.UIManager;

public class Code2API2592258 {
    public static void improveLookAndFeel() throws Exception {
        try { 
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
