package com.code2api.api;
public class Code2API2538803 {
    public static void printFloatWithTwoDecimalPlaces(float value) {
        System.out.printf("%.2f", value);
    }
}
