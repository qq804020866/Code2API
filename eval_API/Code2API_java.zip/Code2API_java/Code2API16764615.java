package com.code2api.api;
public class Code2API16764615 {
    public static void checkStringStartAndEndsWithDoubleQuotes(String str) {
        if (str.matches("\".*\"")) {
            // this string starts and end with a double quote
        }
    }
}
