package com.code2api.api;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class Code2API36652931 {
    public static void fixDisabledButtonColor(JButton button, ImageIcon icon) {
        button.setDisabledIcon(icon);
    }
}
