package com.code2api.api;
import java.net.*;
import java.io.*;

public class Code2API3871163 {
    public static String convertDataInputStreamToString(DataInputStream dis) throws MalformedURLException, IOException {
        StringBuffer inputLine = new StringBuffer();
        String tmp; 
        while ((tmp = dis.readLine()) != null) {
            inputLine.append(tmp);
            System.out.println(tmp);
        }
        dis.close();
        return inputLine.toString();
    }
}
