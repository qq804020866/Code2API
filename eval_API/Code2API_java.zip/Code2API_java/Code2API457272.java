package com.code2api.api;
public class Code2API457272 {
    public static void clearSoftReferences() {
        Object temp = new Object();
        temp = null;
        System.gc();
    }
}
