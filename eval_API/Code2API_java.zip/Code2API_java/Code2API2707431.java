package com.code2api.api;
import java.util.*;

public class Code2API2707431 {
    public static List<int[]> createDynamicTwoDimensionalArray(int columns) {
        List<int[]> rowList = new ArrayList<int[]>();

        rowList.add(new int[] { 1, 2, 3 });
        rowList.add(new int[] { 4, 5, 6 });
        rowList.add(new int[] { 7, 8 });

        return rowList;
    }
}
