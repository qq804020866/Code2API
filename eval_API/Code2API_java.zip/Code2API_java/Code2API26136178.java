package com.code2api.api;
import java.util.regex.Pattern;

public class Code2API26136178 {
    public static String[] splitStringIgnoringWhitespace(String input) {
        return input.split("\\s(?!999)");
    }
}
