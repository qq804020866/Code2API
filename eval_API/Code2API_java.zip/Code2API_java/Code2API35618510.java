package com.code2api.api;
import homeWork.ShoppingBag;

public class Code2API35618510 {
    public static void printShoppingBag(ShoppingBag sb) {
        System.out.print(sb);
    }
}
