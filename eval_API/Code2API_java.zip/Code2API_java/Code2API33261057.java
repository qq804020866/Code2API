package com.code2api.api;
public class Code2API33261057 {
    public static String replaceDoubleQuotes(String text) {
        text = text.replaceAll("\\\"","\"").replaceAll("\"\"", "\"");
        return text;
    }
}
