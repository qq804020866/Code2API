package com.code2api.api;
import java.math.BigInteger;

public class Code2API8890335 {
    public static byte[] convertHexToByteArray(String hexString) {
        return new BigInteger(hexString, 16).toByteArray();
    }
}
