package com.code2api.api;
public class Code2API15977262 {
    public static String appendByteToString(String originalString, byte byteToAppend) {
        originalString += Byte.toString(byteToAppend);
        return originalString;
    }
}
