package com.code2api.api;
public class Code2API23551020 {
    public static void breakWhileLoop() {
        int i = 0;
        while (i++ < 10) {
            if (i == 5) break;
        }
        System.out.println(i); //prints 5
    }
}
