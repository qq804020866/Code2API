package com.code2api.api;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;

public class Code2API8182674 {
    public static JScrollPane createScrollableJTextPane() {
        return new JScrollPane(new JTextPane());
    }
}
