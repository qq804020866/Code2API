package com.code2api.api;
public class Code2API6646535 {
    public static void getTimeTakenToRunProgram() {
        long startTime = System.nanoTime();

        // code

        long endTime = System.nanoTime();
        System.out.println("Took " + (endTime - startTime) + " ns");
    }
}
