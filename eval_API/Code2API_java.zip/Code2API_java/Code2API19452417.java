package com.code2api.api;
public class Code2API19452417 {
    public static String convertToRegex(String value) {
        value = value.replace("*",".*");
        return value;
    }
}
