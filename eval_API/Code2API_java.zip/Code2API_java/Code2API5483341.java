package com.code2api.api;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class Code2API5483341 {
    public static List<String> convertHashMapToList(HashMap<Integer, String> map) {
        List<String> list = new ArrayList<String>(map.values());
        return list;
    }
}
