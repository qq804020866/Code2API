package com.code2api.api;
import java.util.ArrayList;
import java.util.List;

public class Code2API5237354 {
    public static void testListForEmptyOrNullness(List<String> list) {
        list.add("");

        System.out.println("blah = " + list);
        if (list.isEmpty()) {
            System.out.println("Empty");
        }
    }
}
