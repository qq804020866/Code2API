package com.code2api.api;
public class Code2API5387398 {
    public static void convertMinutesToHoursAndMinutes(int minutes) {
        int hours = minutes / 60;
        int minutesRemaining = minutes % 60;
        System.out.printf("%d:%02d", hours, minutesRemaining);
    }
}
