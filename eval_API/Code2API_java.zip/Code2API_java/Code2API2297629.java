package com.code2api.api;
import java.io.BufferedInputStream;
import java.util.Scanner;

public class Code2API2297629 {
    public static void readInputWithMultipleLines() {
        Scanner stdin = new Scanner(new BufferedInputStream(System.in));
        while (stdin.hasNext()) {
            System.out.println(Math.abs(stdin.nextLong() - stdin.nextLong()));
        }
    }
}
