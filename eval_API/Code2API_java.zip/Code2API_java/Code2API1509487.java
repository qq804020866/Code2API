package com.code2api.api;
import java.util.Map;
import java.util.TreeMap;

public class Code2API1509487 {
    public static String getFirstEntryValue(TreeMap<String, String> myMap) {
        return myMap.firstEntry().getValue();
    }
}
