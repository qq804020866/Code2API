package com.code2api.api;
import java.util.ArrayList;
import java.util.Collection;

public class Code2API919420 {
    public static ArrayList<String> getDifferenceBetweenLists(ArrayList<String> listA, ArrayList<String> listB) {
        listB.removeAll(listA);
        return listB;
    }
}
