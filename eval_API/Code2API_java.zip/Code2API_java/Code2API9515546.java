package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API9515546 {
    public static String getStringAfterLastComma(String input) {
        Pattern p = Pattern.compile(".*,\\s*(.*)");
        Matcher m = p.matcher(input);

        if (m.find())
            return m.group(1);
        
        return null;
    }
}
