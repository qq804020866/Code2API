package com.code2api.api;
import java.math.BigInteger;

public class Code2API6563306 {
    public static void initializeBigInteger(BigInteger[] t2) {
        t2[0] = new BigInteger("2");
        t2[1] = BigInteger.ZERO;
    }
}
