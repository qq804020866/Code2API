package com.code2api.api;
public class Code2API425466 {
    public static void checkForNullElements(Object[][] someArray) {
        for (int i=0; i<=someArray.length-1; i++) {
            if (someArray[i] != null) {
                System.out.println("not null");
            } else {
                System.out.println("null");
            }
        }
    }
}
