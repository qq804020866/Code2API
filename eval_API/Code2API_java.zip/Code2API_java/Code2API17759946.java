package com.code2api.api;
import java.util.ArrayList;

public class Code2API17759946 {
    public static boolean checkObjectCasting(Object obj) {
        return obj instanceof ArrayList;
    }
}
