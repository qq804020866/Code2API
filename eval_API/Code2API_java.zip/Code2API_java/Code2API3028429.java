package com.code2api.api;
import java.math.BigInteger;

public class Code2API3028429 {
    public static String convertBigIntegerToString(BigInteger bigInteger) {
        return new String(bigInteger.toByteArray());
    }
}
