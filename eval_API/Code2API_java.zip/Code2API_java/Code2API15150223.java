package com.code2api.api;
public class Code2API15150223 {
    public static void checkStringForIncorrectCharacters(String input) {
        if(!input.matches("[abc]+")) {
            System.out.println("The string you entered has some incorrect characters");
        }
    }
}
