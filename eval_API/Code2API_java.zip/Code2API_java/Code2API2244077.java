package com.code2api.api;
public class Code2API2244077 {
    public static void executeCommand(String[] cmd) throws Exception {
        Process p = Runtime.getRuntime().exec(cmd);
        p.waitFor();
    }
}
