package com.code2api.api;
public class Code2API2361108 {
    public static void compileAndRunJavaProgram() {
        public class HelloWorld {
            public static void main(String args[]) {
                System.out.println("Hello World!");
            }
        }
    }
}
