package com.code2api.api;
public class Code2API460590 {
    public static String getJnlpServerAddress() {
        return "<jnlp>\n  [...]\n  <resources>\n    [...]\n    <property name=\"serverAddress\" value=\"...\" />\n  </resources>\n</jnlp>";
    }
}
