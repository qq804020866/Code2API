package com.code2api.api;
public class Code2API7438009 {
    public static int convertBinaryToDecimal(String binary) {
        return Integer.parseInt(binary, 2);
    }
}
