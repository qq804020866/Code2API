package com.code2api.api;
import java.util.UUID;

public class Code2API3388104 {
    public static String createGUID() {
        UUID uuid = UUID.randomUUID();
        String randomUUIDString = uuid.toString();
        return randomUUIDString;
    }
}
