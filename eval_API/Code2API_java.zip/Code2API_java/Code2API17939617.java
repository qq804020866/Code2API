package com.code2api.api;
import java.util.*;
import java.lang.*;

public class Code2API17939617 {
    public static void getExecutionPath(String[] args) {
        final String dir = System.getProperty("user.dir");
        System.out.println("current dir = " + dir);
    }
}
