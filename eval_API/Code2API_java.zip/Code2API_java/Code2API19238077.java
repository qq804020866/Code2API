package com.code2api.api;
public class Code2API19238077 {
    public static String convertCharArrayToString(char[] c) {
        return String.valueOf(c);
    }
}
