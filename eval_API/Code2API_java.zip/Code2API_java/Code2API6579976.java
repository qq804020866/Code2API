package com.code2api.api;
public class Code2API6579976 {
    public static String getRegexPattern() {
        return "[A-Za-z0-9.,:-]*";
    }
}
