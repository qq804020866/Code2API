package com.code2api.api;
import java.util.regex.Pattern;

public class Code2API1612912 {
    public static String removeCarriageReturn(String input) throws Exception {
        return input.replaceAll("[\n\r]", "");
    }
}
