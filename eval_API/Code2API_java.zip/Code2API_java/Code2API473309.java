package com.code2api.api;
import java.lang.String;

public class Code2API473309 {
    public static String leftPadWithZeros(int number, int length) {
        return String.format("%0" + length + "d", number);
    }
}
