package com.code2api.api;
public class Code2API18471715 {
    public static String addEscapeCharacters(String input) {
        input = input.replaceAll("'", "\\\\'");
        input = input.replaceAll("\"", "\\\\\"");
        return input;
    }
}
