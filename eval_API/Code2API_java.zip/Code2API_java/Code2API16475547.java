package com.code2api.api;
import java.util.Arrays;

public class Code2API16475547 {
    public static byte[] initializeByteArray(int size, byte value) {
        byte[] bytes = new byte[size];
        Arrays.fill(bytes, value);
        return bytes;
    }
}
