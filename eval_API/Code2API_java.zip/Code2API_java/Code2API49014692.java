package com.code2api.api;
public class Code2API49014692 {
    public static void printStackTraceAtBreakpoint() {
        new Exception().printStackTrace();
    }
}
