package com.code2api.api;
import java.math.BigInteger;

public class Code2API5153956 {
    public static String convertHexStringToLong(String hexString) {
        BigInteger bi = new BigInteger(hexString, 16);
        return bi.toString();
    }
}
