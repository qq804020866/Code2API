package com.code2api.api;
public class Code2API36568643 {
    public static String createNumberSequence(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<length; i++) {
            sb.append(i);
        }
        return sb.toString();
    }
}
