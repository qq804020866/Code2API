package com.code2api.api;
public class Code2API7506812 {
    public static String adjustTrailingWhitespace(String input, int length) {
        return String.format("[%-"+length+"s]", input);
    }
}
