package com.code2api.api;
import java.util.regex.Pattern;

public class Code2API2800839 {
    public static String removeLeadingZeros(String input) {
        return input.replaceFirst("^0+(?!$)", "");
    }
}
