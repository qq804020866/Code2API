package com.code2api.api;
public class Code2API7478238 {
    public static String[] searchCharArrayForChar(char[] array, char target) {
        String s = new String(array);
        String[] words = s.split("\\s+");
        return words;
    }
}
