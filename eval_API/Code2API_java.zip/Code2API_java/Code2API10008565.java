package com.code2api.api;
public class Code2API10008565 {
    public static String[] getOperatingSystem() {
        return new String[] {System.getProperty("os.name"), System.getProperty("os.version"), System.getProperty("os.arch")};
    }
}
