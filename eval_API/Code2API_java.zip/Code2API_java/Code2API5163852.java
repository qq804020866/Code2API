package com.code2api.api;
public class Code2API5163852 {
    public static String getLastCharacter(String input) {
        return input.substring(input.length() - 1);
    }
}
