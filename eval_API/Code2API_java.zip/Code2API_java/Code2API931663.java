package com.code2api.api;
import java.io.IOException;

public class Code2API931663 {
    public static void launchExternalProgram(String cmd) throws IOException {
        Runtime.getRuntime().exec(cmd);
    }
}
