package com.code2api.api;
import java.util.ArrayList;
import java.util.Arrays;

public class Code2API6681899 {
    public static String[] removeElementFromArray(String[] array, int index) {
        java.util.List<String> list = new ArrayList<String>(Arrays.asList(array));
        list.remove(index);
        String[] new_array = list.toArray(new String[0]);
        return new_array;
    }
}
