package com.code2api.api;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class Code2API5950446 {
    public static void incrementTimeByOneHour(Date previousTime, Date currentTime) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(previousTime);
        calendar.add(Calendar.HOUR, 1);
        previousTime = calendar.getTime();
        // do your comparison
    }
}
