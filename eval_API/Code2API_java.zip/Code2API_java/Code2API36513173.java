package com.code2api.api;
public class Code2API36513173 {
    public static void formatHtmlPage() {
        System.out.println("<br />");
    }
}
