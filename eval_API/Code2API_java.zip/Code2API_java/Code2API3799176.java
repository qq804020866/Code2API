package com.code2api.api;
public class Code2API3799176 {
    public static void iterateThroughString(String exampleString) {
        for (char ch : exampleString.toCharArray()) {
            System.out.println(ch);
        }
    }
}
