package com.code2api.api;
import javax.swing.*;
import java.awt.*;

public class Code2API15694375 {
    public static void setLayoutForPanels() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        JPanel paintPanel = new JPanel();
        JPanel textPanel = new JPanel();

        mainPanel.add(paintPanel);
        mainPanel.add(textPanel);
    }
}
