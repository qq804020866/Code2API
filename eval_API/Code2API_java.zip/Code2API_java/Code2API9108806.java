package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API9108806 {
    public static String removeLeadingAndTrailingWhitespace(String s) {
        return s.trim();
    }
}
