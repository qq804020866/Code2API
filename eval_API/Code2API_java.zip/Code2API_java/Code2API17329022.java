package com.code2api.api;
import java.util.Calendar;

public class Code2API17329022 {
    public static void subtractHoursFromCalendar(Calendar calendar, int hours) {
        calendar.add(Calendar.HOUR, -hours);
    }
}
