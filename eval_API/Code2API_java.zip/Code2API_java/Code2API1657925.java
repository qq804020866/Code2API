package com.code2api.api;
public class Code2API1657925 {
    public static void throwDivideByZeroException(int numerator, int divisor) throws IllegalArgumentException {
        if (divisor == 0) {
            throw new IllegalArgumentException("Argument 'divisor' is 0");
        }
    }
}
