package com.code2api.api;
public class Code2API7577573 {
    public static String replaceWordInString(String message, String wordToReplace, String replacement) {
        return message.replaceAll(wordToReplace, replacement);
    }
}
