package com.code2api.api;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

public class Code2API269538 {
    public static void getFirstDayOfWeek() {
        Calendar c = new GregorianCalendar();
        System.out.println(Locale.getDefault() + ": " + c.getFirstDayOfWeek());
    }
}
