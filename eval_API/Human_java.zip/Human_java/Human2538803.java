package com.stackoverflow.api;

public class Human2538803 {

  public static void printFloatWithTwoDecimals(float val) {
    System.out.printf("%.2f", val);
  }
}
