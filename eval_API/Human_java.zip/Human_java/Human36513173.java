package com.stackoverflow.api;

public class Human36513173 {

  public static void htmlFormat() {
    System.out.println("<br />");
  }
}
