package com.stackoverflow.api;

public class Human4141352 {

  public static String readableByteArray(byte[] byteArray) {
    return new String(byteArray);
  }
}
