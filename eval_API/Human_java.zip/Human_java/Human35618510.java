package com.stackoverflow.api;

public class Human35618510 {

  public static void printObject(Object sb) {
    System.out.print(sb);
  }
}
