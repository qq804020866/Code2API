package com.stackoverflow.api;

public class Human7190525 {

  public static String[] getLinesFromStringBuilder(StringBuilder sb) {
    String[] lines = sb.toString().split("\\n");

    return lines;
  }
}
