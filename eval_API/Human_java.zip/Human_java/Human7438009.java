package com.stackoverflow.api;

public class Human7438009 {

  public static int convertBinaryStringToDecimal(String c) {
    return Integer.parseInt(c, 2);
  }
}
