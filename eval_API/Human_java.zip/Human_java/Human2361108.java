package com.stackoverflow.api;

public class Human2361108 {

  public static void printHello() {
    System.out.println("Hello World!");
  }
}
