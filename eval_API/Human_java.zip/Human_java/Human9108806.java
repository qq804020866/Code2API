package com.stackoverflow.api;

public class Human9108806 {

  public static String removeLeadingAndTrailingWhitespaces(String s) {
    return s.replaceAll("^\\s+", "").replaceAll("\\s+$", "");
  }
}
