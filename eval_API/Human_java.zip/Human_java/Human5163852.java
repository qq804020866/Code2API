package com.stackoverflow.api;

public class Human5163852 {

  public static String getLastChar(String str1) {
    String string = str1;
    return string.substring(string.length() - 1);
  }
}
