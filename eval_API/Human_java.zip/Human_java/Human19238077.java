package com.stackoverflow.api;

public class Human19238077 {

  public static String charArrayToString(char[] c) {
    String s = String.valueOf(c);
    return s;
  }
}
