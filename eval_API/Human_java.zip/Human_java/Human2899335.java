package com.stackoverflow.api;

public class Human2899335 {

  public static char incrementValueToChar(char value, int increment) {
    char next = (char) (value + increment);
    System.out.println(next);
    return next;
  }
}
