package com.stackoverflow.api;

import javax.swing.*;

public class Human36652931 {

  public static JButton createJButtonWithDisabledIcon(Icon icon3) {
    JButton button = new JButton(icon3);
    button.setDisabledIcon(icon3);
    return button;
  }
}
