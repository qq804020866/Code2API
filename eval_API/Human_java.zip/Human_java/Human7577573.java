package com.stackoverflow.api;

public class Human7577573 {

  public static String replaceWordInString(
    String message,
    String target,
    String name
  ) {
    return message.replaceAll(target, name);
  }
}
