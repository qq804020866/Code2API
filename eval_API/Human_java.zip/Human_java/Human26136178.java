package com.stackoverflow.api;

public class Human26136178 {

  public static String[] specializedStringSplitter(String a) {
    return a.split("\\s(?!999)");
  }
}
