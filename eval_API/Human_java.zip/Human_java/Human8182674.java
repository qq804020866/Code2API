package com.stackoverflow.api;

import javax.swing.*;

public class Human8182674 {

  public static JScrollPane insertScrollBar(JTextPane txt) {
    return new JScrollPane(txt);
  }
}
