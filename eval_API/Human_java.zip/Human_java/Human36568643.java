package com.stackoverflow.api;

public class Human36568643 {

  public static String numberSequence() {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < 1000; i++) {
      sb.append(i);
    }
    return sb.toString();
  }
}
