package com.stackoverflow.api;

public class Human473309 {

  public static String getStringFormatting(double yournumber) {
    return String.format("%05d", yournumber);
  }
}
