package com.stackoverflow.api;

public class Human49014692 {

  public static void printStacktrace() {
    new Exception().printStackTrace();
  }
}
