package com.stackoverflow.api;

public class Human16764615 {

  public static boolean matchDoubleQuotesRegex(String str) {
    return str.matches("\".*\"");
  }
}
