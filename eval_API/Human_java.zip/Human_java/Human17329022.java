package com.stackoverflow.api;

import java.util.Calendar;

public class Human17329022 {

  public static void subtractHours(Calendar rightNow) {
    rightNow.add(Calendar.HOUR, -140);
  }
}
