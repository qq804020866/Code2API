package com.stackoverflow.api;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

public class Human269538 {

  public static int getFirstDayOfWeek() {
    Calendar c = new GregorianCalendar();
    return c.getFirstDayOfWeek();
  }
}
