package com.stackoverflow.api;

public class Human1657925 {

  public static void checkIsNotZero(int divisor) {
    if (divisor == 0) {
      throw new IllegalArgumentException("Argument 'divisor' is 0");
    }
  }
}
