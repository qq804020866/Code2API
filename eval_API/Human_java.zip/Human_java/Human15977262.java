package com.stackoverflow.api;

public class Human15977262 {

  public static String byteToString(byte someByte, String someString) {
    return someString + Byte.toString(someByte);
  }
}
