package com.stackoverflow.api;

public class Human8646467 {

  public static String[] splitByDash(String theString) {
    String[] parts = theString.split("-");

    return parts;
  }
}
