package com.stackoverflow.api;

public class Human460590 {

  public static String getServerAddress() {
    return System.getProperty("serverAddress");
  }
}
