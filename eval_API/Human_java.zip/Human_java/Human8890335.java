package com.stackoverflow.api;

public class Human8890335 {

  public static byte[] stringToByte(String s) {
    return new java.math.BigInteger(s, 16).toByteArray();
  }
}
