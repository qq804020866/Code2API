package com.stackoverflow.api;

import java.util.UUID;

public class Human3388104 {

  public static String getUUID() {
    UUID uuid = UUID.randomUUID();
    return uuid.toString();
  }
}
