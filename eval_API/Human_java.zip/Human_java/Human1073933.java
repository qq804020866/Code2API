package com.stackoverflow.api;

import java.util.ArrayList;
import java.util.List;

public class Human1073933 {

  public static List<Integer> toList(int[] ints) {
    List<Integer> intList = new ArrayList<>();
    for (int i : ints) {
      intList.add(i);
    }
    return intList;
  }
}
