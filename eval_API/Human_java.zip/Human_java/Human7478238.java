package com.stackoverflow.api;

public class Human7478238 {

  public static String[] splitStringBySpaces(String array) {
    String s = new String(array);
    String[] words = s.split("\\s+");
    return words;
  }
}
