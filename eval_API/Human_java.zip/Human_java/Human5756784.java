package com.stackoverflow.api;

public class Human5756784 {

  public static String replaceBackslash(String text) {
    String newString = text.replace("\\", "/");
    return newString;
  }
}
