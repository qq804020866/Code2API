package com.stackoverflow.api;

import java.util.Arrays;

public class Human16475547 {

  public static byte[] initializeByteArray() {
    byte[] bytes = new byte[100];
    Arrays.fill(bytes, (byte) 1);
    return bytes;
  }
}
