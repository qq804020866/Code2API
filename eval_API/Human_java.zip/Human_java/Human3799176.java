package com.stackoverflow.api;

public class Human3799176 {

  public static char[] convertStringToCharArray(String exampleString) {
    char[] result = exampleString.toCharArray();
    for (char ch : result) {
      System.out.println(ch);
    }
    return result;
  }
}
