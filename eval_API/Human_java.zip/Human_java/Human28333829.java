package com.stackoverflow.api;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Human28333829 {

  public static String formatter_format(
    SimpleDateFormat formatter,
    Date receivedDateObj
  ) {
    return formatter.format(receivedDateObj);
  }
}
