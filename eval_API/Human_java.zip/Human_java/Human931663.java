package com.stackoverflow.api;

public class Human931663 {

  /**
   * @param command the command line arguments
   */
  public static void executeJavaProcess(String str1) throws Exception {
    Runtime.getRuntime().exec(str1);
  }
}
