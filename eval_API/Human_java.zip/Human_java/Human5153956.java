package com.stackoverflow.api;

import java.math.BigInteger;

public class Human5153956 {

  public static BigInteger hexStrToBigInteger(String s) {
    BigInteger bi = new BigInteger(s, 16);
    return bi;
  }
}
