package com.stackoverflow.api;

public class Human6646535 {

  public static long getRunningTime() {
    long startTime = System.nanoTime();
    //code
    //I am not sure about how to implement here
    long endTime = System.nanoTime();
    return (endTime - startTime);
  }
}
