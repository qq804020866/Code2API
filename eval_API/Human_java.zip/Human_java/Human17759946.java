package com.stackoverflow.api;

import java.util.ArrayList;

public class Human17759946 {

  public static boolean checkConvertable(Object obj) {
    //    ArrayList<Character> obj = new ArrayList<Character>();
    if (
      obj instanceof java.util.ArrayList
    ) //        System.out.println("My problem Solved");
    return true;
    return false;
  }
}
