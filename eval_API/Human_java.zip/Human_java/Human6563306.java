package com.stackoverflow.api;

import java.math.BigInteger;

public class Human6563306 {

  public static BigInteger[] initBigIntegerArray() {
    BigInteger[] t3 = { new BigInteger("2"), BigInteger.ZERO };
    return t3;
  }
}
