package com.stackoverflow.api;

public class Human27372799 {

  public static String[] parseNumbers(String message) {
    String[] msg = message.split(",");
    return msg;
  }
}
