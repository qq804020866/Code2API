package com.stackoverflow.api;

import java.util.Calendar;

/**
 * How to get the last Sunday before current date?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/12783806">https://stackoverflow.com/a/12783806</a>
 */
public class APIzator12783806 {

  public static int get() throws Exception {
    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DAY_OF_WEEK, -(cal.get(Calendar.DAY_OF_WEEK) - 1));
    return cal.get(Calendar.DATE);
  }
}
