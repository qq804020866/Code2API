package com.stackoverflow.api;

import com.sun.management.UnixOperatingSystemMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;

/**
 * How to find out number of files currently open by Java application?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/16361505">https://stackoverflow.com/a/16361505</a>
 */
public class APIzator16361505 {

  public static void find() {
    OperatingSystemMXBean os = ManagementFactory.getOperatingSystemMXBean();
    if (os instanceof UnixOperatingSystemMXBean) {
      System.out.println(
        "Number of open fd: " +
        ((UnixOperatingSystemMXBean) os).getOpenFileDescriptorCount()
      );
    }
  }
}
