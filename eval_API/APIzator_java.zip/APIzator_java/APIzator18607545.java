package com.stackoverflow.api;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * How to split the strings in a file and read them?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/18607545">https://stackoverflow.com/a/18607545</a>
 */
public class APIzator18607545 {

  public static void splitString(String str1) throws Exception {
    BufferedReader in = null;
    try {
      in = new BufferedReader(new FileReader(str1));
      String read = null;
      while ((read = in.readLine()) != null) {
        String[] splited = read.split("\\s+");
        for (String part : splited) {
          System.out.println(part);
        }
      }
    } catch (IOException e) {
      System.out.println("There was a problem: " + e);
      e.printStackTrace();
    } finally {
      try {
        in.close();
      } catch (Exception e) {}
    }
  }
}
