package com.stackoverflow.api;

/**
 * How Can I Format A HTML Page I'm Outputting From Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/36513173">https://stackoverflow.com/a/36513173</a>
 */
public class APIzator36513173 {

  public static void formatHtml() throws Exception {
    System.out.println("<br />");
  }
}
