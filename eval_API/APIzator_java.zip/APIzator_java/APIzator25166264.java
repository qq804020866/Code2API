package com.stackoverflow.api;

/**
 * How to add delay to while loop
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/25166264">https://stackoverflow.com/a/25166264</a>
 */
public class APIzator25166264 {

  public static void addDelay() throws InterruptedException {
    int countdown = 1;
    while (countdown < 10) {
      System.out.println(countdown);
      ++countdown;
      Thread.sleep(1000);
    }
  }
}
