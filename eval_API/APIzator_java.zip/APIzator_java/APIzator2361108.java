package com.stackoverflow.api;

/**
 * How do I compile and run a program in Java on my Mac?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/2361108">https://stackoverflow.com/a/2361108</a>
 */
public class APIzator2361108 {

  public static void compile() {
    System.out.println("Hello World!");
  }
}
