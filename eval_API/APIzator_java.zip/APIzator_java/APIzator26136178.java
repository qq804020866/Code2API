package com.stackoverflow.api;

/**
 * how to split a string by ignoring the white space
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/26136178">https://stackoverflow.com/a/26136178</a>
 */
public class APIzator26136178 {

  public static String[] splitString(String a) throws Exception {
    return a.split("\\s(?!999)");
  }
}
