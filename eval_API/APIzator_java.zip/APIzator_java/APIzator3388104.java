package com.stackoverflow.api;

import java.util.UUID;

/**
 * how to create GUID in java EE
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/3388104">https://stackoverflow.com/a/3388104</a>
 */
public class APIzator3388104 {

  public static String createGuid() throws Exception {
    UUID uuid = UUID.randomUUID();
    return uuid.toString();
  }
}
