package com.stackoverflow.api;

/**
 * Cannot figure out how to print toString
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/35618510">https://stackoverflow.com/a/35618510</a>
 */
public class APIzator35618510 {

  public static void figure(int sb) throws Exception {
    System.out.print(sb);
  }
}
