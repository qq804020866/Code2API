package com.stackoverflow.api;

import java.util.Calendar;

/**
 * How to subtract hours from a calendar instance
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/17329022">https://stackoverflow.com/a/17329022</a>
 */
public class APIzator17329022 {

  public static void subtractHour() throws Exception {
    Calendar rightNow = Calendar.getInstance();
    rightNow.add(Calendar.HOUR, -140);
  }
}
