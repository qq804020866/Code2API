package com.stackoverflow.api;

/**
 * How to check that a string contains characters other than those specified. (in Java)
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/15150223">https://stackoverflow.com/a/15150223</a>
 */
public class APIzator15150223 {

  public static void check(String s) throws Exception {
    if (!s.matches("[abc]+")) {
      System.out.println(
        "The string you entered has some incorrect characters"
      );
    }
  }
}
