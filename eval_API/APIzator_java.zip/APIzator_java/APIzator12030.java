package com.stackoverflow.api;

import java.io.*;
import java.util.*;

/**
 * How can I determine the IP of my router/gateway in Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/12030">https://stackoverflow.com/a/12030</a>
 */
public class APIzator12030 {

  public static void determineGateway() throws IOException {
    Process result = Runtime
      .getRuntime()
      .exec("traceroute -m 1 www.amazon.com");
    BufferedReader output = new BufferedReader(
      new InputStreamReader(result.getInputStream())
    );
    String thisLine = output.readLine();
    StringTokenizer st = new StringTokenizer(thisLine);
    st.nextToken();
    String gateway = st.nextToken();
    System.out.printf("The gateway is %s\n", gateway);
  }
}
