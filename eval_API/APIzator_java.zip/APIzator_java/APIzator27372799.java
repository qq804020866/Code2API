package com.stackoverflow.api;

/**
 * How to parse string containing negative number into integer?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/27372799">https://stackoverflow.com/a/27372799</a>
 */
public class APIzator27372799 {

  public static int parseString(String message) throws Exception {
    String[] msg = message.split(",");
    int x = Integer.parseInt(msg[0]);
    int y = Integer.parseInt(msg[1]);
    System.out.println(x);
    return y;
  }
}
