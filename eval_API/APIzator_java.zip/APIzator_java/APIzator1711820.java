package com.stackoverflow.api;

import java.util.Calendar;
import java.util.Date;

/**
 * How to create a calendar object in Java
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/1711820">https://stackoverflow.com/a/1711820</a>
 */
public class APIzator1711820 {

  public static int createObject() throws Exception {
    Date date = new Date();
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    return calendar.get(Calendar.HOUR_OF_DAY);
  }
}
