package com.stackoverflow.api;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * How to get String[] A - String[] B i.e. all elements which are in A but not in B ,In java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/27287021">https://stackoverflow.com/a/27287021</a>
 */
public class APIzator27287021 {

  public static String[] getString(
    String[] allEmps,
    String[] listOfEmpsWithCompDefined
  ) throws Exception {
    // convert to set
    Set<String> mySet1 = new HashSet<>(Arrays.asList(allEmps));
    Set<String> mySet2 = new HashSet<>(
      Arrays.asList(listOfEmpsWithCompDefined)
    );
    // elements which are in A but not in B
    mySet1.removeAll(mySet2);
    return mySet1.toArray(new String[mySet1.size()]);
  }
}
