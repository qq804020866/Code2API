package com.stackoverflow.api;

import java.math.BigInteger;

/**
 * How to initialise BigInteger after creating instantces (constructor can't be called)
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/6563306">https://stackoverflow.com/a/6563306</a>
 */
public class APIzator6563306 {

  public static void call(BigInteger[] t2, BigInteger[] t3)
    throws Exception {
    // or
  }
}
