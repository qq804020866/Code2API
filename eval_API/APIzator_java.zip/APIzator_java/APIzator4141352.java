package com.stackoverflow.api;

/**
 * How to convert byte array into Human readable format?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/4141352">https://stackoverflow.com/a/4141352</a>
 */
public class APIzator4141352 {

  public static String convertArray(byte[] byteArray) throws Exception {
    return new String(byteArray);
  }
}
