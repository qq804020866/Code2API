package com.stackoverflow.api;

import java.io.*;

/**
 * How to save the data into File in java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/4499595">https://stackoverflow.com/a/4499595</a>
 */
public class APIzator4499595 {

  public static void saveDatum() {
    try {
      // Create file
      FileWriter fstream = new FileWriter(
        System.currentTimeMillis() + "out.txt"
      );
      BufferedWriter out = new BufferedWriter(fstream);
      out.write("Hello Java");
      // Close the output stream
      out.close();
    } catch (Exception e) {
      // Catch exception if any
      System.err.println("Error: " + e.getMessage());
    }
  }
}
