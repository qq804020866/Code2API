package com.stackoverflow.api;

/**
 * How to create a sequence of numbers in java
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/36568643">https://stackoverflow.com/a/36568643</a>
 */
public class APIzator36568643 {

  public static String createSequence() throws Exception {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < 1000; i++) {
      sb.append(i);
    }
    return sb.toString();
  }
}
