package com.stackoverflow.api;

/**
 * How to split a file path to get the file name?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/26019206">https://stackoverflow.com/a/26019206</a>
 */
public class APIzator26019206 {

  public static String splitPath(String lStr) throws Exception {
    lStr = lStr.substring(lStr.lastIndexOf("/"));
    return lStr;
  }
}
