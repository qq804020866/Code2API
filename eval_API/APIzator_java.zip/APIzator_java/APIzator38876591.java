package com.stackoverflow.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * how to add value into List<Map<String, Object>>?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/38876591">https://stackoverflow.com/a/38876591</a>
 */
public class APIzator38876591 {

  public static void addValue(Map<String, Object> map) throws Exception {
    List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
    list.add(map);
  }
}
