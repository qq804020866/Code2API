package com.stackoverflow.api;

/**
 * How to append a byte to a string in Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/15977262">https://stackoverflow.com/a/15977262</a>
 */
public class APIzator15977262 {

  public static void appendByte(String someString, byte someByte)
    throws Exception {
    someString += Byte.toString(someByte);
  }
}
