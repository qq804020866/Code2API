package com.stackoverflow.api;

/**
 * How to search a particular character from string and find how many times it occured
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/13433126">https://stackoverflow.com/a/13433126</a>
 */
public class APIzator13433126 {

  public static void searchCharacter(String s, char c) throws Exception {
    int cnt = 0;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == c) cnt++;
    System.out.println("No of Occurences of character " + c + "is" + cnt);
  }
}
