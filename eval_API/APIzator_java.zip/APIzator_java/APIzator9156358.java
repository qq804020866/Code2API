package com.stackoverflow.api;

/**
 * How to get local time of different time zones?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/9156358">https://stackoverflow.com/a/9156358</a>
 */
public class APIzator9156358 {

  public static void getTime() throws Exception {
    java.util.TimeZone tz = java.util.TimeZone.getTimeZone("GMT+1");
    java.util.Calendar c = java.util.Calendar.getInstance(tz);
    System.out.println(
      c.get(java.util.Calendar.HOUR_OF_DAY) +
      ":" +
      c.get(java.util.Calendar.MINUTE) +
      ":" +
      c.get(java.util.Calendar.SECOND)
    );
  }
}
