package com.stackoverflow.api;

import java.util.Calendar;

/**
 * How to add one month to a date and get the same day
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/12899896">https://stackoverflow.com/a/12899896</a>
 */
public class APIzator12899896 {

  public static void addMonth() throws Exception {
    final Calendar date = Calendar.getInstance();
    date.set(2012, Calendar.SEPTEMBER, 17);
    int prevDayOfWeekInMonth = date.get(Calendar.DAY_OF_WEEK_IN_MONTH);
    int prevDayOfWeek = date.get(Calendar.DAY_OF_WEEK);
    date.add(Calendar.MONTH, 1);
    date.set(Calendar.DAY_OF_WEEK, prevDayOfWeek);
    date.set(Calendar.DAY_OF_WEEK_IN_MONTH, prevDayOfWeekInMonth);
  }
}
