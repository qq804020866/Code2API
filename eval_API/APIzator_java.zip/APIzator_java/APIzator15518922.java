package com.stackoverflow.api;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * How to validate URL in java using regex?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/15518922">https://stackoverflow.com/a/15518922</a>
 */
public class APIzator15518922 {

  public static Matcher validateUrl() throws Exception {
    Pattern p = Pattern.compile(
      "(@)?(href=')?(HREF=')?(HREF=\")?(href=\")?(http://)?[a-zA-Z_0-9\\-]+(\\.\\w[a-zA-Z_0-9\\-]+)+(/[#&amp;\\n\\-=?\\+\\%/\\.\\w]+)?"
    );
    return p.matcher("your url here");
  }
}
