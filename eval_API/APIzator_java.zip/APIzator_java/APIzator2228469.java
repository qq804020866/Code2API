package com.stackoverflow.api;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * How to find out the preferred size of a JPanel which is not displayed, according to its content?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/2228469">https://stackoverflow.com/a/2228469</a>
 */
public class APIzator2228469 {

  public static void find() throws Exception {
    // Creating the panel
    JPanel lPanel = new JPanel();
    // lPanel.setSize(1000, 1000); //default size, not needed anymore
    lPanel.setLayout(new BoxLayout(lPanel, BoxLayout.PAGE_AXIS));
    // Adding the content
    lPanel.add(new JLabel("Blah"));
    // etc...
    // Adjust the panel to its preferred size
    lPanel.setSize(lPanel.getPreferredSize());
    // Call the layout method
    // (this will adjust the content components to their correct size and position)
    lPanel.doLayout();
  }
}
