package com.stackoverflow.api;

/**
 * How can I get specific data element in a text file
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/36110491">https://stackoverflow.com/a/36110491</a>
 */
public class APIzator36110491 {

  public static String getElement(String line) throws Exception {
    String[] parts = line.split(" ");
    String name = parts[1];
    return name;
  }
}
