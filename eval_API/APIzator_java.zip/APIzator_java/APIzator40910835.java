package com.stackoverflow.api;

/**
 * How to remove all characters before a specific character in Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/40910835">https://stackoverflow.com/a/40910835</a>
 */
public class APIzator40910835 {

  public static void removeCharacter(String s) throws Exception {
    String s1 = s.substring(s.indexOf("=") + 1);
    s1.trim();
  }
}
