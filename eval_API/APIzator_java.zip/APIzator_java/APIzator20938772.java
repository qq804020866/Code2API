package com.stackoverflow.api;

/**
 * How does the concatenation of a String with characters work in Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/20938772">https://stackoverflow.com/a/20938772</a>
 */
public class APIzator20938772 {

  public static void work(int i, String str1, String str)
    throws Exception {
    str1 += String.valueOf(str.charAt(i)) + str.charAt(i);
    str1 += "" + str.charAt(i) + str.charAt(i);
    str1 = str1 + str.charAt(i) + str.charAt(i);
  }
}
