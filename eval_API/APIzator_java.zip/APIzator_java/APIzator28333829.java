package com.stackoverflow.api;

/**
 * How to parse time in correct timezone java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/28333829">https://stackoverflow.com/a/28333829</a>
 */
public class APIzator28333829 {

  public static String parseTime(String receivedDateObj, String formatter)
    throws Exception {
    return formatter.format(receivedDateObj);
  }
}
