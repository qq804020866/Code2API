package com.stackoverflow.api;

import java.awt.image.BufferedImage;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * How can I get height and width of an image?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/8184129">https://stackoverflow.com/a/8184129</a>
 */
public class APIzator8184129 {

  public static void getHeight(String str1) throws Exception {
    URL url = new URL(str1);
    final BufferedImage bi = ImageIO.read(url);
    final String size = bi.getWidth() + "x" + bi.getHeight();
    SwingUtilities.invokeLater(
      new Runnable() {
        public void run() {
          JLabel l = new JLabel(size, new ImageIcon(bi), SwingConstants.RIGHT);
          JOptionPane.showMessageDialog(null, l);
        }
      }
    );
  }
}
