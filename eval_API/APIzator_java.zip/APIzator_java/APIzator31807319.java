package com.stackoverflow.api;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * How to execute Symlink command in java
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/31807319">https://stackoverflow.com/a/31807319</a>
 */
public class APIzator31807319 {

  public static void executeCommand() throws Exception {
    Path directoryTarget = Paths.get("c:/temp");
    Path directoryLink = Paths.get("c:/links/linkTemp");
    Files.exists(directoryTarget);
    try {
      Files.createSymbolicLink(directoryLink, directoryTarget);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
