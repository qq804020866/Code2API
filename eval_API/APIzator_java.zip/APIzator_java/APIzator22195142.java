package com.stackoverflow.api;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Android how to get tomorrow's date
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/22195142">https://stackoverflow.com/a/22195142</a>
 */
public class APIzator22195142 {

  public static void android() throws Exception {
    GregorianCalendar gc = new GregorianCalendar();
    gc.add(Calendar.DATE, 1);
    // now do something with the calendar
  }
}
