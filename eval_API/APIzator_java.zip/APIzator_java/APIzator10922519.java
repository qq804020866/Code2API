package com.stackoverflow.api;

/**
 * Java: How to initialize int array in a switch case?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/10922519">https://stackoverflow.com/a/10922519</a>
 */
public class APIzator10922519 {

  public static void java(int something) throws Exception {
    int[] array;
    switch (something) {
      case 0:
        array = new int[] { 1, 2, 3 };
        break;
      default:
        array = new int[] { 3, 2, 1 };
    }
  }
}
