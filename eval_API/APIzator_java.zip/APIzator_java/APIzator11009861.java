package com.stackoverflow.api;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * How to get list of Integer from String
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/11009861">https://stackoverflow.com/a/11009861</a>
 */
public class APIzator11009861 {

  public static void getList(String number) throws Exception {
    Scanner scanner = new Scanner(number);
    List<Integer> list = new ArrayList<Integer>();
    while (scanner.hasNextInt()) {
      list.add(scanner.nextInt());
    }
  }
}
