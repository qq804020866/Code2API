package com.stackoverflow.api;

import java.io.*;
import java.util.*;

/**
 * How to read from a file and save the content into a linked list?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/16247861">https://stackoverflow.com/a/16247861</a>
 */
public class APIzator16247861 {

  public static void read(String str1) throws IOException {
    String content = new String();
    int count = 1;
    File file = new File(str1);
    LinkedList<String> list = new LinkedList<String>();
    try {
      Scanner sc = new Scanner(new FileInputStream(file));
      while (sc.hasNextLine()) {
        content = sc.nextLine();
        list.add(content);
      }
      sc.close();
    } catch (FileNotFoundException fnf) {
      fnf.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
      System.out.println("\nProgram terminated Safely...");
    }
    Collections.reverse(list);
    Iterator i = list.iterator();
    while (i.hasNext()) {
      System.out.print("Node " + (count++) + " : ");
      System.out.println(i.next());
    }
  }
}
