package com.stackoverflow.api;

import javax.swing.JTextArea;

/**
 * How can I create a JTextArea with a specified width and the smallest possible height required to display all the text?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/4083850">https://stackoverflow.com/a/4083850</a>
 */
public class APIzator4083850 {

  public static void createJtextarea() throws Exception {
    JTextArea textArea = new JTextArea();
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    textArea.setText("one two three four five six seven eight nine ten");
    System.out.println("000: " + textArea.getPreferredSize());
    textArea.setSize(100, 1);
    System.out.println("100: " + textArea.getPreferredSize());
    textArea.setSize(textArea.getPreferredSize());
  }
}
