package com.stackoverflow.api;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * java - How do I create an int array with randomly shuffled numbers in a given range
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/15196438">https://stackoverflow.com/a/15196438</a>
 */
public class APIzator15196438 {

  public static void createArray() {
    List<Integer> dataList = new ArrayList<Integer>();
    for (int i = 0; i < 10; i++) {
      dataList.add(i);
    }
    Collections.shuffle(dataList);
    int[] num = new int[dataList.size()];
    for (int i = 0; i < dataList.size(); i++) {}
    for (int i = 0; i < num.length; i++) {
      System.out.println(num[i]);
    }
  }
}
