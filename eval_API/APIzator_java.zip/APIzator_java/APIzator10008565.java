package com.stackoverflow.api;

/**
 * How to get operating system in Java
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/10008565">https://stackoverflow.com/a/10008565</a>
 */
public class APIzator10008565 {

  public static void getSystem() throws Exception {
    System.getProperty("os.name");
    System.getProperty("os.version");
    System.getProperty("os.arch");
  }
}


