package com.stackoverflow.api;

/**
 * How to mix java webstart with RMI?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/460590">https://stackoverflow.com/a/460590</a>
 */
public class APIzator460590 {

  public static String mixWebstart() throws Exception {
    return System.getProperty("serverAddress");
  }
}
