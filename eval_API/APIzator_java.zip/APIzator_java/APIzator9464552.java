package com.stackoverflow.api;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * how to extract a phone number for a string using regular expression?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/9464552">https://stackoverflow.com/a/9464552</a>
 */
public class APIzator9464552 {

  public static void extractNumber(String str) throws Exception {
    Pattern pattern = Pattern.compile("\\d{3}-\\d{3}-\\d{4}");
    Matcher matcher = pattern.matcher(str);
    if (matcher.find()) {
      System.out.println(matcher.group(0));
    }
  }
}
