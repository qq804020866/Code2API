package com.stackoverflow.api;

/**
 * how can I get the text before and after the "-" (dash)
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/8646467">https://stackoverflow.com/a/8646467</a>
 */
public class APIzator8646467 {

  public static String getText(String theString) throws Exception {
    String[] parts = theString.split("-");
    String first = parts[0];
    return parts[1];
  }
}
