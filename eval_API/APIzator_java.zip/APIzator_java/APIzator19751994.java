package com.stackoverflow.api;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * How to extract text between square brackets with String.split
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/19751994">https://stackoverflow.com/a/19751994</a>
 */
public class APIzator19751994 {

  public static List<String> extractText(String line) {
    Matcher matcher = Pattern.compile("\\[([^\\]]+)").matcher(line);
    List<String> tags = new ArrayList<>();
    int pos = -1;
    while (matcher.find(pos + 1)) {
      pos = matcher.start();
      tags.add(matcher.group(1));
    }
    return tags;
  }
}
