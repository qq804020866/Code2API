package com.stackoverflow.api;

/**
 * How to split a double number by dot into two decimal numbers in Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/24753336">https://stackoverflow.com/a/24753336</a>
 */
public class APIzator24753336 {

  public static void splitNumber(double val, int[] intArr)
    throws Exception {
    String[] arr = String.valueOf(val).split("\\.");
  }
}
