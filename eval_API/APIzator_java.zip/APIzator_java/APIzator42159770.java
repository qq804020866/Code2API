package com.stackoverflow.api;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * how can I get height and width of a photo that I downloaded from internet in Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/42159770">https://stackoverflow.com/a/42159770</a>
 */
public class APIzator42159770 {

  public static void getHeight() throws Exception {
    BufferedImage imo;
    try {
      imo = ImageIO.read(new File("location_of_file"));
      System.out.println(imo.getHeight());
      System.out.println(imo.getWidth());
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }
}
