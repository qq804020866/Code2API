package com.stackoverflow.api;

/**
 * How to search a char array for a specific char?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/7478238">https://stackoverflow.com/a/7478238</a>
 */
public class APIzator7478238 {

  public static void searchArray(String array) throws Exception {
    String s = new String(array);
    String[] words = s.split("\\s+");
    // words = { "robots", "laser", "car" }
  }
}
