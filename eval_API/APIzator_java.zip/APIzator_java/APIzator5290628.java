package com.stackoverflow.api;

/**
 * How can I extract the first 4 digits from an int? (Java)
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/5290628">https://stackoverflow.com/a/5290628</a>
 */
public class APIzator5290628 {

  public static int extractDigit(String str) throws Exception {
    int fullInt = Integer.parseInt(str);
    String first4char = str.substring(0, 4);
    return Integer.parseInt(first4char);
  }
}
