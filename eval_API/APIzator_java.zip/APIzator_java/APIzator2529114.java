package com.stackoverflow.api;

import java.util.Arrays;
import java.util.Comparator;

/**
 * How do I sort strings that contain numbers in Java
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/2529114">https://stackoverflow.com/a/2529114</a>
 */
public class APIzator2529114 {

  public static String sortString(String string) {
    String[] numbers = string.split("\\D+");
    Arrays.sort(
      numbers,
      new Comparator<String>() {
        public int compare(String s1, String s2) {
          return Integer.valueOf(s1).compareTo(Integer.valueOf(s2));
        }
      }
    );
    return Arrays.toString(numbers);
  }
}
