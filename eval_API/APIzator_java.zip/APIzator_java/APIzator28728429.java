package com.stackoverflow.api;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * How can I split a string based on chaging characters rather than one single separator?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/28728429">https://stackoverflow.com/a/28728429</a>
 */
public class APIzator28728429 {

  public static void splitString(String patternString) throws Exception {
    Pattern pattern = Pattern.compile("y+|M+|d+");
    Matcher matcher = pattern.matcher(patternString);
    while (matcher.find()) {
      System.out.println(matcher.group());
    }
  }
}
