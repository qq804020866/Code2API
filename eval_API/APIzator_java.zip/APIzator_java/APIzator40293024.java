package com.stackoverflow.api;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * How to export queried data from Google Cloud Datastore to csv using Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/40293024">https://stackoverflow.com/a/40293024</a>
 */
public class APIzator40293024 {

  public static void exportDatum() throws Exception {
    ByteArrayOutputStream csvOS = new ByteArrayOutputStream();
    PrintStream printer = new PrintStream(csvOS);
    printer.println("L1C1;L1C2;L1C3");
    printer.println("L2C1;L2C2;L2C3");
    printer.close();
  }
}
