package com.stackoverflow.api;

/**
 * How to wrap a string
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/10990974">https://stackoverflow.com/a/10990974</a>
 */
public class APIzator10990974 {

  public static String wrapString(String str) throws Exception {
    String temp = "";
    if (str != null && str.length() > 10) {
      // here 0 is start index and 10 is last index
      temp = str.substring(0, 10) + "....";
    } else {
      temp = str;
    }
    return temp;
  }
}
