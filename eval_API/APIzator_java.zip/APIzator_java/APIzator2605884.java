package com.stackoverflow.api;

import java.io.RandomAccessFile;

/**
 * How to open a Windows named pipe from Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/2605884">https://stackoverflow.com/a/2605884</a>
 */
public class APIzator2605884 {

  public static void openWindows(String echoText) throws Exception {
    try {
      // Connect to the pipe
      RandomAccessFile pipe = new RandomAccessFile(
        "\\\\.\\pipe\\testpipe",
        "rw"
      );
      // write to pipe
      pipe.write(echoText.getBytes());
      // read response
      String echoResponse = pipe.readLine();
      System.out.println("Response: " + echoResponse);
      pipe.close();
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }
}
