package com.stackoverflow.api;

/**
 * How to convert char[] to string in java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/19238077">https://stackoverflow.com/a/19238077</a>
 */
public class APIzator19238077 {

  public static String convertChar(char[] c) throws Exception {
    String s = String.valueOf(c);
    return s;
  }
}
