package com.stackoverflow.api;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * How to remove elements from an array in java even if we have to iterate over array or can we do it directly?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/6681899">https://stackoverflow.com/a/6681899</a>
 */
public class APIzator6681899 {

  public static String[] removeElement(String[] array) throws Exception {
    java.util.List<String> list = new ArrayList<String>(Arrays.asList(array));
    list.remove(0);
    return list.toArray(new String[0]);
  }
}
