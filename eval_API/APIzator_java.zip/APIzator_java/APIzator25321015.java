package com.stackoverflow.api;

/**
 * How to launch chrome browser from java
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/25321015">https://stackoverflow.com/a/25321015</a>
 */
public class APIzator25321015 {

  public static void launchBrowser() throws Exception {
    try {
      Process p = Runtime
        .getRuntime()
        .exec("\"/Program Files (x86)/Google/Chrome/Application/chrome.exe\"");
      p.waitFor();
      System.out.println("Google Chrome launched!");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
