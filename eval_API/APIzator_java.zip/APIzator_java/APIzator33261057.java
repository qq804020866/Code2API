package com.stackoverflow.api;

/**
 * How can i replace double quotes with escape character in java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/33261057">https://stackoverflow.com/a/33261057</a>
 */
public class APIzator33261057 {

  public static String replaceQuote(String text) throws Exception {
    text = text.replaceAll("\\\"", "\"").replaceAll("\"\"", "\"");
    return text;
  }
}
