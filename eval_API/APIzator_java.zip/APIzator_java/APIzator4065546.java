package com.stackoverflow.api;

/**
 * Java: How to get the caller function name
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/4065546">https://stackoverflow.com/a/4065546</a>
 */
public class APIzator4065546 {

  public static String java() throws Exception {
    StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
    // maybe this number needs to be corrected
    StackTraceElement e = stacktrace[2];
    return e.getMethodName();
  }
}
