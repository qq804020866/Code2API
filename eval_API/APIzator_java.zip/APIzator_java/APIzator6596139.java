package com.stackoverflow.api;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * how to find String contain any alphabetic or numeric characters using java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/6596139">https://stackoverflow.com/a/6596139</a>
 */
public class APIzator6596139 {

  public static void find(String s) throws Exception {
    Pattern p = Pattern.compile("[a-zA-Z0-9]");
    Matcher m = p.matcher(s);
    if (m.find()) System.out.println(
      "The string \"" + s + "\" contains alphanumerical characters."
    );
  }
}
