package com.stackoverflow.api;

import javax.swing.Icon;
import javax.swing.JButton;

/**
 * How to stop text going grey when disabling a button?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/36652931">https://stackoverflow.com/a/36652931</a>
 */
public class APIzator36652931 {

  public static void stop(Icon icon3) throws Exception {
    JButton button = new JButton(icon3);
    button.setDisabledIcon(icon3);
  }
}
