package com.stackoverflow.api;

import java.util.Calendar;
import java.util.Date;
import java.util.Date;

/**
 * How do I add 2 weeks to a Date in java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/23307365">https://stackoverflow.com/a/23307365</a>
 */
public class APIzator23307365 {

  public static Date addWeek(Date dateOfOrder, int noOfDays)
    throws Exception {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(dateOfOrder);
    calendar.add(Calendar.DAY_OF_YEAR, noOfDays);
    return calendar.getTime();
  }
}
