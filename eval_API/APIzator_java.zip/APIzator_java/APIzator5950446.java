package com.stackoverflow.api;

import java.util.Calendar;
import java.util.Date;

/**
 * How to increment time by 1 hour
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/5950446">https://stackoverflow.com/a/5950446</a>
 */
public class APIzator5950446 {

  public static void increment(Date previous_time) throws Exception {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(previous_time);
    calendar.add(Calendar.HOUR, 1);
    previous_time = calendar.getTime();
    // do your comparison
  }
}
