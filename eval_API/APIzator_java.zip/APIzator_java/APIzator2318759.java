package com.stackoverflow.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/**
 * How to detect via Java whether a particular process is running under Windows?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/2318759">https://stackoverflow.com/a/2318759</a>
 */
public class APIzator2318759 {

  public static void detect() throws Exception {
    String line;
    try {
      Process proc = Runtime.getRuntime().exec("wmic.exe");
      BufferedReader input = new BufferedReader(
        new InputStreamReader(proc.getInputStream())
      );
      OutputStreamWriter oStream = new OutputStreamWriter(
        proc.getOutputStream()
      );
      oStream.write("process where name='explorer.exe'");
      oStream.flush();
      oStream.close();
      while ((line = input.readLine()) != null) {
        System.out.println(line);
      }
      input.close();
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }
}
