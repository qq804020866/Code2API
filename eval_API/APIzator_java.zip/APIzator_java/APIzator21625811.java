package com.stackoverflow.api;

import java.util.HashMap;
import java.util.HashSet;

/**
 * how to remove duplicate value from hash map
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/21625811">https://stackoverflow.com/a/21625811</a>
 */
public class APIzator21625811 {

  public static void removeValue(HashMap<Integer, String> hm) {
    HashSet<String> hm2 = new HashSet<String>();
    hm2.addAll(hm.values());
    for (String str : hm2) {
      System.out.println(str);
    }
  }
}
