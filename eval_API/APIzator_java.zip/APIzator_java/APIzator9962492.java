package com.stackoverflow.api;

/**
 * How to get the 'place' of a Number in Java (eg. tens, thousands, etc)
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/9962492">https://stackoverflow.com/a/9962492</a>
 */
public class APIzator9962492 {

  public static void getPlace(double[] values) throws Exception {
    for (int i = 0; i < values.length; i++) {
      double tenthPower = Math.floor(Math.log10(values[i]));
      double place = Math.pow(10, tenthPower);
      System.out.println(place);
    }
  }
}
