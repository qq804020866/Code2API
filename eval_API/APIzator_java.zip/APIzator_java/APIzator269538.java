package com.stackoverflow.api;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

/**
 * How to specify firstDayOfWeek for java.util.Calendar using a JVM argument
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/269538">https://stackoverflow.com/a/269538</a>
 */
public class APIzator269538 {

  public static void specifyFirstdayofweek() {
    Calendar c = new GregorianCalendar();
    System.out.println(Locale.getDefault() + ": " + c.getFirstDayOfWeek());
  }
}
