package com.stackoverflow.api;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * How to check if the string is a regular expression or not
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/6341414">https://stackoverflow.com/a/6341414</a>
 */
public class APIzator6341414 {

  public static void check(String input) throws Exception {
    boolean isRegex;
    try {
      Pattern.compile(input);
      isRegex = true;
    } catch (PatternSyntaxException e) {
      isRegex = false;
    }
  }
}
