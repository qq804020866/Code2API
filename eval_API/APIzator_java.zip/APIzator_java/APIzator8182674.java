package com.stackoverflow.api;

import javax.swing.JScrollPane;
import javax.swing.JTextPane;

/**
 * How to have a Scrollable JTextPane?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/8182674">https://stackoverflow.com/a/8182674</a>
 */
public class APIzator8182674 {

  public static JScrollPane haveJtextpane() throws Exception {
    JTextPane txt = new JTextPane();
    return new JScrollPane(txt);
  }
}
