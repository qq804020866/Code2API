package com.stackoverflow.api;

import java.util.Calendar;
import java.util.Date;
import java.util.Date;

/**
 * How to determine the date one day prior to a given date in Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/745451">https://stackoverflow.com/a/745451</a>
 */
public class APIzator745451 {

  public static Date determineDate(Date myDate) throws Exception {
    Calendar cal = Calendar.getInstance();
    cal.setTime(myDate);
    cal.add(Calendar.DAY_OF_YEAR, -1);
    return cal.getTime();
  }
}
