package com.stackoverflow.api;

import java.util.HashMap;
import java.util.Map;

/**
 * How to compare two Hash Maps in Java
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/26904043">https://stackoverflow.com/a/26904043</a>
 */
public class APIzator26904043 {

  public static void compareMaps(
    Map<String, String> hm1,
    Map<String, String> hm2
  ) throws Exception {
    final Map<String, String> hm3 = new HashMap<String, String>();
    for (final String key : hm1.keySet()) {
      if (hm2.containsKey(key)) {
        hm3.put(hm1.get(key), hm2.get(key));
      }
    }
  }
}
