package com.stackoverflow.api;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * How Match a Pattern in Text using Scanner and Pattern Classes?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/4916023">https://stackoverflow.com/a/4916023</a>
 */
public class APIzator4916023 {

  public static void match(String line) {
    Pattern p = Pattern.compile("\\s+[a-zA-Z]\\s+\\d{1,}\\s+\\d{1,}\\s+");
    Matcher matcher = p.matcher(line);
    while (matcher.find()) {
      System.out.printf("group: %s%n", matcher.group());
    }
    System.out.println("done");
  }
}
