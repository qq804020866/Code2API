package com.stackoverflow.api;

import java.io.*;
import java.util.Scanner;

/**
 * How to read an input file char by char using a Scanner?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/13370154">https://stackoverflow.com/a/13370154</a>
 */
public class APIzator13370154 {

  public static void readChar(String str1) throws IOException {
    Scanner s = null;
    try {
      s = new Scanner(new BufferedReader(new FileReader(str1)));
      while (s.hasNext()) {
        String str = s.next();
        char[] myChar = str.toCharArray();
        // do something
      }
    } finally {
      if (s != null) {
        s.close();
      }
    }
  }
}
