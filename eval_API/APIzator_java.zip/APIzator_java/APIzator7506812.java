package com.stackoverflow.api;

/**
 * How to adjust trailing whitespace?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/7506812">https://stackoverflow.com/a/7506812</a>
 */
public class APIzator7506812 {

  public static String adjustWhitespace() throws Exception {
    return String.format("[%-20s]", "foo");
  }
}
