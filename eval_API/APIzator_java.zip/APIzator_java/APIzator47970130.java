package com.stackoverflow.api;

import java.util.AbstractMap;
import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * How to skip successive elements in a java stream?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/47970130">https://stackoverflow.com/a/47970130</a>
 */
public class APIzator47970130 {

  static String[] filterOptionAndValue(String option, String[] args) {
    return IntStream
      .range(0, args.length)
      .filter(i -> i % 2 == 0)
      .mapToObj(i -> new AbstractMap.SimpleEntry<>(args[i], args[i + 1]))
      .filter(e -> !option.equals(e.getKey()))
      .flatMap(e -> Stream.of(e.getKey(), e.getValue()))
      .toArray(String[]::new);
  }

  public static String skipElement(String[] args) {
    return Arrays.toString(filterOptionAndValue("-k", args));
  }
}
