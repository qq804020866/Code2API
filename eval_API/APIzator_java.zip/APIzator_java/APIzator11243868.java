package com.stackoverflow.api;

/**
 * how to automatically populate a 2d array with numbers
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/11243868">https://stackoverflow.com/a/11243868</a>
 */
public class APIzator11243868 {

  public static void populateArray(int n) throws Exception {
    int[][] arr = new int[n][n];
    int inc = 1;
    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) {
      inc++;
    }
  }
}
