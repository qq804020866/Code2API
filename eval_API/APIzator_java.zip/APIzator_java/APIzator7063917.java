package com.stackoverflow.api;

import java.util.ArrayList;
import java.util.List;

/**
 * Android, how to populate a CharSequence array dynamically (not initializing?)
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/7063917">https://stackoverflow.com/a/7063917</a>
 */
public class APIzator7063917 {

  public static CharSequence[] initialize(List<String> listItems)
    throws Exception {
    return listItems.toArray(new CharSequence[listItems.size()]);
  }
}
