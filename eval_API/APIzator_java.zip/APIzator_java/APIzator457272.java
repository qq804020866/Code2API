package com.stackoverflow.api;

/**
 * How to cause soft references to be cleared in Java?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/457272">https://stackoverflow.com/a/457272</a>
 */
public class APIzator457272 {

  public static void causeReference() throws Exception {
    Object temp = new Object();
    temp = null;
    System.gc();
  }
}
