package com.stackoverflow.api;

import javax.swing.*;

/**
 * How do I get a webpage to open up in a frame?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/1988273">https://stackoverflow.com/a/1988273</a>
 */
public class APIzator1988273 {

  public static void getWebpage() throws Exception {
    JEditorPane website = new JEditorPane("http://www.google.com/");
    website.setEditable(false);
    JFrame frame = new JFrame("Google");
    frame.add(new JScrollPane(website));
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
    frame.pack();
  }
}
