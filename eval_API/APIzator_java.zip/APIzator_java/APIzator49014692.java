package com.stackoverflow.api;

/**
 * How to get stack trace in Processing debugger
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/49014692">https://stackoverflow.com/a/49014692</a>
 */
public class APIzator49014692 {

  public static void getTrace() throws Exception {
    new Exception().printStackTrace();
  }
}
