package com.stackoverflow.api;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * how to convert Base64 to String in java (For pdf)
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/32175072">https://stackoverflow.com/a/32175072</a>
 */
public class APIzator32175072 {

  public static void convertBase64(int decodedBytes, String str1)
    throws Exception {
    try (OutputStream out = new FileOutputStream(str1)) {
      out.write(decodedBytes);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
