package com.stackoverflow.api;

/**
 * How to write Fibonacci Java program without using if
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/12772008">https://stackoverflow.com/a/12772008</a>
 */
public class APIzator12772008 {

  public static void writeProgram() {
    int f = 0;
    int g = 1;
    for (int i = 1; i <= 10; i++) {
      System.out.print(f + " ");
      f = f + g;
      g = f - g;
    }
    System.out.println();
  }
}
