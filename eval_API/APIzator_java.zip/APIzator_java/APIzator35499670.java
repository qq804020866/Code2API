package com.stackoverflow.api;

/**
 * How can I compare two strings and return the lexicographical ordered result using the compareTo method?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/35499670">https://stackoverflow.com/a/35499670</a>
 */
public class APIzator35499670 {

  public static void compareString() {
    String n = new String("jennifer");
    String n2 = new String("paul");
    if (n.compareTo(n2) < 0) {
      System.out.println(n + " is before than " + n2);
    } else if (n.compareTo(n2) > 0) {
      System.out.println(n + " is after than " + n2);
    } else if (n.compareTo(n2) == 0) {
      System.out.println(n + " is equals to " + n);
    }
  }
}
