package com.stackoverflow.api;

import java.util.ArrayList;
import java.util.List;

/**
 * How to test List<String> for empty or nullness?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/5237354">https://stackoverflow.com/a/5237354</a>
 */
public class APIzator5237354 {

  public static void testList(List<String> list) throws Exception {
    // displays "blah = []"
    System.out.println("blah = " + list);
    if (list.isEmpty()) {
      // doesn't get displayed
      System.out.println("Empty");
    }
  }
}
