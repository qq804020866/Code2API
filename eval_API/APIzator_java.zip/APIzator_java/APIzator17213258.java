package com.stackoverflow.api;

import java.util.Calendar;
import java.util.Date;

/**
 * How to know if now time is between two hours?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/17213258">https://stackoverflow.com/a/17213258</a>
 */
public class APIzator17213258 {

  public static boolean know(int from, int to) throws Exception {
    Date date = new Date();
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    int t = c.get(Calendar.HOUR_OF_DAY) * 100 + c.get(Calendar.MINUTE);
    return (
      to > from && t >= from && t <= to || to < from && (t >= from || t <= to)
    );
  }
}
