package com.stackoverflow.api;

/**
 * how to get specific value from string array and save it to another string array?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/36538609">https://stackoverflow.com/a/36538609</a>
 */
public class APIzator36538609 {

  public static void getValue() throws Exception {
    String[] arrayOne = {
      "65535",
      "00000",
      "00000",
      "00000",
      "00000",
      "A32CE",
      "43251",
      "98702",
      "ACED2",
      "98AAB",
      "00000",
      "00000",
      "00000",
      "65535",
      "65535",
    };
    int validCounter = 0;
    for (int i = 0; i < arrayOne.length; i++) if (
      !(arrayOne[i].equals("65535") || arrayOne[i].equals("00000"))
    ) validCounter++;
    String[] arrayTwo = new String[validCounter];
    int arrayTwoPos = 0;
    for (int i = 0; i < arrayOne.length; i++) if (
      !(arrayOne[i].equals("65535") || arrayOne[i].equals("00000"))
    ) {
      arrayTwo[arrayTwoPos] = arrayOne[i];
      arrayTwoPos++;
    }
    for (int i = 0; i < arrayTwo.length; i++) System.out.println(arrayTwo[i]);
  }
}
