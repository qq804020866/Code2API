package com.stackoverflow.api;

/**
 * User will input some filter criteria -- how can I turn it into a regular expression for String.match
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/19452417">https://stackoverflow.com/a/19452417</a>
 */
public class APIzator19452417 {

  public static void inputCriterion(String value) throws Exception {
    // replace  * with .*
    value = value.replace("*", ".*");
  }
}
