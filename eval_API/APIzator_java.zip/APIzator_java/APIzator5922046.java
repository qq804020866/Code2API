package com.stackoverflow.api;

import java.util.Calendar;
import java.util.Date;

/**
 * How to set an expiration date in java
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/5922046">https://stackoverflow.com/a/5922046</a>
 */
public class APIzator5922046 {

  public static void setDate() throws Exception {
    Date date = new Date();
    Calendar cal = Calendar.getInstance();
    cal.setTime(date);
    cal.add(Calendar.MONTH, 6);
    java.util.Date expirationDate = cal.getTime();
    System.err.println(expirationDate);
  }
}
