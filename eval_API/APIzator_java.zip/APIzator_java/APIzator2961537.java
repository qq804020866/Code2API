package com.stackoverflow.api;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * How to get the second word from a String?
 *
 * @author APIzator
 * @see <a href="https://stackoverflow.com/a/2961537">https://stackoverflow.com/a/2961537</a>
 */
public class APIzator2961537 {

  public static void getWord(String s) throws Exception {
    Pattern pattern = Pattern.compile("\\s([A-Za-z]+)");
    Matcher matcher = pattern.matcher(s);
    if (matcher.find()) {
      System.out.println(matcher.group(1));
    }
  }
}
