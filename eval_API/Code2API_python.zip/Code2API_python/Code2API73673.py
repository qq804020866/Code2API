import sys

def terminate_script():
    sys.exit()
