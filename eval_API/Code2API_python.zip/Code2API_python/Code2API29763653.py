def select_columns_except(df, column_name):
    return df.loc[:, df.columns != column_name]
