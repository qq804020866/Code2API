import numpy

def check_numpy_version():
    return numpy.version.version
