def create_dictionary(keys, values):
    return dict(zip(keys, values))
