def check_none_type(variable):
    if variable is None:
        return True
    else:
        return False
