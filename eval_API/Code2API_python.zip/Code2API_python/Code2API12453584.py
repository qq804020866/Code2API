def concatenate_list(words):
    return '-'.join(words), ' '.join(words)
