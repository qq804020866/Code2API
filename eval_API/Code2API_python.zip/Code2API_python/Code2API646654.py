def get_last_items(num_list):
    return num_list[-9:]
