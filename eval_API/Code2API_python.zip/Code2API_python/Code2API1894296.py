import ast

def convert_string_to_list(string_list):
    return [n.strip() for n in ast.literal_eval(string_list)]
