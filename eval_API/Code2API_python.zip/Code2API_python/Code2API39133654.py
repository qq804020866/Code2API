import matplotlib.pyplot as plt

def add_subplot_titles():
    fig = plt.figure()
    ax1 = fig.add_subplot(221)
    ax2 = fig.add_subplot(222)
    ax3 = fig.add_subplot(223)
    ax4 = fig.add_subplot(224)
    ax1.title.set_text('First Plot')
    ax2.title.set_text('Second Plot')
    ax3.title.set_text('Third Plot')
    ax4.title.set_text('Fourth Plot')
    plt.show()
