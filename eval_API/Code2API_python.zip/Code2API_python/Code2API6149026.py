def format_float(value):
    return '%.2f' % value
