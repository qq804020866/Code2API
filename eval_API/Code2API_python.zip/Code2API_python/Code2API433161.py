def logical_xor(a, b):
    return bool(a) != bool(b)
