def get_dict_values(d):
    return list(d.values())
