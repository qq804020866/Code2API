def sort_dataframe(df):
    return df.sort_values('2')
