import os

def set_current_working_directory(path):
    os.chdir(path)
