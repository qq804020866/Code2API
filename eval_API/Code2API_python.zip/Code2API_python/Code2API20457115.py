def round_to_2_decimals(answer):
    return str(round(answer, 2))
