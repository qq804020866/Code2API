def check_dataframe_empty(df):
    if df.empty:
        print('DataFrame is empty!')
