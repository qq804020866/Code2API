def find_all_occurrences(my_list, element):
    return [i for i, x in enumerate(my_list) if x == element]
