import pandas as pd

def group_by_sum(df):
    return df.groupby(['Fruit','Name']).sum()
