import os
import shutil

def move_file(current_file_path, new_file_path):
    os.rename(current_file_path, new_file_path)
    os.replace(current_file_path, new_file_path)
    shutil.move(current_file_path, new_file_path)
