def count_occurrences(lst, item):
    return lst.count(item)
