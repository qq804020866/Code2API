import psutil

def get_system_status():
    cpu_percent = psutil.cpu_percent()
    virtual_memory = psutil.virtual_memory()
    virtual_memory_dict = dict(virtual_memory._asdict())
    percent_used_ram = virtual_memory.percent
    percent_available_memory = virtual_memory.available * 100 / virtual_memory.total
    
    return cpu_percent, virtual_memory, virtual_memory_dict, percent_used_ram, percent_available_memory
