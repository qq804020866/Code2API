import pandas as pd

def create_dataframe(data, index_col, header_cols):
    return pd.DataFrame(data=data[1:,1:], index=data[1:,0], columns=data[0,1:])
