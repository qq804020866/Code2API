def create_array_of_zeros():
    return [0] * 100
