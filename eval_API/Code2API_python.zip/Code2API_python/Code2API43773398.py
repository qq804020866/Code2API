import pandas as pd

def print_specific_row(df, index_value):
    print(df.loc[[index_value]])
