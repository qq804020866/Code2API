from datetime import datetime, timedelta

def subtract_one_day(date, days_to_subtract):
    return date - timedelta(days=days_to_subtract)
