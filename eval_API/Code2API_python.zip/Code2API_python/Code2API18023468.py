import pandas as pd

def get_set_index_title():
    df = pd.DataFrame(data)
    return df.index.name
