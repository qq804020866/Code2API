def check_items_in_list(list1, list2):
    return [i for i in list1 if i in list2]
