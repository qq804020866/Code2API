def convert_string_to_list(string):
    return string.split(',')
