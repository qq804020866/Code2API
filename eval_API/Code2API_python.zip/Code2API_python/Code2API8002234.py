def is_divisible(n, k):
    return n % k == 0
