def get_value_from_cell(df, col_name):
    return df.iloc[0][col_name]
