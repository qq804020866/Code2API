import django

def check_django_version():
    return django.VERSION
