def convert_to_uppercase(string):
    return string.upper()
