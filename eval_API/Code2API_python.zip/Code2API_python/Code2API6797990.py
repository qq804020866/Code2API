def lowercase_string(input_string):
    return input_string.lower()
