def convert_char_to_int_and_viceversa(char):
    return chr(97), ord(char)
