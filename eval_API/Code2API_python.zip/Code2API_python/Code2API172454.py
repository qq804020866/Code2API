def split_multi_line_string(input_string):
    return input_string.splitlines()
