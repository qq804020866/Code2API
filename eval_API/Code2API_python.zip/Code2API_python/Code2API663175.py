def get_substring(string, start_index):
    return string[start_index:]

def get_substring(string, end_index):
    return string[:end_index]

def get_substring(string, start_index, end_index):
    return string[start_index:end_index]

def get_substring(string, start_index, end_index):
    return string[start_index:-end_index]

def get_substring(string, end_index):
    return string[-end_index:]

def get_substring(string, start_index, end_index):
    return string[start_index:-end_index]
