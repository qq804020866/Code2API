def extract_numbers(txt):
    return [int(s) for s in txt.split() if s.isdigit()]
