from PIL import Image

def get_picture_size():
    im = Image.open('whatever.png')
    width, height = im.size
    return width, height
