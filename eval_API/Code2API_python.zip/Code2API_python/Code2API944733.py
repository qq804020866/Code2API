import math

def is_nan(value):
    return math.isnan(value)
