def check_key_in_dict(dict, key):
    if key in dict:
        # do something
