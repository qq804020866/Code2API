import json

def parse_json(json_str):
    data = json.loads(json_str)
    return data['two']
