from numpy import genfromtxt

def read_csv_into_record_array(file_path):
    return genfromtxt(file_path, delimiter=',')
