def append_multiple_values(lst, values):
    lst.append(values)
