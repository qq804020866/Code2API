def insert_variable_into_string(variable_value):
    return 'hanning(%d).pdf' % variable_value
