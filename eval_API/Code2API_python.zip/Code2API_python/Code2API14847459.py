from numpy import matrix

def get_matrix_dimensions():
    A = matrix([[1,2],[3,4]])
    return A.shape
