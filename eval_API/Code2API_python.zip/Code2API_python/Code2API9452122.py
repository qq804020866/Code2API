def replace_string(original_string, substring, replacement_string):
    return original_string.replace(substring, replacement_string)
