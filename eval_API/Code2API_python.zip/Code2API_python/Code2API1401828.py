import numpy

def calculate_euclidean_distance(point_a, point_b):
    return numpy.linalg.norm(point_a - point_b)
