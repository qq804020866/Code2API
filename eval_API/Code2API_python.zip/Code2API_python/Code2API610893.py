def check_attribute(obj, attribute_name):
    if hasattr(obj, attribute_name):
        return obj.attribute_name
