import random

def get_random_float(start, stop):
    return random.uniform(start, stop)
