from time import sleep

def sleep_for_milliseconds():
    sleep(0.05)
