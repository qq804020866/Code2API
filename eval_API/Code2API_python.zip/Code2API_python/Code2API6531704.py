def check_string_contains_element(url_string, extensionsToCheck):
    if any(ext in url_string for ext in extensionsToCheck):
        print(url_string)
