import json

def build_json_object():
    data = {}
    data['key'] = 'value'
    json_data = json.dumps(data)
    return json_data
