import cv2

def crop_image(image_path, x, y, w, h):
    img = cv2.imread(image_path)
    crop_img = img[y:y+h, x:x+w]
    cv2.imshow("cropped", crop_img)
    cv2.waitKey(0)
