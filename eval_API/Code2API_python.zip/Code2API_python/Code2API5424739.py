def check_if_number(user_input):
    try:
        val = int(user_input)
    except ValueError:
        print("That's not an int!")
