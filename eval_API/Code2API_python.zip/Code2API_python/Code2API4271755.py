import socket

def get_system_hostname():
    return socket.gethostname()
