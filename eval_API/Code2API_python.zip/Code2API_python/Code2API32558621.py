def iterate_columns(df):
    for column in df:
        print(df[column])
