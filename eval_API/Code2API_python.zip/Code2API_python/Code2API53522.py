def is_list_empty(lst):
    return not lst
