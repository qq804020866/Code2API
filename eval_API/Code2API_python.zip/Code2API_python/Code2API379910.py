def parse_string_to_number(input_string):
    return float(input_string), int(float(input_string))
