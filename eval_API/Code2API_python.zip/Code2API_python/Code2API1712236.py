def get_list_length(items):
    return len(items)
