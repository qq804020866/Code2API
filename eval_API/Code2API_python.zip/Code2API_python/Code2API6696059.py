def split_list_elements(my_list):
    return [i.split('\t', 1)[0] for i in my_list]
