import numpy as np

def create_and_append_array():
    a = np.zeros(shape=(3, 2))
    a[0] = [1, 2]
    a[1] = [3, 4]
    a[2] = [5, 6]
    return a
