def split_and_strip(my_string):
    return [x.strip() for x in my_string.split(',')]
