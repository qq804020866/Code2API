import pandas as pd

def add_header_row(file_path, column_names):
    return pd.read_csv(file_path, sep='\t', names=column_names)
