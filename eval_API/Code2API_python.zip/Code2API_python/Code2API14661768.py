import pandas as pd

def drop_rows(df, seq_nums):
    return df.drop(index=seq_nums)
