import datetime

def get_day_of_week(date):
    return date.weekday()
