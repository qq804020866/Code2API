def fill_string_with_spaces(string, width):
    return string.ljust(width)
