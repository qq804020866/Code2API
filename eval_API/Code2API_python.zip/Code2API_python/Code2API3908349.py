from dateutil import parser

def parse_iso8601_datetime(datestring):
    return parser.parse(datestring)
