def convert_list_to_floats(lst):
    return [float(i) for i in lst]
