def print_dictionary():
    mydictionary = {'keyname': 'somevalue'}
    for key in mydictionary:
        print("key: %s , value: %s" % (key, mydictionary[key]))
