import time

def convert_local_to_utc(local_time_string):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(time.mktime(time.strptime(local_time_string, "%Y-%m-%d %H:%M:%S"))))
