from numpy import random
import matplotlib.pyplot as plt

def remove_axis_and_padding(inputname, outputname):
    data = random.random((5,5))
    img = plt.imshow(data, interpolation='nearest')
    img.set_cmap('hot')
    plt.axis('off')
    plt.savefig(outputname, bbox_inches='tight')
