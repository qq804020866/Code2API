def convert_datetime_to_date():
    return datetime.datetime.now().date()
