def get_string_after_substring(my_string):
    return my_string.split("world", 1)[1]
