def int_to_hex_string(integer):
    return chr(integer)
