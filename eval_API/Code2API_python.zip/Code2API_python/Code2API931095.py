def reverse_string(input_string):
    return input_string[::-1]
