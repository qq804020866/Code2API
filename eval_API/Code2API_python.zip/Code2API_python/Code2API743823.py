def split_sentence(sentence):
    words = sentence.split()
    return words
