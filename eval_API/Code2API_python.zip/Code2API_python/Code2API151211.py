from datetime import date

def calculate_days_between_dates(date1, date2):
    delta = date2 - date1
    return delta.days
