def get_latest_news():
    return News.objects.order_by("-date")[:10]
