import numpy as np

def stack_stokes_lines(numrows, y):
    stokes_list = []
    for i in range(numrows):
        epoch_name = y['filename'][i]
        os.system('pdv -t {0} > temp.txt '.format(epoch_name))
        stokes_line = np.genfromtxt('temp.txt', usecols=3, dtype=[('stokesI','float')], skip_header=1)
        stokes_list.append(stokes_line)
    
    big_stokes = np.vstack(stokes_list)
    return big_stokes
