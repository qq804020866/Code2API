import codecs

def encode_to_hex(bytes_to_encode, encoding_type):
    return codecs.encode(bytes_to_encode, encoding_type)
