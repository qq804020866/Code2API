from dateutil.relativedelta import relativedelta

def add_months_to_date(start_date, num_months):
    return start_date + relativedelta(months=num_months)
