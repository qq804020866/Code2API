from sqlalchemy import create_engine, sessionmaker

def create_connection_engines(databases):
    engines = []
    sessions = []
    for dbconninfo in databases:
        engine = create_engine(dbconninfo)
        engines.append(engine)
        sessions.append(sessionmaker(bind=engine)())
    return engines, sessions
