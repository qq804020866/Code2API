import os

def generate_random_string():
    return os.urandom(8)
