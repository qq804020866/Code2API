from bs4 import BeautifulSoup
from selenium import webdriver

def parse_website():
    driver = webdriver.Firefox()
    driver.get('http://news.ycombinator.com')
    html = driver.page_source
    soup = BeautifulSoup(html)
    for tag in soup.find_all('title'):
        print(tag.text)
