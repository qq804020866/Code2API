def dump_object():
    return "<h1>|{{ points }}|</h1>"
