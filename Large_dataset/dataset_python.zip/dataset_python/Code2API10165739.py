import tornado.web

def serve_static_files(favicon_path_dir, static_path_dir):
    handlers = [
        (r'/(favicon\.ico)', tornado.web.StaticFileHandler, {'path': favicon_path_dir}),
        (r'/static/(.*)', tornado.web.StaticFileHandler, {'path': static_path_dir}),
        (r'/', WebHandler)
    ]
    # Rest of the code
