import numpy as np

def decrease_tick_labels(subplot_obj, tick_values):
    subplot_obj.yaxis.set_ticks(tick_values)
