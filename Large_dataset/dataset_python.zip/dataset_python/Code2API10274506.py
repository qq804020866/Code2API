import h5py

def extract_array_from_hdf5(filename, array_name):
    with h5py.File(filename, 'r') as f:
        return f[array_name][()]
