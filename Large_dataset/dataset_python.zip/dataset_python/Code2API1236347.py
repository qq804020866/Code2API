def configure_pypi_server():
    # Mount pypi repositories into URI space
    Alias /pypi   /var/pypi

    # /pypi/dev: Redirect for unknown packages (fallback to pypi)
    RewriteCond   /var/pypi/dev/$1 !-d
    RewriteCond   /var/pypi/dev/$1 !-f
    RewriteRule   ^/pypi/dev/([^/]+)/?$ http://pypi.python.org/pypi/$1/ [R,L]

    RewriteCond   /var/pypi/dev/$1/$2 !-f
    RewriteRule   ^/pypi/dev/([^/]+)/([^/]+)$ http://pypi.python.org/pypi/$1/$2 [R,L]

    # /pypi/stable: Redirect for unknown packages (fallback to pypi)
    RewriteCond   /var/pypi/stable/$1 !-d
    RewriteCond   /var/pypi/stable/$1 !-f
    RewriteRule   ^/pypi/stable/([^/]+)/?$ http://pypi.python.org/pypi/$1/ [R,L]

    RewriteCond   /var/pypi/stable/$1/$2 !-f
    RewriteRule   ^/pypi/stable/([^/]+)/([^/]+)$ http://pypi.python.org/pypi/$1/$2 [R,L]
