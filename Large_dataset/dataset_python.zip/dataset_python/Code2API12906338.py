# -*- coding: utf-8 -*-

def set_file_encoding():
    pass
