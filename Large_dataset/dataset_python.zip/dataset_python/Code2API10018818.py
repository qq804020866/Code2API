import pymongo

def find_houses(query):
    return db.houses.find({"hid":{"$regex": query}})
