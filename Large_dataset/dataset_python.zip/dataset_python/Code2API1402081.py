def right_align_numeric_data():
    width = 10
    str_number = str(ord('a'))
    print 'a%s' % (str_number.rjust(width))
