def format_float(num):
    return round(num, 4)
