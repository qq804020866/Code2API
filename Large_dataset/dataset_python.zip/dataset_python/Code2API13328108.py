from PIL import Image
import subprocess

def display_and_close_image():
    p = subprocess.Popen(["display", "/tmp/test.png"])
    raw_input("Give a name for image:")
    p.kill()
