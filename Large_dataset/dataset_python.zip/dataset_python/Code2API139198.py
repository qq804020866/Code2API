from inspect import getmembers, isfunction
from somemodule import foo

def list_module_functions():
    return getmembers(foo, isfunction)
