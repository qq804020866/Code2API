def download_file_via_ftp(ftp, filename, path):
    handle = open(path.rstrip("/") + "/" + filename.lstrip("/"), 'wb')
    ftp.retrbinary('RETR %s' % filename, handle.write)
