import matplotlib.pyplot as plt

def export_figure():
    plot(range(80))
    xlabel('foo')
    ylabel('bar')
    legend(['myline'])
    axis([0, 80, 0, 120])
    savefig('sample.pdf')
