def get_string_after_substring(input_string, target_substring):
    return input_string.split(target_substring, 1)[1]
