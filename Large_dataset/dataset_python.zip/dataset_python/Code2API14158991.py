def write_streaming_text_file(file_path, mydata):
    with open(file_path, 'w', buffering=20*(1024**2)) as myfile:
        for line in mydata:
            myfile.write(line + '\n')
