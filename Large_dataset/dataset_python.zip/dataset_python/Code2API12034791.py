from importlib import reload
import logging

def reset_logging_module():
    logging.shutdown()
    return reload(logging)
