import subprocess

def check_ffmpeg_installed():
    subprocess.Popen([exe, '-version'], stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
