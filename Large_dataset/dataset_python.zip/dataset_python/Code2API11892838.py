from pyquery import PyQuery
import requests

def login_to_website(username_email, password):
    payload = {'inUserName': username_email, 'inUserPass': password}
    url = 'http://www.locationary.com/home/index2.jsp'
    requests.post(url, data=payload)
