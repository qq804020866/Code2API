from PyQt4.QtCore import *
from PyQt4.QtGui import *

def get_lineedit_text(dlg):
    return dlg.ui.lineEdit.text()
