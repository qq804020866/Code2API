import numpy as np

def is_numpy_type(obj):
    return type(obj).__module__ == np.__name__
