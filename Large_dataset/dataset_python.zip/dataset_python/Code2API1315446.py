import getopt, sys

def check_mandatory_arguments():
    found_f = False
    try:
        opts, args = getopt.getopt(sys.argv[1:], "ho:v", ["help", "output="])
    except getopt.GetoptError as err:
        print(str(err))
        usage()
        sys.exit(2)
    for o, a in opts:
        if o == '-f':
            process_f()
            found_f = True
        elif ...
    if not found_f:
        print("-f was not given")
        usage()
        sys.exit(2)
