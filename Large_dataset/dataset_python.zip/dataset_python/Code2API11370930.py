def iterate_list_of_dict(listofobs):
    for a in listofobs:
        print(str(a['timestamp']), a['ip'], a['user'])
