def change_tuple_value(tuple_values, index):
    lst = list(tuple_values)
    lst[index] = '300'
    return tuple(lst)
