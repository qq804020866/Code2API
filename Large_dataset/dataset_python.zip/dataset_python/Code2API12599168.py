def hide_label_in_form():
    return '''
<form ...>
    {% for field in form.hidden_fields %}
        {{ field }}
    {% endfor %}

    {% for field in form.visible_fields %}
        {{ field.label }} {{ field }}
    {% endfor %}
</form>
'''
