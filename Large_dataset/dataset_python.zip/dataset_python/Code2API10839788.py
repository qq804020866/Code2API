import matplotlib.pyplot as plt

def set_x_axis_step():
    plt.xticks([1, 2, 3, 4, 5])
