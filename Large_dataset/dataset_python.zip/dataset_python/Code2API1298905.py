import itertools

def create_dictionary_with_initial_size():
    d = {}
    for i in xrange(4000000):
        d[i] = None

    d = dict(itertools.izip(xrange(4000000), itertools.repeat(None)))

    dict.fromkeys(xrange(4000000))

    s = set(xrange(4000000))
    dict.fromkeys(s)
