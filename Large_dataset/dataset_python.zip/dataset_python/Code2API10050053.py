import tkinter as tk

def set_listbox_exportselection(listbox):
    listbox.config(exportselection=False)
