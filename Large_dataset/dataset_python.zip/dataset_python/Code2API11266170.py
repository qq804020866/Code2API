def get_numpy_array_address(array):
    return array.__array_interface__['data']
