def view_enqueued_tasks():
    return "rabbitmqctl list_queues"
