from IPython.utils import coloransi
from IPython.core import prompts

def customize_text_color():
    termcolors = coloransi.TermColors() # the color table
    # IPython's two color schemes:
    dark = prompts.PColLinux.colors
    light = prompts.PColLightBG.colors

    # colors.in_normal affects input code
    dark.in_normal = termcolors.Green
    light.in_normal = termcolors.Blue
    # colors.normal affects output
    dark.normal = light.normal = termcolors.Red
