def is_file_utf8(file_path):
    try:
        filedata = open(file_path, encoding='UTF-8').read() 
    except:
        filedata = open(file_path, encoding='other-single-byte-encoding').read() 
    return filedata
