import numpy as np

def convert_histogram_to_pmf(values, bin_size):
    return np.histogram(values, bins=bin_size, normed=1)[0]
