from pprint import pprint

def print_dict_separate_line():
    pprint(sums)
