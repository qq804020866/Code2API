import compileall

def compile_py_files(dir_path):
    compileall.compile_dir(dir_path, force=True)
