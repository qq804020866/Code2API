import numpy as np
import matplotlib.pyplot as plt

def plot_image_with_scatter(x, y, image):
    plt.imshow(image, extent=[x.min(), x.max(), y.min(), y.max()])
    plt.plot(x, y, 'ro')
    plt.show()
