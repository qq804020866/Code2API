def remove_first_last(lst):
    return [' '.join(el.split()[1:-1]) for el in lst]
