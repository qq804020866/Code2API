def create_multiline_string():
    cmd = """line %d
      line %d
      line %d""" % (
      1,
      2,
      3)
    return cmd
