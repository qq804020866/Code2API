import os

def get_image_size():
    return os.stat('somefile.ext').st_size
