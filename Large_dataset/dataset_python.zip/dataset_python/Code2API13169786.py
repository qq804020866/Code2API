def convert_string_to_list(input_string):
    out = []
    buff = []
    for c in input_string:
        if c == '\n':
            out.append(''.join(buff))
            buff = []
        else:
            buff.append(c)
    else:
        if buff:
            out.append(''.join(buff))
    return out
