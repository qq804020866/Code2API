import pymongo

def get_distinct_tags(collection_name, category):
    return db[collection_name].find({"category": category}).distinct("tags")
