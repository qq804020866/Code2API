import serial

def send_data_to_xbee(port, baud, timeout, packet):
    ser = serial.Serial(port, baud, timeout=timeout)
    ser.write(packet)
    data = ser.read()
    return data
