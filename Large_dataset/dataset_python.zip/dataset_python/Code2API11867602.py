import datetime
import numpy as np

def get_unix_timestamp():
    now = np.datetime64(datetime.datetime.now())
    return (now.astype('uint64') / 1e6).astype('uint32')
