import matplotlib.pyplot as plt

def plot_with_labels(x_A, y_A, x_B, y_B):
    plt.plot(x_A,y_A,'g--', label="plot A")
    plt.plot(x_B,y_B,'r-o', label="plot B")
    plt.legend()
    plt.show()
