def use_2to3_tool(file_path):
    return "python C:\Python32\Tools\scripts\2to3.py -w " + file_path
