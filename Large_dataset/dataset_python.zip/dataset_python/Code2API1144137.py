import matplotlib.pyplot as plt
import Image

def customize_axis_ticks(tick_locs, tick_lbls):
    plt.xticks(tick_locs, tick_lbls)
