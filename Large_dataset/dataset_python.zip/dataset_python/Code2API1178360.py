def strip_chars_after_semicolon(line):
    return line.split(";")[0]
