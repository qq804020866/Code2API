import requests

def get_json_data(url):
    r = requests.get(url)
    return r.json()
