from pandas.io import data as web

def calculate_monthly_change(start_date, end_date, symbol):
    s = web.get_data_yahoo(symbol, start=start_date, end=end_date)['Adj Close']
    monthly = s.resample('BM', how=lambda x: x[-1])
    return monthly.pct_change()
