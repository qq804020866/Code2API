def concatenate_strings_with_binary(data, sep):
    return sep.join(data)
