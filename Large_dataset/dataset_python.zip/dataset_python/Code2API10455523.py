def reduce_decimal_precision(number):
    return '%.4f' % (number)
