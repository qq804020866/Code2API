def set_focus_for_widget(list_widget, item_index):
    list_widget.selection_set(item_index)
    list_widget.focus_set()
    list_widget.focus(item_index)
