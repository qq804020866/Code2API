import subprocess

def run_python_script(cmd, args):
    start = subprocess.Popen(["my/full/path/to/python.exe", cmd, args], stdout=subprocess.PIPE)
    output = start.communicate()[0]
    print(output)
