import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as stats
import math

def plot_normal_distribution(mean, variance):
    sigma = math.sqrt(variance)
    x = np.linspace(mean - 3*sigma, mean + 3*sigma, 100)
    plt.plot(x, stats.norm.pdf(x, mean, sigma))
    plt.show()
