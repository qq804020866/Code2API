def cache_pip_packages():
    return "pip install --download-cache /path/to/pip/cache matplotlib"
