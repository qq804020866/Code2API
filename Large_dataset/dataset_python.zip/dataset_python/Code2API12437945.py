import pymongo

def query_element_from_list(collection_name, tag):
    return list(db.users.find({"document_up.tags":{"$in":[tag]}}))
