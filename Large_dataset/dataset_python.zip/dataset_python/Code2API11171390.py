def set_python_version():
    pass
