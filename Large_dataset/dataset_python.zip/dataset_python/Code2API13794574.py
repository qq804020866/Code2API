from pylab import *

def plot_subplots(x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, t, N, dt, a, b, c, r):
    subplot(3,1,1)
    Func = a
    Integrator(x1,x2,x3,x4,t,N,Func,dt)
    ylabel('x(t)') # set y-axis label
    title(str(Func.func_name) + ': Pitchfork ODE at r= ' + str(r)) # set plot title
    axis([0.0,dt*(N+1),-2.0,2.0])
    # Plot the time series
    plot(t,x1,'b')
    plot(t,x2,'r')
    plot(t,x3,'g')
    plot(t,x4,'m')

    subplot(212)
    Func = b
    Integrator(x5,x6,x7,x8,t,N,Func,dt)
    ylabel('x(t)') # set y-axis label
    title(str(Func.func_name) + ': Pitchfork ODE at r= ' + str(r)) # set plot title
    axis([0.0,dt*(N+1),-2.0,2.0])
    # Plot the time series
    plot(t,x5,'b')
    plot(t,x6,'r')
    plot(t,x7,'g')
    plot(t,x8,'m')

    subplot(3,1,3)
    Func = c
    Integrator(x9,x10,x11,x12,t,N,Func,dt)
    xlabel('Time t') # set x-axis label
    ylabel('x(t)') # set y-axis label
    title(str(Func.func_name) + ': Pitchfork ODE at r= ' + str(r)) # set plot title
    axis([0.0,dt*(N+1),-2.0,2.0])
    # Plot the time series
    plot(t,x9,'b')
    plot(t,x10,'r')
    plot(t,x11,'g')
    plot(t,x12,'m')
