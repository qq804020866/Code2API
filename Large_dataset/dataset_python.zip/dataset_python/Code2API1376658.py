import re

def extract_string(start_str, end_str, main_str):
    r = re.compile(start_str + '(.*?)' + end_str)
    m = r.search(main_str)
    if m:
        return m.group(1)
