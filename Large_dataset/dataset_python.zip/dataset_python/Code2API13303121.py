def access_class_variable(test, a_string):
    return getattr(test, a_string)
