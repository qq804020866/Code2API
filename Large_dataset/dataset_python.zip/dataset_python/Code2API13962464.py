def break_while_loop(i, x):
    while i<=10:
        for a in range(1, x+1):
            print("ok")
            i+=1
            if i > 10:
                break
