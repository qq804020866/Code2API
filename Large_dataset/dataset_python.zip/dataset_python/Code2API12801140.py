from django.contrib.staticfiles.urls import staticfiles_urlpatterns

def serve_static_files_with_gunicorn():
    # ... the rest of your URLconf goes here ...
    urlpatterns += staticfiles_urlpatterns()
