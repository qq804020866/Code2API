def install_lxml():
    cd /tmp
    curl -O http://lxml.de/files/lxml-3.6.0.tgz
    tar -xzvf lxml-3.6.0.tgz 
    cd lxml-3.6.0
    python setup.py build --static-deps --libxml2-version=2.7.3  --libxslt-version=1.1.24 
    sudo python setup.py install
