def is_value_in_list(mylist, value):
    return any(value in sublist for sublist in mylist)
