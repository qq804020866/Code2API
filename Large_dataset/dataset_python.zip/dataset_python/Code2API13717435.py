import tempfile

def get_tempfile_path():
    myfile = tempfile.NamedTemporaryFile()
    myfile.write(fdf)
    myfile.seek(0)
    myfile.close()
    return myfile.name
