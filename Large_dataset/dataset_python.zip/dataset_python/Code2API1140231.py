import sys

def get_current_frame(number):
    return sys._getframe(number)
