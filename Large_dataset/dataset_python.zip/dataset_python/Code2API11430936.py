import re

def find_overlapping_matches(pattern, input_string):
    return re.findall(pattern, input_string)
