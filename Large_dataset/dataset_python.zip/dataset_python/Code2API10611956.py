def search_document_by_oid(document_id):
    return Docs.objects.get(id=document_id)
