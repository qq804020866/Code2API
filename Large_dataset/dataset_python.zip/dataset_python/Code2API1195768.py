from django.db import models

def update_many_to_many_field(correct_author_name, incorrect_author_name):
    george_author = Author.objects.get(name=correct_author_name)
    for book in Book.objects.filter(authors__name=incorrect_author_name):
        book.authors.add(george_author.id)
        book.authors.filter(name=incorrect_author_name).delete()
