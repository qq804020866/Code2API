import numpy as np
from sklearn.preprocessing import Imputer

def handle_missing_data(train, missing_values, strategy, axis):
    imp = Imputer(missing_values=missing_values, strategy=strategy, axis=axis)
    imp.fit(train)
    train_imp = imp.transform(train)
