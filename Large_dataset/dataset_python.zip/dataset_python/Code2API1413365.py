from PIL import Image

def is_gif_animated(gif_path):
    gif = Image.open(gif_path)
    try:
        gif.seek(1)
    except EOFError:
        return False
    else:
        return True
