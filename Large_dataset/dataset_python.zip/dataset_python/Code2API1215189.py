def run_program():
    script = '''
@echo off
call proc1.bat
proc2
'''
    return script
