import pygame

def display_text(text, font_size, font_color, position):
    # initialize font; must be called after 'pygame.init()' to avoid 'Font not Initialized' error
    myfont = pygame.font.SysFont("monospace", font_size)

    # render text
    label = myfont.render(text, 1, font_color)
    screen.blit(label, position)
