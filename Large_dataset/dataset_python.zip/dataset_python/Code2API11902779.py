def compare_items(all_items):
    for x, left in enumerate(all_items):
        for y, right in enumerate(all_items):
            common = len(set(left) & set(right))
            print("item%s has %s values in common with item%s" % (x, common, y))
