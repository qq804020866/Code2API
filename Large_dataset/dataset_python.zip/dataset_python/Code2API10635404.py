def print_block():
    print(unichr(0x2588))
    print(u"\u2588")
