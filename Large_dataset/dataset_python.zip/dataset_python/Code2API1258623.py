from email.utils import parsedate_tz

def parse_rfc2822_datetime(date_string):
    parsedate_tz(date_string)
