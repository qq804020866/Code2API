from Tkinter import Tk, Canvas, Frame, Button
from Tkinter import BOTH, W, NW, SUNKEN, TOP, X, FLAT, LEFT

def add_button_to_canvas(canvas, button_text):
    button = Button(canvas, text=button_text, command=canvas.quit, anchor=W)
    button.configure(width=10, activebackground="#33B5E5", relief=FLAT)
    button_window = canvas.create_window(10, 10, anchor=NW, window=button)
