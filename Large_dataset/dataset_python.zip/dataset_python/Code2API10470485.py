import numpy as np

def create_white_image():
    img = np.zeros([100,100,3],dtype=np.uint8)
    img.fill(255) # or img[:] = 255
    return img
