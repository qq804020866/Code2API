import re

def is_string_valid(input_string):
    return re.match('^[\w-]+$', input_string) is not None
