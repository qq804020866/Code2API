import unicodedata

def find_unicode_character(character):
    return [unicodedata.name(character), hex(ord(character))]
