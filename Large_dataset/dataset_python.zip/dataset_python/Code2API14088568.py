from selenium import webdriver

def execute_javascript_function(wd, code):
    return wd.execute_script("return checkdata('" + code + "');")
