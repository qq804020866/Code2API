import os

def start_background_process(command):
    os.spawnl(os.P_DETACH, command)
