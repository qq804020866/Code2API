import pylab as plt
import numpy as np

def display_numpy_array():
    Z=np.array(((1,2,3,4,5),(4,5,6,7,8),(7,8,9,10,11)))
    im = plt.imshow(Z, cmap='hot')
    plt.colorbar(im, orientation='horizontal')
    plt.show()
