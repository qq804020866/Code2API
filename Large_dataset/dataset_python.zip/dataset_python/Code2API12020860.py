from PIL import Image
import urllib2 as urllib
import io

def open_image_from_internet(image_url):
    fd = urllib.urlopen(image_url)
    image_file = io.BytesIO(fd.read())
    im = Image.open(image_file)
    return im.size
