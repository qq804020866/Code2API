import pandas

def assign_groupby_results(df, groupby_column, sum_column):
    return df.join(df.groupby(groupby_column)[sum_column].sum(), on=groupby_column, rsuffix='_r')
