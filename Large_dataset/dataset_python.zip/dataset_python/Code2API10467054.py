import nltk

def create_nltk_text(file_path):
    f = open(file_path, 'rU')
    raw = f.read()
    tokens = nltk.word_tokenize(raw)
    text = nltk.Text(tokens)
    return text
