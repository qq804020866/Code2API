from PyQt5 import QtGui

def set_default_item():
    self.appExeCB = QtGui.QComboBox()
    self.appExeCB.addItems(self.items.keys())
    self.appExeCB.setCurrentIndex(self.items.keys().index('Maya Executable'))
