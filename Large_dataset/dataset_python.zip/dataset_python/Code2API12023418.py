import serial
import time
import struct

def convert_decimal_to_16bit_integer(decimal_value):
    return struct.pack('<h', int(decimal_value))
