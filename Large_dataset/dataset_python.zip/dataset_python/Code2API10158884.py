import httplib

def get_webpage_info():
    conn = httplib.HTTPConnection("www.python.org")
    conn.request("GET", "/index.html")
    r1 = conn.getresponse()
    return r1.status, r1.reason
