import os
import signal

def kill_subprocess(pid, signal):
    os.kill(pid, signal.SIGKILL)
