import bcrypt

def compare_passwords(plain_password, stored_hash):
    return hashed == bcrypt.hashpw(plain_password, stored_hash)
