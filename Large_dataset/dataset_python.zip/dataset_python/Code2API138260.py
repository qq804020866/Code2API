from PIL import Image

def get_pixel_rgb(image_path, pixel_coordinates):
    im = Image.open(image_path)
    pix = im.load()
    return pix[pixel_coordinates]
