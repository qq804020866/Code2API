def parse_avro_schema(avro_schema):
    mySchema = avro_schema
