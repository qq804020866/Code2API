def install_modules_via_requirements():
    return "-r{toxinidir}/tools/pip-requires\n-r{toxinidir}/tools/test-requires"
