import os
import shutil

def copy_file_with_directory(srcfile, dstroot):
    assert not os.path.isabs(srcfile)
    dstdir = os.path.join(dstroot, os.path.dirname(srcfile))
    os.makedirs(dstdir)
    shutil.copy(srcfile, dstdir)
