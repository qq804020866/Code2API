import re

def search_pattern_in_file(file_path):
    pattern = re.compile("<(\d{4,5})>")
    for i, line in enumerate(open(file_path)):
        for match in re.finditer(pattern, line):
            print('Found on line %s: %s' % (i+1, match.group()))
