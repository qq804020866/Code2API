from subprocess import Popen, PIPE

def run_swfdump_command():
    process = Popen(['swfdump', '/tmp/filename.swf', '-d'], stdout=PIPE, stderr=PIPE)
    stdout, stderr = process.communicate()
    return stdout, stderr
