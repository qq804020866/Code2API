def restart_group_programs():
    return "supervisorctl restart tapjoy:*"
