import sys

def import_file_from_parent(path_to_parent):
    sys.path.append(path_to_parent)
    import parent.file1
