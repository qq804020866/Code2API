def select_rows_columns(level_0_value, level_1_value, level_2_value):
    metals.xs(level_0_value, level=0).xs(level_1_value, level=0).xs(level_2_value, level=1)
    metals.xs(level_0_value, level='bmp_category').xs(level_1_value, level='parameter').xs(level_2_value, level='storm')
    metals.ix[level_0_value, level_1_value].ix[:, level_2_value]
