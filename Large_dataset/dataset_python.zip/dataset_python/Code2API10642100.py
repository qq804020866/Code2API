import numpy as np

def get_cdf(data, width, height):
    histo = np.zeros(4096, dtype = np.int32)
    for x in range(0, width):
        for y in range(0, height):
            histo[data[x][y]] += 1
            q = 0 
    cdf = list()
    for i in histo:
        q = q + i
        cdf.append(q)
    return np.cumsum(hist)
