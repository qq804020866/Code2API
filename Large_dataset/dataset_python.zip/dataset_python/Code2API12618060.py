def replace_backslash(string):
    return string.replace("\\","")
