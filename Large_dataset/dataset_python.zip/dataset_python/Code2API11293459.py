from django.db import IntegrityError
from django.shortcuts import render_to_response

def catch_integrity_error():
    try:
        # code that produces error
    except IntegrityError as e:
        return render_to_response("template.html", {"message": e.message})
