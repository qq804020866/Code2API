import time

def stop_while_loop():
    timeout = time.time() + 60*5   # 5 minutes from now
    while True:
        test = 0
        if test == 5 or time.time() > timeout:
            break
        test = test - 1
