from matplotlib import pyplot as plt

def remove_xticks():
    plt.plot(range(10))
    plt.tick_params(
        axis='x',          # changes apply to the x-axis
        which='both',      # both major and minor ticks are affected
        bottom=False,      # ticks along the bottom edge are off
        top=False,         # ticks along the top edge are off
        labelbottom=False) # labels along the bottom edge are off
    plt.show()
    plt.savefig('plot')
    plt.clf()
