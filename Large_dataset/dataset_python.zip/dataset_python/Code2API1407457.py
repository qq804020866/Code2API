def regex_match_with_unknown_groups(input_string):
    a = input_string.split()
    if a[0] == "VALUE":
        return [int(x) for x in a[1:]]
