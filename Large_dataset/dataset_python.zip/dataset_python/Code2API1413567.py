from PIL import Image

def show_image(image_path):
    img = Image.open(image_path)
    img.show()
