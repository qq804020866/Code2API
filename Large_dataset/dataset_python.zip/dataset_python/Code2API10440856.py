import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

def add_variable_to_xlabel(entries):
    plt.ylabel('Percentage', fontproperties=font_manager.FontProperties(size=10))
    plt.xlabel('position %d' % entries, fontproperties=font_manager.FontProperties(size=10))
    plt.title("'Graph-A",fontproperties=font_manager.FontProperties(size=10))

    plt.xticks(np.arange(22), np.arange(1,23), fontproperties=font_manager.FontProperties(size=8))
    plt.yticks(np.arange(0,121,5), fontproperties=font_manager.FontProperties(size=8))
    plt.legend((p1[0], p2[0], p3[0], p4[0],p5[0]), ('A','B','C','D','E'), loc=1, prop=font_manager.FontProperties(size=7))
