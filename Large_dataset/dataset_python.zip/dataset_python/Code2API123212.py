import shutil

def copy_file(src, dst):
    shutil.copyfile(src, dst)
    shutil.copy(src, dst)  # dst can be a folder; use shutil.copy2() to preserve timestamp
