import calendar
import datetime

def convert_utc_to_unix(parsed_date):
    return calendar.timegm(parsed_date.utctimetuple())
