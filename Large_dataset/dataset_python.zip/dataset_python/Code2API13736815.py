def support_item_assignment():
    pass
