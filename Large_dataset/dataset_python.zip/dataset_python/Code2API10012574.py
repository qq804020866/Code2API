import random

def generate_big_random_number():
    return random.getrandbits(128)
