def filter_items(my_list):
    return [token for token in my_list if token.isalpha()]
