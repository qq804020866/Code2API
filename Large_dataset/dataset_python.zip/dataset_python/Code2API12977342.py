def put_and_get_set(fruit, colour):
    q.put((fruit, colour))
