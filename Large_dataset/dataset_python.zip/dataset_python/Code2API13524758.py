import random

def get_random_document(collection_name, mongodb):
    collection = mongodb[collection_name]
    rand = random.random()  # rand will be a floating point between 0 to 1.
    random_record = collection.find_one({ 'random': { '$gte': rand } })
    return random_record
