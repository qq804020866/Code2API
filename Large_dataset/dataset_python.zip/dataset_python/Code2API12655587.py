import sys
from PySide.QtGui import *

def set_widget_background_color(w, color):
    p = w.palette()
    p.setColor(w.backgroundRole(), color)
    w.setPalette(p)
