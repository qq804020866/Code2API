import numpy as np

def is_array_empty(array):
    return array.size == 0
