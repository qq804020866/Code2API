from six import string_types

def is_string(var):
    return isinstance(var, string_types)
