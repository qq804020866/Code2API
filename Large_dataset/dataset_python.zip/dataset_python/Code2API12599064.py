import numpy as np
import matplotlib.pyplot as plt

def maximize_plot_window():
    mng = plt.get_current_fig_manager()
    mng.frame.Maximize(True)

data = np.random.exponential(scale=180, size=10000)
print('el valor medio de la distribucion exponencial es: ')
print(np.average(data))
plt.hist(data, bins=len(data)**0.5, normed=True, cumulative=True, facecolor='red', label='datos tamano paqutes acumulativa', alpha=0.5)
plt.legend()
plt.xlabel('algo')
plt.ylabel('algo')
plt.grid()
maximize_plot_window()
plt.show()
