def explain_bitwise_operations():
    return "11011 is not -11. You have a misunderstanding of the encoding scheme for negative numbers.\n\nIn two's complement, -11 is 10101 which is the correct bit inversion.\n\nTo negate a two's complement number, you invert all bits and add one:\n\n01011 eleven\n10100 invert\n10101 add one gives negative eleven"
