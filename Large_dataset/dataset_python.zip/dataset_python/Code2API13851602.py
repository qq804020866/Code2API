def delete_rows_based_on_condition(df, column_name):
    return df[df[column_name].map(len) < 2]
