import boto

def copy_large_file():
    s3 = boto.connect_s3('access', 'secret')
    b = s3.get_bucket('destination_bucket')
    mp = b.initiate_multipart_upload('tmp/large-copy-test.mp4')
    mp.copy_part_from_key('source_bucket', 'path/to/source/key', 1, 0, 999999999)
    mp.copy_part_from_key('source_bucket', 'path/to/source/key', 2, 1000000000, 1999999999)
    mp.copy_part_from_key('source_bucket', 'path/to/source/key', 3, 2000000000, 2999999999)
    mp.copy_part_from_key('source_bucket', 'path/to/source/key', 4, 3000000000, 3999999999)
    mp.copy_part_from_key('source_bucket', 'path/to/source/key', 5, 4000000000, 4999999999)
    mp.copy_part_from_key('source_bucket', 'path/to/source/key', 6, 5000000000, 5500345712)
    mp.complete_upload()
