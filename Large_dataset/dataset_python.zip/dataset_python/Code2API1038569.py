from PIL import Image

def generate_image_from_data(width, height, pixel_values):
    img = Image.new('RGB', (width, height))
    img.putdata(pixel_values)
    img.save('image.png')
