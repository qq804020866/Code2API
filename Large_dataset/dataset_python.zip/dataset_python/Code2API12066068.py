def str_to_single_element_list(var_1):
    return [var_1]
