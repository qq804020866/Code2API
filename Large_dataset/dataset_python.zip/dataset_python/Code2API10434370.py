def set_python3_as_default():
    pass
