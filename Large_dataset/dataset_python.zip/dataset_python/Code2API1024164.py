import urlparse

def parse_qs_fix(qsdata):
    return dict( (k, v if len(v)>1 else v[0] ) for k, v in urlparse.parse_qs(qsdata).iteritems() )
