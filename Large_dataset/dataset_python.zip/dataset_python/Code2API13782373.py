from pydub import AudioSegment

def mix_audio_files(file1_path, file2_path):
    sound1 = AudioSegment.from_mp3(file1_path)
    sound2 = AudioSegment.from_mp3(file2_path)
    
    # mix sound2 with sound1, starting at 5000ms into sound1)
    output = sound1.overlay(sound2, position=5000)
    
    # save the result
    output.export("mixed_sounds.mp3", format="mp3")
