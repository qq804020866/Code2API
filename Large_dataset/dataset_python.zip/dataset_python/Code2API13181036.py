def break_while_loop():
    try:
        while True:
            do_something()
    except KeyboardInterrupt:
        pass
