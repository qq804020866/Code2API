from lxml import etree
import urllib.request

def extract_tables_from_website():
    web = urllib.request.urlopen("http://www.ffiec.gov/census/report.aspx?year=2011&state=01&report=demographic&msa=11500")
    s = web.read()

    html = etree.HTML(s)

    ## Get all 'tr'
    tr_nodes = html.xpath('//table[@id="Report1_dgReportDemographic"]/tr')

    ## 'th' is inside first 'tr'
    header = [i[0].text for i in tr_nodes[0].xpath("th")]

    ## Get text from rest all 'tr'
    td_content = [[td.text for td in tr.xpath('td')] for tr in tr_nodes[1:]]

    return td_content
