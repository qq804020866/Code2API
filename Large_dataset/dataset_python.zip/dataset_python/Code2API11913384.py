import boto.sqs

def get_receive_count(c, q, num_messages):
    messages = c.receive_message(q, num_messages=num_messages, attributes='All')
    return messages[0].attributes['ApproximateReceiveCount']
