def check_multiple_choices(choice):
    while choice not in [1, 2, 3]:
        choice = raw_input("pick 1, 2 or 3")

        if choice == "1":
            print "1 it is!"

        elif choice == "2":
            print "2 it is!"

        elif choice == "3":
            print "3 it is!"

        else:
            print "You should choose 1, 2 or 3"
