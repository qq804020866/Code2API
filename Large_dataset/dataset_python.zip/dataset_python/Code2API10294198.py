def access_meteor_mongodb():
    pass
