import pytz, datetime

def get_timezone_info():
    tz = pytz.timezone("Asia/Calcutta")
    return tz, tz.localize(datetime.datetime(1901, 7, 10, 12, 0)), tz.localize(datetime.datetime(2012, 7, 10, 12, 0))
