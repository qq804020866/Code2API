import pandas as pd

def filter_csv(file_path, column_name, constant):
    iter_csv = pd.read_csv(file_path, iterator=True, chunksize=1000)
    return pd.concat([chunk[chunk[column_name] > constant] for chunk in iter_csv])
