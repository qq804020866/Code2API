from xml.etree.ElementTree import parse, tostring

def replace_xml_element_text(file_path, new_value):
    doc = parse(file_path)
    elem = doc.findall('original_spoken_locale')[0]
    elem.text = new_value
    return tostring(doc.getroot())
