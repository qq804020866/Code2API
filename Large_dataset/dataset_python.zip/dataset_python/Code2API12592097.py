from urllib.request import urlopen
import mechanize

def download_file(remote_file_path, local_file_path):
    f = open(local_file_path, 'w')
    f.write(urlopen(remote_file_path).read())
    f.close()
