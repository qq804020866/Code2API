import requests

def simulate_http_post_request():
    URL = 'https://www.yourlibrary.ca/account/index.cfm'
    payload = {
        'barcode': 'your user name/login',
        'telephone_primary': 'your password',
        'persistent': '1'  # remember me
    }

    session = requests.session()
    r = requests.post(URL, data=payload)
    return r.cookies
