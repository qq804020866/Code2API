import numpy
import pylab

def imshow_with_rescaled_axes(SLP, ff, AA):
    pylab.imshow(SLP, aspect='auto', origin='lower', extent=(ff.min(), ff.max(), AA.min(), AA.max()))
