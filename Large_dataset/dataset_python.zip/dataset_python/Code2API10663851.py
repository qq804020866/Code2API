import datetime
import time

def convert_time_to_seconds(time_string):
    x = time.strptime(time_string.split(',')[0],'%H:%M:%S')
    return datetime.timedelta(hours=x.tm_hour,minutes=x.tm_min,seconds=x.tm_sec).total_seconds()
