def find_os_py_file():
    return [
        "/home/blah/scratch/bin/lib/pythonX.Y/os.py",
        "/home/blah/scratch/lib/pythonX.Y/os.py",
        "/home/blah/lib/pythonX.Y/os.py",
        "/home/lib/pythonX.Y/os.py",
        "/lib/pythonX.Y/os.py"
    ]
