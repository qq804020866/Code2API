import numpy as np
import matplotlib.pyplot as plt

def stretch_image_width(A, interpolation):
    plt.imshow(A, interpolation=interpolation, aspect='auto')
