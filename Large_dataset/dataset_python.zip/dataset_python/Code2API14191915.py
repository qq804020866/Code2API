from datetime import datetime, timedelta

def calculate_week_difference(date1, date2):
    monday1 = (date1 - timedelta(days=date1.weekday()))
    monday2 = (date2 - timedelta(days=date2.weekday()))

    return (monday2 - monday1).days / 7
