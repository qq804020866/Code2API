import sys

def import_custom_module():
    sys.path.insert(0, 'your_path_here')
    import custom_module
