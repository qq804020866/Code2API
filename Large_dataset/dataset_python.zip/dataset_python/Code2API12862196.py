import pandas as pd

def pivot_table_unique_count(df2, values, index, columns, aggfunc):
    return df2.pivot_table(values=values, index=index, columns=columns, aggfunc=aggfunc)
