def append_lists(data):
    month_list = []
    year_list = []
    lists = [month_list, year_list]
    dict = {0 : year_list, 1:month_list}

    for i, values in enumerate(data[:2]):
        dict[i].append(values)

    print('month_list - ', month_list[0])
    print('year_list - ', year_list[0])
