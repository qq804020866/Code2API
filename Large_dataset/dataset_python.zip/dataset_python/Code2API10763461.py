def install_python3_package():
    return """
virtualenv -p /usr/bin/python3 py3env
source py3env/bin/activate
pip install package-name
"""
