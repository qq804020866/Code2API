from subprocess import Popen, PIPE

def ffmpeg_conversion(input_file, output_file):
    p = Popen(["ffmpeg", "-i", "-", "-f", "matroska", "-vcodec", "mpeg4",
               "-acodec", "aac", "-strict", "experimental", "-"],
              stdin=input_file, stdout=PIPE)
    while True:
        data = p.stdout.read(1024)
        if len(data) == 0:
            break
        # do something with data...
        print(data)
    print(p.wait()) # should have finished anyway
