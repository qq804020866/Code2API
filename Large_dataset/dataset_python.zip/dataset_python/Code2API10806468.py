def get_tweet_ids():
    for status in api.user_timeline():
        print(status.id)
