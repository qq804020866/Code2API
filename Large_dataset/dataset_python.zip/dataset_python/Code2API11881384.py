import urllib3
import requests
import json

def trigger_jenkins_job(jenkins_url, username, password, file_path, file_param_name):
    url = jenkins_url

    params = {"parameter": [
        {"name": "integration.xml", "file": file_param_name},
    ]}
    with open(file_path, "rb") as f:
        file_data = f.read()
    data, content_type = urllib3.encode_multipart_formdata([
        (file_param_name, (f.name, file_data)),
        ("json", json.dumps(params)),
        ("Submit", "Build"),
    ])
    resp = requests.post(url, auth=(username, password), data=data,
            headers={"content-type": content_type}, verify=False)
    resp.raise_for_status()
