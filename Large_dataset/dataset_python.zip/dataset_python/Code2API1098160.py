import icu

def sort_unicode_strings(strings):
    collator = icu.Collator.createInstance(icu.Locale('de_DE.UTF-8'))
    return sorted(strings, key=collator.getSortKey)
