def install_python_xlib():
    return "sudo pip install svn+https://svn.code.sf.net/p/python-xlib/code/trunk/"
