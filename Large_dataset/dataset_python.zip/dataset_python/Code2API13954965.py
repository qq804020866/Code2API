def convert_line_breaks(file_name):
    f = open(file_name, 'rU')
