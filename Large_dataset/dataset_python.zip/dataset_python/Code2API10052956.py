import operator

def sort_dict_by_attribute(obj_dict, attribute):
    for student in (sorted(obj_dict.values(), key=operator.attrgetter(attribute))):
        print(student.name)
