from jinja2 import Template

def output_loop_counter(elements):
    s = "{% for element in elements %}{{loop.index}} {% endfor %}"
    return Template(s).render(elements=elements)
