from mpl_toolkits.mplot3d import Axes3D

def set_camera_position(fig, xx, yy, zz):
    ax = Axes3D(fig)
    ax.scatter(xx, yy, zz, marker='o', s=20, c="goldenrod", alpha=0.6)
    for ii in range(0, 360, 1):
        ax.view_init(elev=10., azim=ii)
        savefig("movie%d.png" % ii)
