import ast

def read_dictionary_from_file(file_path):
    with open(file_path, "r") as data:
        return ast.literal_eval(data.read())
