import tornado.web
import tornado.httpserver

def run_tornado_server(application, settings, port):
    http_server = tornado.httpserver.HTTPServer(application)
    http_server.listen(port, address='127.0.0.1')
