def remove_spaces(string):
    return string.strip()
