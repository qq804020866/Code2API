import os

def make_relative_file_path():
    return os.path.join(os.path.dirname(__file__), 'test.txt')
