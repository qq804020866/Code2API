from gevent import monkey; monkey.patch_all()
from gevent.wsgi import WSGIServer

from django.core.management import setup_environ    
import settings
setup_environ(settings)

from django.core.handlers.wsgi import WSGIHandler as DjangoWSGIApp

def run_django_with_gevent():
    application = DjangoWSGIApp()
    server = WSGIServer(("127.0.0.1", 1234), application)
    print "Starting server on http://127.0.0.1:1234"
    server.serve_forever()
