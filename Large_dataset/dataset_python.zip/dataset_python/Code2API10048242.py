import marshal
import types

def unpickle_functions(file_path, sandbox):
    with open(file_path, "rb") as funcfile:
        while True:
            try:
                code = marshal.load(funcfile)
            except EOFError:
                break
            sandbox[code.co_name] = types.FunctionType(code, sandbox, code.co_name)
