def is_running_on_dev_server(request):
    server = request.META.get('wsgi.file_wrapper', None)
    return server is not None and server.__module__ == 'django.core.servers.basehttp'
