import numpy as np

def convert_points_to_image_array(coordinates):
    x, y = [i[0] for i in coordinates], [i[1] for i in coordinates]
    max_x, max_y = max(x), max(y)

    image = np.zeros((max_y + 1, max_x + 1))

    for i in range(len(coordinates)):
        image[max_y - y[i], x[i]] = 1

    return image
