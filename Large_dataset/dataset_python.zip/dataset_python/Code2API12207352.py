import pandas

def compute_histogram(my_series):
    return dict(my_series.value_counts())
