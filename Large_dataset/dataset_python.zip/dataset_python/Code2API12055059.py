def get_request_referrer(response):
    return response.request.headers.get('Referer', None)
