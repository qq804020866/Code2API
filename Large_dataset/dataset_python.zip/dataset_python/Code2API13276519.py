from PyPDF2 import PdfReader

def add_image_to_pdf(document_path, overlay_path):
    page = PdfReader(document_path).pages[0]
    overlay = PdfReader(overlay_path).pages[0]
    page.merge_page(overlay)
