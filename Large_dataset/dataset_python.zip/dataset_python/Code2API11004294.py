from bottle import run

def run_server_with_reloader():
    run(reloader=True)
