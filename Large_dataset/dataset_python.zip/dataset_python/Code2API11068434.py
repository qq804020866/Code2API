import os.path

def is_symlink(file_path):
    return os.path.islink(file_path)
