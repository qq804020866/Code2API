import json, re
from bson import json_util

def transform_tengenjson(file_path):
    with open(file_path, "rb") as f:
        bsondata = f.read()

        jsondata = re.sub(r'ObjectId\s*\(\s*\"(\S+)\"\s*\)',
                          r'{"$oid": "\1"}',
                          bsondata)
        jsondata = re.sub(r'Date\s*\(\s*(\S+)\s*\)',
                          r'{"$date": \1}',
                          jsondata)

        data = json.loads(jsondata, object_hook=json_util.object_hook)

        print(data)
        print(type(data))

        print(json_util.dumps(data))
