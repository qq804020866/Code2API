from scipy import stats

def create_equal_bins(data, nbins):
    return stats.mstats.mquantiles(data, [0, 2./nbins, 4./nbins, 1])
