from tkinter import *

def delete_widgets():
    root = Tk()

    b = Button(root, text="Delete me", command=lambda: b.pack_forget())
    b.pack()

    root.mainloop()
