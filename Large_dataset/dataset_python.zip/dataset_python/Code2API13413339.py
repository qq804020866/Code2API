from socket import gethostbyname, gaierror

def catch_exception():
    pass
