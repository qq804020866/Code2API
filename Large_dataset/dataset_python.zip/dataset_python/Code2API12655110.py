from sage.plot.plot import list_plot

def add_labels_legend_title(myplot, myplot2, x_label, y_label, legend_label1, legend_label2, title, frame, legend_loc):
    myplot = list_plot(
        zip(range(20), range(20)), 
        color='red', 
        legend_label=legend_label1)

    myplot2 = list_plot(
        zip(range(20), [i*2 for i in range(20)]), 
        color='blue', 
        legend_label=legend_label2)

    combined = myplot + myplot2

    combined.axes_labels([x_label, y_label])
    combined.legend(True)

    combined.show(title=title, frame=frame, legend_loc=legend_loc)
