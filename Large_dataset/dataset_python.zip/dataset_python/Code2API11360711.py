def create_dictionary_in_loop(data):
    listofobjs = []
    for x in data:
        d = {
          'a_data': x.a,
          'b_data':model_obj.address,
          'c_data':x.c,
          'd_data':x.d,
        }
        listofobjs.append(d)
    return listofobjs
