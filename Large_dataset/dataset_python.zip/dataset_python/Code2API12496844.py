import example.config

def override_constant():
    example.config.CONSTANT = "Better value"

    from example import examplemod
    examplemod.do_stuff()
    # desired result!
