import sys
import foo

def import_egg_library():
    sys.path.append("library1.egg")
    import foo
