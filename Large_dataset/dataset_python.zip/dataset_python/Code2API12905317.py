import matplotlib.pyplot as plt

def show_plot():
    plt.show()
