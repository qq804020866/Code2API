import asizeof

def get_bytes_per_element(data):
    return asizeof.asizeof(data) / len(data)
