def set_celery_task_always_eager():
    CELERY_TASK_ALWAYS_EAGER = True
    # use this if you are on older versions of celery
    # CELERY_ALWAYS_EAGER = True
