from a import *

def import_all_variables():
    if name == "Michael" and age == 15:
        print('Simple!')
