import codecs

def rot13_encode(input_string):
    enc = codecs.getencoder("rot-13")
    return enc(input_string)[0]
