import datetime
import calendar

def get_events_in_specific_month():
    year = 2012
    month = 6

    num_days = calendar.monthrange(year, month)[1]
    start_date = datetime.date(year, month, 1)
    end_date = datetime.date(year, month, num_days)

    results = session.query(Event).filter(and_(Event.date >= start_date, Event.date <= end_date)).all()
    return results
