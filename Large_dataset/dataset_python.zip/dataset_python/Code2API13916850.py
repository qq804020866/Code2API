def install_specific_version():
    return "pip install django_modeltranslation==0.4.0-beta2"
