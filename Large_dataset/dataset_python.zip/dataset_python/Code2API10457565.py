import subprocess
import time

def close_program():
    while 1:
        subprocess.call("TASKKILL /F /IM firefox.exe", shell=True)
        time.sleep(10)
