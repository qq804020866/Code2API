def evaluate_string(eval_string):
    try:
        eval(eval_string)
    except SyntaxError:
        exec(eval_string)
