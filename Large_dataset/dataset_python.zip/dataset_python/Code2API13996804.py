from django.core.validators import validate_email
from django import forms

def validate_email_input(request, email_input):
    if request.method == "POST":
        try:
            validate_email(request.POST.get(email_input, ""))
        except forms.ValidationError:
            pass
