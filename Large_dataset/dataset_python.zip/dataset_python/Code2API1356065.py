def print_aligned_columns(name, price):
    print "Name: %-20s Price: %10d" % (name, price)
