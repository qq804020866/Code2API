import numpy

def customize_matrix_output():
    numpy.set_printoptions(formatter={'float': lambda x: 'float: ' + str(x)})
