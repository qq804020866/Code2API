import nltk
from nltk import bigrams, trigrams

def calculate_ngram_counts(text):
    tokens = nltk.word_tokenize(text)
    tokens = [token.lower() for token in tokens if len(token) > 1]
    bi_tokens = bigrams(tokens)
    tri_tokens = trigrams(tokens)

    return [(item, tri_tokens.count(item)) for item in sorted(set(tri_tokens))]
