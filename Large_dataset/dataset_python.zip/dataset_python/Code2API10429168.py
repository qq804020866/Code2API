def install_packages_from_requirements(requirements_path, archive_path):
    command = f"pip install -r {requirements_path} --no-index --find-links {archive_path}"
    # Execute the command using subprocess or os.system
