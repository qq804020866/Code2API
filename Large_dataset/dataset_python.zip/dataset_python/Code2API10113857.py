from BeautifulSoup import BeautifulSoup

def find_text_in_paragraphs(html_content):
    VALID_TAGS = ['div', 'p']
    soup = BeautifulSoup(html_content)
    for tag in soup.findAll('p'):
        if tag.name not in VALID_TAGS:
            tag.replaceWith(tag.renderContents())
    return soup.renderContents()
