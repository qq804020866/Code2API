from urllib.parse import quote
from urllib.request import urlopen

def encode_url(url_path):
    url = 'http://zh.wikipedia.org/wiki/' + quote(url_path)
    content = urlopen(url).read()
    return content
