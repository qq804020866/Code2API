def compare_startswith_vs_index():
    pass
