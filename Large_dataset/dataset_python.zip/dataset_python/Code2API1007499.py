def replace_whitespace_with_underscore(mystring):
    return mystring.replace(" ", "_")
