from collections import deque

def get_deque_length(queue):
    return len(queue)
