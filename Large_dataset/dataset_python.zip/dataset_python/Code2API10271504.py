def element_wise_multiplication(list_a, list_b):
    return [a*b for a,b in zip(list_a,list_b)]
