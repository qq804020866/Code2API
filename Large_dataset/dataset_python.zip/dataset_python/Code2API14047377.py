import sqlite3

def fetch_integer_values():
    conn = sqlite3.connect("growll.db")
    cursor = conn.cursor()

    print("\nHere's a listing of all the records in the table:\n")
    cursor.execute("select lchar from GrowLLDados")    

    return [int(record[0]) for record in cursor.fetchall()]
