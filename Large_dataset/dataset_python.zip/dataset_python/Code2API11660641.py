import os
import shutil

def overwrite_folder():
    dir = 'path_to_my_folder'
    if os.path.exists(dir):
        shutil.rmtree(dir)
    os.makedirs(dir)
