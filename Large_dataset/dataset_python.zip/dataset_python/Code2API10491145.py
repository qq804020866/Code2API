def encode_unicode(unicode_string):
    return unicode_string.encode("utf-8") == "ひらがな"
