from selenium import webdriver

def get_element_contents(driver, element_id):
    element = driver.find_element_by_id(element_id)
    element_text = element.text
    element_attribute_value = element.get_attribute('value')
    return element_text, element_attribute_value
