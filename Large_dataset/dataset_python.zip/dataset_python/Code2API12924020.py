def move_first_letter_to_end(word):
    return word[1:] + word[0]
