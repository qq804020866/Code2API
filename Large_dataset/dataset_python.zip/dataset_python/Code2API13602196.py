def distance_between_values(x, y):
    return abs(x-y)
