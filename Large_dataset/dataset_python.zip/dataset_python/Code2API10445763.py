from __future__ import print_function

def print_to_file(file_path, text):
    with open(file_path, 'w') as f:
        print(text, file=f)
