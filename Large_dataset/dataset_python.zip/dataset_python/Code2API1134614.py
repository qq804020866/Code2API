def get_errno():
    try:
        fp = open("nothere")
    except IOError as e:
        return e.errno, e
