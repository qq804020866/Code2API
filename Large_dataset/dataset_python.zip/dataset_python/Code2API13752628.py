import re

def filter_emoji(mytext, highpoints):
    mytext = highpoints.sub(u'\u25FD', mytext)
    return mytext
