import textwrap

def preserve_line_breaks(text):
    w = textwrap.TextWrapper(width=90, break_long_words=False, replace_whitespace=False)
    return w
