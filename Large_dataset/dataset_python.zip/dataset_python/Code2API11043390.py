import tempfile

def create_temp_files():
    tf = tempfile.NamedTemporaryFile()  
    return tf.name
