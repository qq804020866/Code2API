def selective_escape(test, sentence):
    selectiveEscape = "Print percent %% in sentence and not %s" % test
    return selectiveEscape

test = "have it break."
sentence = "Print percent % in sentence and not %s" % test
print(selective_escape(test, sentence))
