import numpy as np

def convert_3d_to_2d(array_3d):
    return array_3d.reshape(2,2,2,2).swapaxes(1,2).reshape(4,-1)
