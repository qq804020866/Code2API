def split_string_list(string_list):
    return dict(s.split('=') for s in string_list)
