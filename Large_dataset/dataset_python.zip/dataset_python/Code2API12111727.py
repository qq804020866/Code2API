def get_full_ip_header(myPacket):
    return str(myPacket)[:(myPacket[IP].ihl * 4)]
