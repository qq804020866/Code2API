def export_print_to_txt():
    pass
