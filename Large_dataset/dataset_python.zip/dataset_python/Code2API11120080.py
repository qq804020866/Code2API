def get_canvas_background_color():
    return myCanvas['background']
