import matplotlib.pyplot as plt

def hide_subplot_axes():
    hf, ha = plt.subplots(3,2)
    ha[-1, -1].axis('off')

    plt.show()
