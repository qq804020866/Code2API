import subprocess

def run_subprocess(cmd):
    process = subprocess.Popen(cmd, shell=True,
                               stdout=subprocess.PIPE, 
                               stderr=subprocess.PIPE)
    out, err = process.communicate()
    errcode = process.returncode
    return out, err, errcode
