import subprocess

def start_daemon_process(executable):
    DETACHED_PROCESS = 8
    subprocess.Popen(executable, creationflags=DETACHED_PROCESS, close_fds=True)
