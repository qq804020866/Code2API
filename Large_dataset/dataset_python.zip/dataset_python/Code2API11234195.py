from sqlalchemy import MetaData

def clean_database(engine, metadata):
    for tbl in reversed(metadata.sorted_tables):
        engine.execute(tbl.delete())
