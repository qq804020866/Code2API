def combine_columns(df, source_years, column_name):
    df[column_name] = df[column_name].where(source_years!=0, df[column_name])
    return df
