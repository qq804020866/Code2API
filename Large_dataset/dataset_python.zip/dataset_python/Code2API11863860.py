def voxelize_mesh(triangles, cubes):
    for triangle in triangles:
        for cube in cubes:
            if triangle_intersects_cube(triangle, cube):
                set_cube_to_full(cube)
            else:
                set_cube_to_empty(cube)
