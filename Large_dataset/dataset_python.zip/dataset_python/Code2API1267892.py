from __future__ import division

def force_float_division():
    a = 4
    b = 6
    c = a / b
    return c
