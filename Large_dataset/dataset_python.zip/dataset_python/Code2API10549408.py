def remove_duplicates(a, b):
    [b.append(item) for item in a if item not in b]
