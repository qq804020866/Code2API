import time

def parse_timezone(time_string):
    gmt_offset_str = time_string[-3:]
    gmt_offset_seconds = int(gmt_offset_str)*60*60
    timestamp = time.strptime(time_string[:-4], '%Y-%m-%d %H:%M:%S')
    return time.localtime(time.mktime(timestamp)-gmt_offset_seconds)
