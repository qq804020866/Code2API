def add_to_pythonpath(path_to_modules):
    export PYTHONPATH=$PYTHONPATH:path_to_modules
