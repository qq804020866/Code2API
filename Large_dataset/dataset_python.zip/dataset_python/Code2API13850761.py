from PyQt4 import QtGui

def is_dialog_visible():
    myDialog = QtGui.QDialog()
    return myDialog.isVisible()
