from collections import namedtuple

def get_namedtuple_name():
    ham = namedtuple('eggs', 'x, y, z')
    return type(ham).__name__
