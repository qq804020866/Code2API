import cherrypy

def configure_ip_address():
    cherrypy.server.socket_host = 'www.machinename.com'
    cherrypy.engine.start()
    cherrypy.engine.block()
