import httplib

def send_head_request(host, path):
    conn = httplib.HTTPConnection(host)
    conn.request("HEAD", path)
    res = conn.getresponse()
    return res.status, res.reason, res.getheaders()
