import oauth2 as oauth
import time
import urllib2 as urllib

def post_or_put_me(action, xml, url):
    echo_base_url = 'http://pilot.echo360.com/ess/scheduleapi/v1'

    consumer = oauth.Consumer(key='xxxxx', secret='xxxx')
    client = oauth.Client(consumer)
    params = xml

    resp, content = client.request(
        echo_base_url + url,
        method=action,
        body=params,
        headers={'Content-type': 'application/xml'}
        #force_auth_header=True
    )
    return resp, content

action = "PUT"
xml = "<person><first-name>Jon</first-name><last-name>Doe</last-name><title>Super  Hero</title><email-address>[email protected]</email-address><block-alerts>false</block-alerts><time-zone>US/Eastern</time-zone><locale>en_US</locale><credentials><user-name>[email protected]</user-name><password>password</password></credentials><organization-roles><organization-role><organization-id>b1973c39-dc76-4cab-a4aa-3f9efd628df2</organization-id><role>role-name-admin</role></organization-role></organization-roles></person>"
url = "/people/"

resp, content = post_or_put_me(action, xml, url)
print(resp, content)
