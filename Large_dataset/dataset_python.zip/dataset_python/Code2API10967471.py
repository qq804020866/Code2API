from PIL import Image
from matplotlib import cm

def convert_array_to_colored_PIL_image(array):
    return Image.fromarray(np.uint8(cm.gist_earth(array)*255))
