def extract_jar():
    # Change directory to the target directory and extract the jar file
    os.system("cd /where/you/want/it; jar xf /path/to/jarfile.jar")
