def enumerate_properties(the_object):
    for property, value in vars(the_object).items():
        print(property, ":", value)
