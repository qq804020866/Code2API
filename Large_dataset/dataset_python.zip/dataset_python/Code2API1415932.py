import re

def get_pattern_string():
    p = re.compile('my pattern')
    return p.pattern
