def increase_available_sockets():
    pass
