from xml.etree.ElementTree import Element

def append_to_xml(existing_xml, username, password, new_group):
    existing_xml.append(Element.fromstring('<user username="{}" password="{}"><group>{}</group></user>'.format(username, password, new_group)))
