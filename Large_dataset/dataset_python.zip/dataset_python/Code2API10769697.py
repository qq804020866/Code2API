def remove_repeated_elements(vector):
    return unique(vector)
