import subprocess

def run_piped_command(command, input):
    proc = subprocess.Popen(
        command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    stdout_value, stderr_value = proc.communicate(input)
    return stdout_value, stderr_value
