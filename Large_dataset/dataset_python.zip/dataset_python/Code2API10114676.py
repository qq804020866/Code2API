import numpy

def set_empty_points_to_white(my_data):
    my_data[my_data == 0.0] = numpy.nan
    return my_data
