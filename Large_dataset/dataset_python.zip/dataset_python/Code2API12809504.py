import subprocess

def get_grep_output(pattern, file_path):
    hosts_process = subprocess.Popen(['grep', pattern, file_path], stdout=subprocess.PIPE)
    hosts_out, hosts_err = hosts_process.communicate()
    return hosts_out, hosts_err
