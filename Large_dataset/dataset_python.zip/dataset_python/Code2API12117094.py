def create_dict_from_another_dict(original_dict, keys_list):
    return {x:original_dict[x] for x in keys_list}
