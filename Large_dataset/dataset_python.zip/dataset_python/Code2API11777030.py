import pylab as plt
import numpy as np

def plot_2D_array():
    Z=np.array((range(1,30),range(31,60),range(61,90))).transpose()

    X,Y=np.meshgrid(range(Z.shape[0]+1),range(Z.shape[1]+1))
    im = plt.pcolormesh(X,Y,Z.transpose(), cmap='hot')
    plt.colorbar(im, orientation='horizontal')
    plt.show()
