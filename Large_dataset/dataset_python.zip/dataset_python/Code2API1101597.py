from dateutil.parser import parse

def parse_date_with_timezone(date_string):
    return parse(date_string)
