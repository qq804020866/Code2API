def evaluate_assignment():
    a, b = 5 + 4, 5
    print(a, b)
