from PIL import Image

def create_empty_png(n, m):
    image = Image.new('RGB', (n, m))
    return image
