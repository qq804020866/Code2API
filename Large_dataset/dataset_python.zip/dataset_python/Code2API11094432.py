def convert_unicode():
    return '\u84b8\u6c7d\u5730'.decode('unicode-escape')
