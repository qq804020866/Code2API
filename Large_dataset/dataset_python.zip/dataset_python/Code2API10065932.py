def document_method_with_parameters(method_name):
    """
    Parameters
    ----------
    method_name : type
        Description of parameter `method_name`.
    """
    pass
