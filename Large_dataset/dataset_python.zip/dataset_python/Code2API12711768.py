def turn_on_minor_ticks_y_axis():
    ax.tick_params(axis='x', which='minor', bottom=False)
