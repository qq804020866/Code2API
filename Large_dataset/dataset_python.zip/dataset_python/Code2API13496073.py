def display_skipped_tests():
    pass
