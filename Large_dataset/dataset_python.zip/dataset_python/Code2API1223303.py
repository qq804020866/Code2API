import os

def write_newline_to_fd(fd):
    os.write(fd, os.linesep)
