from PIL import Image

def create_image_from_pixels(pixels):
    im = Image.new("RGB", (len(pixels), 1))
    im.putdata(pixels)
    return im
