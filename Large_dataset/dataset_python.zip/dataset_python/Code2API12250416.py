import xlrd

def get_sheet_names(file_path):
    xls = xlrd.open_workbook(file_path, on_demand=True)
    return xls.sheet_names()
