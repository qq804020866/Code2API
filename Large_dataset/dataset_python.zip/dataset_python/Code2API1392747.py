def create_dropdown_with_selected_value(movies, selected_movie):
    dropdown_html = '<select name="movie">\n'
    for movie in movies:
        if movie.id == selected_movie.id:
            dropdown_html += f'    <option value="{movie.key}" selected="selected">Movie {movie.id}: {movie.name}</option>\n'
        else:
            dropdown_html += f'    <option value="{movie.key}">Movie {movie.id}: {movie.name}</option>\n'
    dropdown_html += '</select>'
    return dropdown_html
