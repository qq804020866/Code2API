import pytz
import datetime

def convert_gmt_to_est(gmt_time):
    gmt = pytz.timezone('GMT')
    eastern = pytz.timezone('US/Eastern')
    date = datetime.datetime.strptime(gmt_time, '%a, %d %b %Y %H:%M:%S GMT')
    dategmt = gmt.localize(date)
    dateeastern = dategmt.astimezone(eastern)
    return dateeastern
