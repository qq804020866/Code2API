def restore_cwd_decorator(func):
    def wrapper(*args, **kwargs):
        current_dir = os.getcwd()
        try:
            return func(*args, **kwargs)
        finally:
            os.chdir(current_dir)
    return wrapper
