import gtk

def add_items_to_combobox(combo_box, items):
    for item in items:
        combo_box.append_text(item)
    combo_box.set_active(0)
