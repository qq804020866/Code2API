def insert_blob_into_db(thefile, sometable, theblobcolumn, cursor):
    thedata = open(thefile, 'rb').read()
    sql = f"INSERT INTO {sometable} ({theblobcolumn}) VALUES (%s)"
    cursor.execute(sql, (thedata,))
