def add_title_to_rst():
    return "My Title\n*********"
