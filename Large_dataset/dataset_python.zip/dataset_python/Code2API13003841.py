def convert_array_to_string(tags):
    return "{{ tags|join(' ') }}"
