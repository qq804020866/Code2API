def store_session_data(request, session_data):
    request.session['fav_color'] = session_data
    fav_color = request.session['fav_color']
