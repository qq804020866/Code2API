import httplib2
from apiclient.discovery import build
from oauth2client.client import SignedJwtAssertionCredentials

def query_bigquery():
    # REPLACE WITH YOUR Project ID
    PROJECT_NUMBER = 'XXXXXXXXXXX'
    # REPLACE WITH THE SERVICE ACCOUNT EMAIL FROM GOOGLE DEV CONSOLE
    SERVICE_ACCOUNT_EMAIL = '[email protected]'

    # OBTAIN THE KEY FROM THE GOOGLE APIs CONSOLE
    # More instructions here: http://goo.gl/w0YA0
    f = file('key.p12', 'rb')
    key = f.read()
    f.close()

    credentials = SignedJwtAssertionCredentials(
        SERVICE_ACCOUNT_EMAIL,
        key,
        scope='https://www.googleapis.com/auth/bigquery')

    http = httplib2.Http()
    http = credentials.authorize(http)

    service = build('bigquery', 'v2')
    datasets = service.datasets()
    response = datasets.list(projectId=PROJECT_NUMBER).execute(http)

    print 'Dataset list:'
    for dataset in response['datasets']:
        print '%s' % dataset['datasetReference']['datasetId']
