import re

def escape_backslash(input_string):
    return re.findall(r'\\', input_string)[0]
