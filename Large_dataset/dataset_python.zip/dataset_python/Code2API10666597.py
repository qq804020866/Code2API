def install_lxml():
    return "$ sudo port install python27 py27-lxml"
