import random

def select_random_element(mylist):
    return random.choice(mylist)
