def override_change_list_template():
    return """
templates/
  admin/
    app/
      change_list.html
"""
