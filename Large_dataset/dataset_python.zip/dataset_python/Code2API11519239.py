import paramiko

def transfer_file_to_ssh_server(s, local_file_path, remote_file_path):
    sftp = s.open_sftp()
    sftp.put(local_file_path, remote_file_path)
