def upgrade_pip():
    return "easy_install --upgrade pip"
