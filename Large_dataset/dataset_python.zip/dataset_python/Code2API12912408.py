from matplotlib.dates import DateFormatter
import matplotlib.pyplot as plt

def change_date_format():
    formatter = DateFormatter('%Y-%m-%d %H:%M:%S')
    plt.gcf().axes[0].xaxis.set_major_formatter(formatter)
