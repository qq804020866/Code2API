def is_string_numeric(input_string):
    return input_string.isdigit()
