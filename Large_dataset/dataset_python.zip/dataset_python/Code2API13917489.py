def delete_file_from_zip():
    pass
