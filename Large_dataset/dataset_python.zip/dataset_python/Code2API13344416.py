from django.db.models.aggregates import Count

def get_filtered_jobstatus():
    return JobStatus.objects.filter(
        status='PRF'
    ).values_list(
        'job', flat=True
    ).order_by(
        'job'
    ).annotate(
        count_status=Count('status')
    ).filter(
        count_status__gt=1
    ).distinct()
