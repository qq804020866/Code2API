def get_next_line(file_obj):
    irofile = iter(file_obj)
    for line in irofile:
        print(line)
        if line == 'foo':
            line = next(irofile)  # BEWARE, This could raise StopIteration!
            print(line)
