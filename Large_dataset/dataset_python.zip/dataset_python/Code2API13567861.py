import pandas as pd

def write_read_series_csv(s, file_path):
    s.to_csv(file_path)
    return pd.read_csv(file_path)
