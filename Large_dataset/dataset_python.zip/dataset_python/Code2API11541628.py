import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def plot_3d_lines(VecStart_x, VecStart_y, VecStart_z, VecEnd_x, VecEnd_y, VecEnd_z):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    for i in range(4):
        ax.plot([VecStart_x[i], VecEnd_x[i]], [VecStart_y[i],VecEnd_y[i]], zs=[VecStart_z[i],VecEnd_z[i]])

    plt.show()
