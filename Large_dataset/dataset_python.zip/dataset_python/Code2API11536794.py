def run_core_test():
    pass
