def add_key_to_dictionary(dictionary, new_key, new_value):
    dictionary[new_key] = new_value
    return dictionary
