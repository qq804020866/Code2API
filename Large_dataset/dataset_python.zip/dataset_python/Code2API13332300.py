import subprocess

def execute_command_with_pipe(command_list, input_pipe):
    ps = subprocess.Popen(command_list, stdout=subprocess.PIPE)
    output = subprocess.check_output(input_pipe, stdin=ps.stdout)
    ps.wait()
    return output
