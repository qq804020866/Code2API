import random

def pick_random_items(item_set):
    return random.sample(item_set, 2)
