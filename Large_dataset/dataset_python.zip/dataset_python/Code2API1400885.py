from PyQt4 import QtCore

def create_QString(string_value):
    return QtCore.QString(string_value)
