from django.core.management import call_command

def make_db_dumpfile(output_filename, model_name):
    output = open(output_filename,'w') # Point stdout at a file for dumping data to.
    call_command('dumpdata', model_name, format='json', indent=3, stdout=output)
    output.close()
