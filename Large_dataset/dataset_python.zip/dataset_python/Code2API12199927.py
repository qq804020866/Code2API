def convert_to_bytestring():
    return chr(0xd3)
