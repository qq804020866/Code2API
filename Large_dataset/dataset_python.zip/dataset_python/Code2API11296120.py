def get_current_item(when_to_change_the_mode, listA):
    looking_for = iter(when_to_change_the_mode)
    current = next(looking_for)
    for l in listA:
        do_something(current)
        if l == current:
            current = next(looking_for)
