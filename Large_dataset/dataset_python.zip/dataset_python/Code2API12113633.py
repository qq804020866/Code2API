def destroy_test_database():
    pass
