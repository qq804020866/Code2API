from mpl_toolkits.axes_grid1 import make_axes_locatable
import numpy as np
import matplotlib.pyplot as plt

def limit_x_axis():
    velocity=np.random.rand(3,9)

    fig, ax1 = plt.subplots(1,1,figsize=(16, 12), dpi=100, subplot_kw={'aspect': 'equal'})

    ax1.set_yticks([int(j) for j in range(0,4)])
    ax1.set_xticks([int(j) for j in range(-4,5)])

    for label in ax1.get_xticklabels() + ax1.get_yticklabels():
        label.set_fontsize(15)
    for tick in ax1.get_xticklines() + ax1.get_yticklines():
        tick.set_markeredgewidth(2)
        tick.set_markersize(6)

    im = ax1.imshow(velocity, cmap=cm.jet, interpolation='nearest',origin='lower',vmin=0,vmax=1.7, extent=[-4.50,4.50,0,3])
    ax1.set_xlim(-4,4)

    divider = make_axes_locatable(ax1)
    cax = divider.append_axes("right", size="2.5%", pad=0.3)
    cb=plt.colorbar(im,cax=cax)
    cb.set_label('Speed [$m/s$]')

    plt.savefig("speed_400.png")
    plt.close(fig)
