def write_bytes_to_file(file_path, msg):
    f = open(file_path, 'wb')
    f.write(msg)
    f.close()
