def split_list_into_chunks(lst):
    return zip(*[iter(lst)]*3)
