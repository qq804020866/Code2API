import subprocess

def communicate_with_engine():
    engine = subprocess.Popen(
        'stockfish-x64.exe',
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
    )
    for line in engine.stdout:
        print(line.strip())
