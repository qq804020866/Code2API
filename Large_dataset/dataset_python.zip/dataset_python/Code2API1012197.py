def index_list_with_another_list(list_to_index, indices):
    return [list_to_index[i] for i in indices]
