def set_django_test_server_interface(ip_port):
    # python manage.py runserver 0.0.0.0:8000
    pass
