from PyQt4 import QtCore, QtGui

def jump_to_front(window):
    window.setWindowState(window.windowState() & ~QtCore.Qt.WindowMinimized | QtCore.Qt.WindowActive)
    window.activateWindow()
