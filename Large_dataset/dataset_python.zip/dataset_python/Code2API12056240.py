from django.contrib.sessions.models import Session
from django.contrib.auth.models import User

def find_user_id_from_session_data(session_key):
    session = Session.objects.get(session_key=session_key)
    uid = session.get_decoded().get('_auth_user_id')
    user = User.objects.get(pk=uid)

    return user.username, user.get_full_name(), user.email
