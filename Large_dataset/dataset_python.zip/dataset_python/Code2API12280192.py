import os

def move_one_folder_back():
    os.chdir("../nodes")
