def run_python_script(script_path, data_path):
    #!/bin/sh
    python script_path data_path
