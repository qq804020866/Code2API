import random

def randomly_choose_users(user_dict):
    keys = random.sample(list(user_dict), 10)
    values = [user_dict[k] for k in keys]
    return keys, values
