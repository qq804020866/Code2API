import numpy as np

def create_array_with_value(shape, value):
    return np.zeros(shape) + value
