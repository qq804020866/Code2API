import sys

def add_path_to_sys(path):
    sys.path.insert(0, path)
