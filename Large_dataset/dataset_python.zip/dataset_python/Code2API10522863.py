import csv

def export_sqlite_to_csv():
    conn = sqlite3.connect(dbfile)
    conn.text_factory = str
    cur = conn.cursor()
    data = cur.execute("SELECT * FROM mytable")

    with open('output.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Column 1', 'Column 2', ...])
        writer.writerows(data)
