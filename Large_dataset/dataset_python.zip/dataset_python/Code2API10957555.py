import time

def convert_string_datetime_to_timestamp(datetimestring):
    return time.mktime(time.strptime(datetimestring, '%a, %d %b %Y %H:%M:%S GMT'))
