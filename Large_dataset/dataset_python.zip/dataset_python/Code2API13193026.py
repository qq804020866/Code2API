import os
from zipfile import ZipFile, ZIP_DEFLATED
import subprocess
from modulefinder import ModuleFinder

def build_single_file(dest_dir, zip_name, source_name, python_exe, dest_path):
    zipfile = ZipFile(os.path.join(dest_dir, zip_name), 'w', ZIP_DEFLATED)
    sys.path.insert(0, '.')
    finder = ModuleFinder()
    finder.run_script(source_name)

    for name, mod in finder.modules.iteritems():
        filename = mod.__file__
        if filename is None:
            continue
        if "python" in filename.lower():
            continue

        subprocess.call('"%s" -OO -m py_compile "%s"' % (python_exe, filename))

        zipfile.write(filename, dest_path)
