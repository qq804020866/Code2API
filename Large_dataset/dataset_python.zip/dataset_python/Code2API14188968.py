import xlrd

def copy_row_to_another_sheet(file_name, sheet_name):
    bk = xlrd.open_workbook(file_name)
    shxrange = range(bk.nsheets)
    try:
        sh = bk.sheet_by_name(sheet_name)
    except:
        print "no sheet in %s named %s" % (file_name, sheet_name)
        return None
    nrows = sh.nrows
    ncols = sh.ncols
    print "nrows %d, ncols %d" % (nrows, ncols)

    cell_value = sh.cell_value(1, 1)
    print cell_value

    row_list = []
    for i in range(1, nrows):
        row_data = sh.row_values(i)
        row_list.append(row_data)
