import os

def launch_command_window(command):
    os.system(command)
