from PIL import Image

def is_image_corrupted(image_path):
    v_image = Image.open(image_path)
    v_image.verify()
