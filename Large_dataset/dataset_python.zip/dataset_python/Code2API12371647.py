def open_ascii_file_as_utf8(file_path):
    template_str = template_str.decode('utf8')
    return template_str
