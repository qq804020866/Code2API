from matplotlib.colors import colorConverter
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl

def overlay_imshow_plots(zvals, zvals2, color1, color2, cmap1, cmap2, alphas):
    cmap2._init() # create the _lut array, with rgba values
    cmap2._lut[:,-1] = alphas

    img2 = plt.imshow(zvals, interpolation='nearest', cmap=cmap1, origin='lower')
    img3 = plt.imshow(zvals2, interpolation='nearest', cmap=cmap2, origin='lower')

    plt.show()
