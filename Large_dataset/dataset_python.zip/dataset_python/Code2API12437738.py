import string

def replace_punctuation(text, replacement):
    replace_punctuation = string.maketrans(string.punctuation, replacement * len(string.punctuation))
    return text.translate(replace_punctuation)
