import math

def find_angle(x1, y1, x2, y2):
    dx, dy = x2 - x1, y2 - y1
    rads = math.atan2(dx/dy)
    degs = math.degrees(rads)
    return degs
