def drop_rows_with_nan(df):
    return df[df['EPS'].notna()]
