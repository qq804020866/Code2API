from numpy.random import rand
import matplotlib.pyplot as plt

def share_secondary_y_axis():
    ax0 = plt.subplot(211)
    ax1 = ax0.twinx()
    ax2 = plt.subplot(212)
    ax3 = ax2.twinx()

    ax1.get_shared_y_axes().join(ax1, ax3)

    ax0.plot(rand(1) * rand(10),'r')
    ax1.plot(10*rand(1) * rand(10),'b')
    ax2.plot(3*rand(1) * rand(10),'g')
    ax3.plot(10*rand(1) * rand(10),'y')
    plt.show()
