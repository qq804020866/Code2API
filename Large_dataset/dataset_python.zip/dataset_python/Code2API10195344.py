import MySQLdb

def retrieve_column_value(conn, query):
    cursor = conn.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute(query)
    result_set = cursor.fetchall()
    for row in result_set:
        print("%s, %s" % (row["name"], row["category"]))
