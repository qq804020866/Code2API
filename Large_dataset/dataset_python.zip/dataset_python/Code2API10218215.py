def convert_to_hex(bignum):
    return hex(bignum).rstrip("L").lstrip("0x") or "0"
