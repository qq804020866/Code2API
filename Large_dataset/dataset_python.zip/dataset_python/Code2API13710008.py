def install_package_to_virtualenv(package_name, virtualenv_path):
    command = f"sudo apt-get install {package_name}\n"
    command += f"cp /usr/lib/python2.7/dist-packages/{package_name}* {virtualenv_path}/lib/python2.7/site-packages/"
    return command
