import numpy as np
import cv2

def convert_image(image_array, desired_dtype):
    image = cv2.cvtColor(image_array, cv2.COLOR_GRAY2BGR)
    cvuint8 = cv2.convertScaleAbs(image)
    return cvuint8

# Example usage
img = np.empty((100,100,1), dtype=np.uint16)
converted_img = convert_image(img, np.uint8)
print(converted_img.dtype)
