from sklearn.base import clone

def duplicate_estimator():
    lr1 = LogisticRegression()
    lr2 = clone(lr1)
    return lr1, lr2
