import datetime as dt

def add_delta_to_time():
    now = dt.datetime.now()
    delta = dt.timedelta(hours = 12)
    t = now.time()
    return (dt.datetime.combine(dt.date(1,1,1),t) + delta).time()
