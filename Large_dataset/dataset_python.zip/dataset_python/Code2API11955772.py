import scipy.sparse.linalg

def find_eigenvector(matrix):
    return scipy.sparse.linalg.eigs(matrix, k=1, sigma=1)
