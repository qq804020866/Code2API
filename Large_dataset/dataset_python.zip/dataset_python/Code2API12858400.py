def set_date_tick_labels(x, ax):
    ax.xaxis.set_ticks(x)
