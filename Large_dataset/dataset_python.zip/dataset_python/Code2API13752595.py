def change_list_values(execlist, mynumber, myctype, myx, myy, mydelay):
    for i in range(len(execlist)):
        if execlist[i][0] == mynumber:
            execlist[i][1] = myctype
            execlist[i][2] = myx
            execlist[i][3] = myy
            execlist[i][4] = mydelay
