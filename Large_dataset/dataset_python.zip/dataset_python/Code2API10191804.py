import requests

def http_delete_request(url, payload, headers, toggl_token, data_description):
    response = requests.delete(
        url, 
        data=json.dumps(payload), 
        headers=headers,
        auth=HTTPBasicAuth(toggl_token, 'api_token')
    )
    return response
