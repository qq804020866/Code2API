def dynamic_column_filter(db_session, Notice, col_name, query):
    return db_session.query(Notice).filter(getattr(Notice, col_name).like("%" + query + "%"))
