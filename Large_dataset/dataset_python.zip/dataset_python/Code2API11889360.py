import os

def add_unicode_literal(somedir, encoding):
    unicode_somedir = somedir.decode(encoding)
    return unicode_somedir
