import time
import itertools

def show_progress():
    for c in itertools.cycle('/-\|'):
        print(c, end = '\r')
        time.sleep(0.2)
