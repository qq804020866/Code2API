from IPython.display import Image

def display_image(file_name):
    Image(filename=file_name)
