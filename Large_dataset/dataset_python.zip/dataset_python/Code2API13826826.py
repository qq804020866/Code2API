from jsonschema import Draft3Validator

def validate_schema(my_schema):
    return Draft3Validator.check_schema(my_schema)
