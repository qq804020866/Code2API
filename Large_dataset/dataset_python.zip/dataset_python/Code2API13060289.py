from Tkinter import Tk, Label

def show_tkinter_window():
    root = Tk()
    w = Label(root, text="Hello, world!")
    w.pack()
    root.mainloop()
