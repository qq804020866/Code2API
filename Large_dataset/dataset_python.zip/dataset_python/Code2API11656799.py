from math import log

def take_log_of_list(num_list):
    return [log(y,10) for y in num_list]
