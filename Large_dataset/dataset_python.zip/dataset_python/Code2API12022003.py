def slice_dataframe(df):
    return df.head(10)
