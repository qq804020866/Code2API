import numpy as np

def check_array_contains(a, b):
    diff = np.setdiff1d(b, a)
    return diff.size
