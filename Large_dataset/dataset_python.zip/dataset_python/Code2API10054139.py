from django.conf.urls import url, include

def create_custom_admin_page():
    urlpatterns = patterns('',
       url(r'^admin/preferences/$', TemplateView.as_view(template_name='admin/preferences/preferences.html')),
       url(r'^admin/', include('django.contrib.admin.urls')),
    )
    return urlpatterns
