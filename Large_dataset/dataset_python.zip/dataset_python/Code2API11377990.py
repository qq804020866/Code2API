def count_queryset_items(queryset):
    return len(queryset)
