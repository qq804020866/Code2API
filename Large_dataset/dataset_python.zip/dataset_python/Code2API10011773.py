import numpy

def divide_by_zero(numerator, denominator):
    return numpy.float64(numerator) / denominator
