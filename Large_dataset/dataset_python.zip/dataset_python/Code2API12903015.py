def allow_append_return(myList, element):
    return myList + [element]
