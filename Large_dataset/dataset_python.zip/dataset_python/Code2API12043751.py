import numpy as np

def calculate_average_line(x, y):
    x, y = zip(*sorted((xVal, np.mean([yVal for a, yVal in zip(x, y) if xVal==a])) for xVal in set(x)))
    return x, y
