def check_keys_in_dict(dict_obj, keys):
    if all(k in dict_obj for k in keys):
        print("They're there!")
