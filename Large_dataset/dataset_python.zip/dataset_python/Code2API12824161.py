import locale

def format_float_with_comma(value, precision=4):
    locale.setlocale(locale.LC_ALL, '')
    return locale.format('%.{}f'.format(precision), value, grouping=True)
