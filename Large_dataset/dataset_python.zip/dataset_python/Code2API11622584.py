import calendar

def is_leap_year(year):
    return calendar.isleap(year)
