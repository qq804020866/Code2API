from pandas import DataFrame

def convert_query_result(resoverall):
    df = DataFrame(resoverall.fetchall())
    df.columns = resoverall.keys()
    return df
