from glob import iglob
import shutil
import os

def concatenate_files():
    PATH = r'C:\music'
    destination = open('everything.mp3', 'wb')
    for filename in iglob(os.path.join(PATH, '*.mp3')):
        shutil.copyfileobj(open(filename, 'rb'), destination)
    destination.close()
