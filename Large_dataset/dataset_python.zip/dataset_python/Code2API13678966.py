def pass_kwargs_in_url(regex, view, kwargs=None, name=None, prefix=''):
    return url(regex, view, kwargs=dict(model=models.userModel), name="sample")
