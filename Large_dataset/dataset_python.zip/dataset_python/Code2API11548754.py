import logging

def set_logging_level():
    logging.getLogger().setLevel(logging.INFO)
