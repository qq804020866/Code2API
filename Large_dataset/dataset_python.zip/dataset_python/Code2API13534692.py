import subprocess

def execute_bat_file(bat_file_path):
    subprocess.Popen(bat_file_path, creationflags=subprocess.CREATE_NEW_CONSOLE)
