def list_properties():
    property_names = [p for p in dir(SomeClass) if isinstance(getattr(SomeClass,p),property)]
    return property_names
