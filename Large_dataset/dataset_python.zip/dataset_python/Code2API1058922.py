def concatenate_strings(list_of_strings):
    return ''.join(list_of_strings)
