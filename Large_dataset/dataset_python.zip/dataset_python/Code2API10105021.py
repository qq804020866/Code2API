import matplotlib.pyplot as plt
import networkx as nx

def set_edge_labels_offset(G, pos, edge_labels_dict):
    nx.draw_networkx_edge_labels(G, pos, edge_labels_dict, label_pos=0.3)
