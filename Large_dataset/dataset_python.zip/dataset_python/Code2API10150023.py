import os.path, time

def get_file_creation_date(file_path):
    f = open(file_path)
    data = f.read()
    f.close()
    return "last modified: %s" % time.ctime(os.path.getmtime(file_path)) + "\ncreated: %s" % time.ctime(os.path.getctime(file_path))
