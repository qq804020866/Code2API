def change_datetime_format(datetime_obj):
    return "{{ datetime_obj|date:\"d-m-Y\" }}"
