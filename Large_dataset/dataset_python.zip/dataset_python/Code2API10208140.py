import win32gui
import time

def scan_window_title():
    tempWindowName = win32gui.GetWindowText(win32gui.GetForegroundWindow())
    while True:
        if tempWindowName == win32gui.GetWindowText(win32gui.GetForegroundWindow()):
            pass
        else:
            tempWindowName = win32gui.GetWindowText(win32gui.GetForegroundWindow())
            # do what you want
        time.sleep(0.1)
