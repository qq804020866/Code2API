from django.contrib import admin
from mysite.books.models import Publisher, Author, Book

def register_models_to_admin():
    admin.site.register(Publisher)
    admin.site.register(Author)
    admin.site.register(Book)
