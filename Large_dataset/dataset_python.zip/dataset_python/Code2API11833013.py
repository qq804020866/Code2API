import requests

def upload_attachment(file_path):
    with open(file_path) as fh:
        mydata = fh.read()
        response = requests.put('https://api.elasticemail.com/attachments/upload',
                                data=mydata,                         
                                auth=('omer', 'b01ad0ce'),
                                headers={'content-type':'text/plain'},
                                params={'file': file_path}
                               )
    return response
