import sys

def check_python_version():
    import sys
    print(sys.version)
