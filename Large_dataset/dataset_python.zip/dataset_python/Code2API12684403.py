def left_align_fixed_width_string(code, name, industry):
    sys.stdout.write("%-6s %-50s %-25s\n" % (code, name, industry))
