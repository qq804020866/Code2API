def generate_sop_instance_uid():
    return YOUR_ORG_ROOT.CONVERTED_UUID
