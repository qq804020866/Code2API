from sqlalchemy.orm import aliased

def join_queries_by_age(q1, q2):
    a1 = aliased(q1._mapper_zero().class_)
    a2 = aliased(q2._mapper_zero().class_)
    s = q2.subquery()
    return q1.join(s, a1.age==s.columns.age).all()
