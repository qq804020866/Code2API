from xlwt import Workbook
import xlwt

def set_excel_cell_background_color(workbook, sheet, row, column, text, background_color):
    st = xlwt.easyxf('pattern: pattern solid;')
    st.pattern.pattern_fore_colour = background_color
    sheet.write(row, column, text, st)
    workbook.save('simple.xls')
