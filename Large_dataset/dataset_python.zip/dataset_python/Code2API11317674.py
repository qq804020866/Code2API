from urllib import urlencode

def escape_pipe_symbol(params):
    u = urlencode(params)
    return u.replace('%7C', '|')
