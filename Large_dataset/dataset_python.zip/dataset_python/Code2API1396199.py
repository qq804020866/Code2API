def drop_into_repl():
    pass
