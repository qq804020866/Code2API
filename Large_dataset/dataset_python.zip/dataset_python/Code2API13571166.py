import os
import sys

def read_files_in_subdirectories(rootdir):
    with open('output.txt','w') as fout:
        for root, subFolders, files in os.walk(rootdir):
            if 'data.txt' in files:
                with open(os.path.join(root, 'data.txt'), 'r') as fin:
                    for lines in fin:
                        dosomething()
