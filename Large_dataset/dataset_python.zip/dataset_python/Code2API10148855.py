def iterate_over_columns(array):
    for column in array.T:
        some_function(column)
