import datetime
import time

def convert_ctime_to_datetime():
    return datetime.datetime.strptime(time.ctime(), "%a %b %d %H:%M:%S %Y")
