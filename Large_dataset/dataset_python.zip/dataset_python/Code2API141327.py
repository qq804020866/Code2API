import os

def list_top_level_directories(dir_path):
    return [name for name in os.listdir(dir_path) if os.path.isdir(os.path.join(dir_path, name))]
