from selenium import webdriver

def set_element_display(element_id):
    driver = webdriver.Chrome()
    driver.execute_script("document.getElementById(element_id).style.display='block';")
