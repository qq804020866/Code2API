from bs4 import BeautifulSoup

def get_xml_tag_value(xml_string):
    soup = BeautifulSoup(xml_string)
    return soup.find('text').string
