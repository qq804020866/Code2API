import matplotlib.pyplot as plt
import numpy as np

def set_y_axis_in_radians():
    x = np.arange(-10.0, 10.0, 0.1)
    y = np.arctan(x)

    fig = plt.figure()
    ax = fig.add_subplot(111)

    ax.plot(x, y, 'b.')

    y_pi = y / np.pi
    unit = 0.25
    y_tick = np.arange(-0.5, 0.5 + unit, unit)

    y_label = [r"$-\frac{\pi}{2}$", r"$-\frac{\pi}{4}$", r"$0$", r"$+\frac{\pi}{4}$", r"$+\frac{\pi}{2}$"]
    ax.set_yticks(y_tick * np.pi)
    ax.set_yticklabels(y_label, fontsize=20)

    y_label2 = [r"$" + format(r, ".2g") + r"\pi$" for r in y_tick]
    ax2 = ax.twinx()
    ax2.set_yticks(y_tick * np.pi)
    ax2.set_yticklabels(y_label2, fontsize=20)

    plt.show()
