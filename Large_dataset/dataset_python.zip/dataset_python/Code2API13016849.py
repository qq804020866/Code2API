from setuptools.command import easy_install

def install_module(module_name):
    easy_install.main([module_name])
