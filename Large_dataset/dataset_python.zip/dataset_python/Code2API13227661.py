def compare_dates(date1, date2):
    return date1.date() == date2.date()
