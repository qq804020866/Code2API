def make_hollow_square_marks(xaxis, pq_averages, label):
    pylab.semilogy(xaxis, pq_averages, 'ks-', markerfacecolor='none', label=label)
