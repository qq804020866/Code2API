import matplotlib.pyplot as plt

def add_formula_legend(x, y):
    ax = plt.gca()
    ax.plot(x, y, label=r'$\sin (x)$')
    ax.legend()
