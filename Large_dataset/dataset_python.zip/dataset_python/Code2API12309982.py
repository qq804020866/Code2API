def list_to_string(my_list):
    return " ".join(my_list)
