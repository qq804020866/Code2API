import urllib
import urllib2

def send_get_request(url, params):
    full_url = url + '?' + urllib.urlencode(params)
    urllib2.urlopen(full_url)
