from selenium import webdriver

def get_href_of_links(partial_text):
    links = browser.find_elements_by_partial_link_text(partial_text)
    for link in links:
        print(link.get_attribute("href"))
