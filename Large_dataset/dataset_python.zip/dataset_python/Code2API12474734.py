import urllib

def get_content_type(url):
    res = urllib.urlopen(url)
    http_message = res.info()
    full = http_message.type
    main = http_message.maintype
    return full, main
