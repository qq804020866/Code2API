import ntpath
import os

def change_path_format(path_string):
    return path_string.replace(os.sep, ntpath.sep)
