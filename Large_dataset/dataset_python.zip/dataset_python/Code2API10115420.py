def check_attribute_exists(current_element, attribute_name):
    return attribute_name in current_element.attrib
