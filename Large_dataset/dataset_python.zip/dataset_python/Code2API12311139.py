import numpy as np
import scipy.ndimage
import matplotlib.pyplot as plt

def smooth_contour_plot():
    data = np.loadtxt('data.txt')
    data = scipy.ndimage.zoom(data, 3)
    plt.contour(data)
    plt.show()
