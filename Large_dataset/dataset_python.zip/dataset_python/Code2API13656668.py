def remove_newlines(file_path):
    return open(file_path, 'U').read().split()
