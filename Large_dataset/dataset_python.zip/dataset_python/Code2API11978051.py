from scipy.cluster.hierarchy import linkage
from scipy.cluster.hierarchy import dendrogram
from scipy.spatial.distance import pdist
import matplotlib
from matplotlib import pyplot as plt
import numpy as np
from numpy import arange

def make_square_subplots():
    fig = plt.figure(figsize=(5,7))
    ax1 = plt.subplot(2, 1, 1)
    cm = matplotlib.cm.Blues
    X = np.random.random([5,5])
    pmat = pdist(X, "euclidean")
    linkmat = linkage(pmat)
    dendrogram(linkmat)
    x0,x1 = ax1.get_xlim()
    y0,y1 = ax1.get_ylim()
    ax1.set_aspect((x1-x0)/(y1-y0))

    plt.subplot(2, 1, 2, aspect=1)
    labels = ["a", "b", "c", "d", "e", "f"]
    Y = np.random.random([6,6])
    plt.xticks(arange(0.5, 7.5, 1))
    plt.gca().set_xticklabels(labels)
    plt.pcolor(Y)
    plt.colorbar()

    # add a colorbar to the first plot and immediately make it invisible
    cb = plt.colorbar(ax=ax1)
    cb.ax.set_visible(False)

    plt.show()
