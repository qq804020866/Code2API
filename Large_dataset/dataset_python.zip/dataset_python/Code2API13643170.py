def import_fixtures():
    from sonoftest import pytest_addoption, cmdopt
