from <app name>.Crunch import *

def import_crunch_methods():
    pass
