import matplotlib.pyplot as plt

def convert_data_to_color(colormap_name, data_value):
    return plt.get_cmap(colormap_name)(data_value)
