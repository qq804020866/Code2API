import sys

def append_paths_to_pythonpath(directories):
    for directory in directories:
        sys.path.append(directory)
    from test1.common.api import GenericAPI
