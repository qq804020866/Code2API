from django.db import models

def get_all_children(animals):
    return [animal.categories.all() for animal in animals]
