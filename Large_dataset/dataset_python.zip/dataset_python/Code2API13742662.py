from xml.etree import ElementTree as ET

def validate_xml(xml_string):
    return ET.fromstring(xml_string)
