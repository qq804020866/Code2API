import numpy as np

def create_list_of_lists():
    lst = []
    line = np.genfromtxt('temp.txt', usecols=3, dtype=[('floatname','float')], skip_header=1)
    lst.append(line)
    return lst
