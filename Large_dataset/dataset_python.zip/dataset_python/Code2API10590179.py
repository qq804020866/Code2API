import urllib

def redirect_with_query_string(request):
    newurl = '/my/new/route?' + urllib.urlencode(request.params)
    self.redirect(newurl)
