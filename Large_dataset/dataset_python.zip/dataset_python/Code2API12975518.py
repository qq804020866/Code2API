def check_numpy_installation():
    import numpy
    print(numpy)
