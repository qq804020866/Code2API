import re

def replace_backslash(mystr1, myfile):
    return re.sub(mystr1 + "\\\\", "", myfile)
