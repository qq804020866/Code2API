import existingmodule

def modify_function():
    existingmodule.foo = lambda *args, **kwargs: "You fail it"
