import csv

def remove_duplicates(input_file_path, output_file_path):
    reader = csv.reader(open(input_file_path, 'r'), delimiter=',')
    writer = csv.writer(open(output_file_path, 'w'), delimiter=',')

    entries = set()
    for row in reader:
        key = (row[0], row[1])  # instead of just the last name

        if key not in entries:
            writer.writerow(row)
            entries.add(key)
