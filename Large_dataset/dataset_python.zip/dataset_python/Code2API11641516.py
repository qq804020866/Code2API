import cPickle as pickle

def dump_and_load_dicts(filename, dict1, dict2, dict3):
    with open(filename,'wb') as fp:
        pickle.dump(dict1,fp)
        pickle.dump(dict2,fp)
        pickle.dump(dict3,fp)

    with open(filename,'rb') as fp:
        d1=pickle.load(fp)
        d2=pickle.load(fp)
        d3=pickle.load(fp)
