def remove_chars_from_beginning(lines):
    for line in lines:
        line = line[2:]
        # do something here
