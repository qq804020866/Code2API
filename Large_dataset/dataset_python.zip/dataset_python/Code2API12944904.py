import itertools

def loop_list(iterable):
    iterable = tuple(iterable)
    l = len(iterable)
    num = 0
    while num < l:
        yield iterable[num]
        num += 1
        if num >= l:
            num = 0
