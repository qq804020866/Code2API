import boto

def delete_s3_folder(bucket, folder_prefix):
    for key in bucket.list(prefix=folder_prefix):
        key.delete()
