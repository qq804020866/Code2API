from importlib import reload

def reload_module():
    import X
    reload(X)
    from X import Y  # or * for that matter
