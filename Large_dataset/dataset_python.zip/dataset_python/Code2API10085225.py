import pyodbc

def connect_to_database(driver, server, database, username, password):
    return pyodbc.connect('driver={%s};server=%s;database=%s;uid=%s;pwd=%s' % (driver, server, database, username, password))
