from sqlalchemy import text

def execute_query(query_string, search_string):
    return connection.execute(text(query_string), string=search_string)
