import pandas as pd

def merge_with_index(df1, df2):
    return df1.reset_index().merge(df2, how='left').set_index('index')
