from datetime import datetime

def convert_to_12_hour_time(time_24_hour):
    return datetime.strptime(time_24_hour, "%H:%M").strftime("%I:%M %p")
