import sys

def is_stdout_attached_to_terminal():
    if sys.stdout.isatty():
        # You're running in a real terminal
        return True
    else:
        # You're being piped or redirected
        return False
