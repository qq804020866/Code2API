import datetime
import os

def get_file_modification_date_utc(file_path):
    dt = os.path.getmtime(file_path)
    return datetime.datetime.fromtimestamp(dt), datetime.datetime.utcfromtimestamp(dt)
