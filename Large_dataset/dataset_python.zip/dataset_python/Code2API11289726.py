from xml.etree.ElementTree import ElementTree
from xml.parsers import expat

def parse_xml_file(xml_file, encoding):
    tree = ElementTree()
    root = tree.parse(xml_file, parser=expat.ParserCreate(encoding))
    return root
