import os, subprocess

def run_command_with_env(command_list, env_vars):
    env = dict(os.environ)   # Make a copy of the current environment
    env.update(env_vars)     # Update the environment with the provided variables
    subprocess.Popen(command_list, env=env)
