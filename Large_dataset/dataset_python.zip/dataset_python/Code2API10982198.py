def shift_column(df, column_name):
    df[column_name] = df[column_name].shift(1)
