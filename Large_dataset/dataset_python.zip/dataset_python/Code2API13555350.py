from bs4 import BeautifulSoup as BS
import urllib2

def get_option_text(file_path):
    soup = BS(urllib2.urlopen(file_path).read())
    contents = [str(x.text) for x in soup.find(id="start_dateid").find_all('option')]
    return contents
