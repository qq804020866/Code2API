from myapp.tasks import my_task

def run_periodic_task():
    eager_result = my_task.apply()
