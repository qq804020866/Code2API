import pandas as pd

def convert_datetimeindex_to_string_series(datetime_index):
    return pd.Series(datetime_index.format())
