def get_dropdown_value():
    pass
