def save_list_to_file(your_list, file_path):
    outfile = open(file_path, "w")
    print >> outfile, "\n".join(str(i) for i in your_list)
    outfile.close()
