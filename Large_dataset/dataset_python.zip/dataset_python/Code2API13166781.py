import git

def pull_remote_repository(repo_path):
    repo = git.Repo(repo_path)
    o = repo.remotes.origin
    o.pull()
