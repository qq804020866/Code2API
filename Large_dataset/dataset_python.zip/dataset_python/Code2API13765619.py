import zipfile

def unzip_specific_folder(zip_file_path, destination_path):
    archive = zipfile.ZipFile(zip_file_path)

    for file in archive.namelist():
        if file.startswith('foo/'):
            archive.extract(file, destination_path)
