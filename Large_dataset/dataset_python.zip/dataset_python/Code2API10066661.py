def find_common_elements(lists):
    result = set(lists[0])
    for s in lists[1:]:
        result.intersection_update(s)
    return result
