import cv2
from PIL import Image
from io import StringIO

def convert_raw_image(file_path):
    f = open(file_path, "rb")
    rawImage = f.read()
    f.close()

    pilImage = Image.open(StringIO(rawImage))
    npImage = np.array(pilImage)
    matImage = cv.fromarray(npImage)

    cv.NamedWindow('display')
    cv.MoveWindow('display', 10, 10)
    cv.ShowImage('display', matImage)
    cv.WaitKey(0)
