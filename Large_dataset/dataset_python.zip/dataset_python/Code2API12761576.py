def calculate_average_word_length(sentence):
    words = sentence.split()
    average = sum(len(word) for word in words) / len(words)
    return average
