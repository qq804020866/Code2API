import numpy as np

def remove_non_numeric_rows(array):
    return array[~np.isnan(array).any(axis=1)]
