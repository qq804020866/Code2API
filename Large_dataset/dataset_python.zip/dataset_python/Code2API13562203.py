import tarfile

def extract_files_from_tar(tar_path):
    with tarfile.open(tar_path) as tf:
        for entry in tf:  # list each entry one by one
            fileobj = tf.extractfile(entry)
            # fileobj is now an open file object. Use `.read()` to get the data.
            # alternatively, loop over `fileobj` to read it line by line.
