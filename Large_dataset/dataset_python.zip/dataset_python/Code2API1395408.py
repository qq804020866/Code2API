def convert_to_standard_binary():
    return bin(30)[2:].zfill(8)
