import os

def get_files_with_extension(directory_path, extension):
    files_with_extension = []
    for root, dirs, files in os.walk(directory_path):
        for file in files:
            if file.endswith(extension):
                files_with_extension.append(file)
    return files_with_extension
