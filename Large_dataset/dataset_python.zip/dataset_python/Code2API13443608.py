def format_list(mylist):
    for elem in mylist:
        print(elem)
