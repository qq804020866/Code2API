import datetime

def convert_string_to_datetime(your_string):
    return datetime.datetime.strptime(your_string, "%Y-%m-%dT%H:%M:%S.%f")
