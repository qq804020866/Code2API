def loop_through_generator(gen):
    for x in gen:
        # whatever
