import tkinter

def draw_image(tk, can, image_path, x_coordinate, y_coordinate):
    can = tkinter.Canvas(tk)
    can.pack()
    img = tkinter.PhotoImg(image_path)
    can.create_image((x_coordinate, y_coordinate), img)
