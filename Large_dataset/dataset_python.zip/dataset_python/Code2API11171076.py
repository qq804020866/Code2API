import re

def extract_number_from_html():
    m = re.search("Your number is <b>(\d+)</b>", "xxx Your number is <b>123</b>  fdjsk")
    if m:
        return m.groups()[0]
