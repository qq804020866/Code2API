def apply_function_to_list(my_things):
    for i in my_things:
        i.size = "big"
