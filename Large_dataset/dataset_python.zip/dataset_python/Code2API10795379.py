import numpy
import pandas as pd

def discretize_and_convert_to_binary_matrix(df):
    return pd.concat([(df.a.values[:,numpy.newaxis] == df.a.unique()).astype(int), ((0 <= df.b.values[:,numpy.newaxis]) & (df.b.values[:,numpy.newaxis] < 0.2)).astype(int), (df.c.values[:,numpy.newaxis] == df.c.unique()).astype(int)], axis=1)
