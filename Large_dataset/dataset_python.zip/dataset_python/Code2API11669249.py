from bitarray import bitarray

def create_bit_array(size):
    return bitarray(size)
