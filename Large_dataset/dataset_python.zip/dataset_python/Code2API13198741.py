def set_compile_flags():
    CFLAGS = "-I/home/qrtt1/app/include"
    LDFLAGS = "-L/home/qrtt1/app/lib"
    pip install pycrypto
