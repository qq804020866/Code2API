import scipy.stats

def calculate_probability(mean, std):
    distribution = scipy.stats.norm(mean, std)
    pdf_result = distribution.pdf(0)
    cdf_result = distribution.cdf(0)
    return pdf_result, cdf_result
