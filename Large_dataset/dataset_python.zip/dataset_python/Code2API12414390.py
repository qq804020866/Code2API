def perform_action_and_put_results(L, function):
    return [function(x) for x in L]
