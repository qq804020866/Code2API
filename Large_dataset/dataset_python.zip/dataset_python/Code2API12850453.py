def combine_dataframes(df1, df2):
    return df1.append(df2, ignore_index=True)
