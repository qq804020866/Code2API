import paramiko

def change_directory(ssh_client):
    ssh_client.exec_command('cd ..; pwd')
