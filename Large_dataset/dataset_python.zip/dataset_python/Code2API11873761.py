import datetime
import pytz

def get_nyc_time():
    utc = pytz.utc
    utc_dt = datetime.datetime(2002, 10, 27, 6, 0, 0, tzinfo=utc)
    eastern = pytz.timezone('US/Eastern')
    loc_dt = utc_dt.astimezone(eastern)
    fmt = '%Y-%m-%d %H:%M:%S %Z%z'
    return loc_dt.strftime(fmt)
