import matplotlib.pyplot as plt
from scipy import eye

def display_multiple_images():
    fig1 = plt.figure(figsize=plt.figaspect(0.75))
    ax1 = fig1.add_subplot(1, 1, 1)
    im1, = plt.imshow(eye(3))

    fig2 = plt.figure(figsize=plt.figaspect(0.75))
    ax2 = fig2.add_subplot(1, 1, 1)
    im2, = plt.imshow(eye(2))

    plt.show()
