package com.code2api.api;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class Code2API12594744 {
    public static void addLabelsToPanel(JPanel panel, JLabel label, JLabel label2) {
        panel.add(label,BorderLayout.NORTH);
        panel.add(label2,BorderLayout.SOUTH);
    }
}

class Frame extends JFrame {

    private static final long serialVersionUID = 1L;

    public Frame(){
        setSize(500,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Dimension di = new Dimension(50,50);
        Dimension dim = new Dimension(200,200);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(dim);

        JLabel label = new JLabel("Here is my label");
        JLabel label2 = new JLabel("Here is my label2");

        JMenuBar menu = new JMenuBar();
        JMenu setting = new JMenu("Setting");
        JMenuItem exit = new JMenuItem("Exit");
        JMenuItem add = new JMenuItem("Add");
        setting.add(add);
        setting.add(exit);
        menu.add(setting);

        label.setPreferredSize(di);
        label2.setPreferredSize(di);

        Code2API12594744.addLabelsToPanel(panel, label, label2);

        add(menu,BorderLayout.NORTH);
        add(panel,BorderLayout.CENTER);

        pack();
        setVisible(true);
    }
}
