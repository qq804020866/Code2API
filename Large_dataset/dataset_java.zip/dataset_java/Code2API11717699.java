package com.code2api.api;
public class Code2API11717699 {
    public static String[] splitStringWithEmptyNewLine(String text) {
        return text.split("\n\r");
    }
}
