package com.code2api.api;
import java.text.DateFormatSymbols;
import java.util.Locale;

public class Code2API12655568 {
    public static String[] getMonthsInOrder(Locale locale) {
        DateFormatSymbols symbols = new DateFormatSymbols(locale);
        return symbols.getMonths();
    }
}
