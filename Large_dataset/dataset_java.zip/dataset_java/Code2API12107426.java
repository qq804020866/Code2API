package com.code2api.api;
public class Code2API12107426 {
    public static void splitStringByDelimiter(String str, String delimiter) {
        String[] temp;
        temp = str.split(delimiter);
        for(int i =0; i < temp.length ; i++)
            System.out.println(temp[i]);
    }
}
