package com.code2api.api;
import javax.swing.JFrame;
import javax.swing.JDialog;

public class Code2API12613656 {
    public static void removeAllComponents(JFrame frame) {
        frame.removeAll();
    }
}
