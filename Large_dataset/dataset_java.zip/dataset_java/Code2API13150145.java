package com.code2api.api;
public class Code2API13150145 {
    public static int getNextDigit(int number) {
        String digits = String.valueOf(number);
        return Integer.parseInt(digits.substring(number, number+1));
    }
}
