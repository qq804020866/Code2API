package com.code2api.api;
import java.util.Scanner;

public class Code2API12030964 {
    public static void countVowelsAndConsonants(String text) {
        int vowelCount = 0;
        int consonantCount = 0;
        text = text.toLowerCase();
        for (char ch : text.toCharArray()) { 
            switch(ch) {
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u':
                    vowelCount++;
                    break;
                default:
                    consonantCount++;
                    break;
            }
        } 
        System.out.println("VowelCount : " + vowelCount);
        System.out.println("ConsonantCount is : " + consonantCount);
    }
}
