package com.code2api.api;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Code2API1053474 {
    public static void saveStringToFile(String text, String filename) throws IOException {
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(filename));
            writer.write(text);
        } catch (IOException e) {
            // handle exception
        } finally {
            try {
                if (writer != null)
                    writer.close();
            } catch (IOException e) {
                // handle exception
            }
        }
    }
}
