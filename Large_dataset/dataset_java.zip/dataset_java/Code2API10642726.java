package com.code2api.api;
public class Code2API10642726 {
    public static boolean getBooleanValueFromObject(Preference preference, Object newValue) {
        return Boolean.parseBoolean((String) newValue);
    }
}
