package com.code2api.api;
public class Code2API12247007 {
    public static void extractPOS(String inputString) {
        String string = inputString.replaceAll("\\S+/", "").replace(".", "");  
        System.out.println(string);
    }
}
