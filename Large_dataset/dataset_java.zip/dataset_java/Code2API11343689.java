package com.code2api.api;
public class Code2API11343689 {
    public static String splitStringToRemoveParts(String oldString) {
        String firstPart = oldString.substring(0, oldString.indexOf(")")); // ACHMU
        String secondPart = oldString.substring(oldString.indexOf("(")); // (ACH Payment Sys Menus - Online Services)][3:c,1,(M)]
        String newString = firstPart + " " + secondPart.substring(0, secondPart.indexOf(")") + 1); // ACHMU (ACH Payment Sys Menus - Online Services)
        return newString;
    }
}
