package com.code2api.api;
public class Code2API1007297 {
    public static String getCallingClass() {
        Throwable t = new Throwable();
        StackTraceElement[] stackTraceElements = t.getStackTrace();
        return stackTraceElements[1].getClassName();
    }
}
