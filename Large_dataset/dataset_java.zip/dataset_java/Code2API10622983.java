package com.code2api.api;
public class Code2API10622983 {
    public static int countWords(String text) {
        return text.trim().split("\\s+").length;
    }
}
