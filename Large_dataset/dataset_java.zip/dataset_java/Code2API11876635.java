package com.code2api.api;
public class Code2API11876635 {
    public static String getFileNameFromPath(String path) {
        String st = path.replace("\n", "\\n");
        st = st.replace("\\", "\\\\");
        String str = st.substring(st.lastIndexOf("\\")+1);
        return str;
    }
}
