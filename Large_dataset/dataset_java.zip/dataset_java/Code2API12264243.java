package com.code2api.api;
public class Code2API12264243 {
    public static String getCityNameFromAddress(String address) {
        String [] vals = address.split(",");
        return vals[vals.length - 2];
    }
}
