package com.code2api.api;
public class Code2API10897499 {
    public static void replaceFirstOccurrence(String input, String target) {
        String newString = input.substring(input.indexOf(target) + target.length());
        System.out.println(newString);
    }
}
