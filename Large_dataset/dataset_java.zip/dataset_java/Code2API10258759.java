package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API10258759 {
    public static void extractHttpLinks(String jsonResult) {
        String httpLinkPattern = "https?://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]";
        Pattern p = Pattern.compile(httpLinkPattern);
        Matcher m = p.matcher(jsonResult);
        while (m.find())
            System.out.println("Found http link: " + m.group());
    }
}
