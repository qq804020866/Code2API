package com.code2api.api;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Code2API10036076 {
    public static void sortTwoDimensionArrayList(ArrayList<ArrayList<Double>> data) {
        for(int c=0; c<data.get(0).size(); c++) {
            List<Double> col = new ArrayList<Double>();
            for( int r=0; r<data.size(); r++ )
                col.add( data.get(r).get(c) );

            Collections.sort(col);

            for( int r=0; r<col.size(); r++ )
                data.get(r).set( c, col.get(r) );
        }
    }
}
