package com.code2api.api;
public class Code2API11073496 {
    public static void clearConsole() {
        System.out.print('\f');
    }
}
