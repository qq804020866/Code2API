package com.code2api.api;
import java.io.File;
import java.io.RandomAccessFile;

public class Code2API13161217 {
    public static void writeEnterToFile() {
        String enter = System.getProperty("line.separator");

        String BeforEnter = "It's Before Enter...";
        String AfterEnter = "It must be on next Line...";

        File MyFile = new File("test.txt");
        try {
            RandomAccessFile TextFile = new RandomAccessFile(MyFile, "rw");
            TextFile.writeChars(BeforEnter);
            TextFile.writeChars(enter);
            TextFile.writeChars(AfterEnter);
            TextFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
