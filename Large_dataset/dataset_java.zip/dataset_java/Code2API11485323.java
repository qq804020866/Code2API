package com.code2api.api;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Code2API11485323 {
    public static FileInputStream getFileContent(File file) throws FileNotFoundException {
        return new FileInputStream(file);
    }
}
