package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API12595265 {
    public static String getStringBetweenCharacters(String input, char startChar, char endChar) {
        Pattern p = Pattern.compile("\\" + startChar + ".*?\\" + endChar);
        Matcher m = p.matcher(input);
        if (m.find()) {
            return m.group().substring(1, m.group().length() - 1);
        }
        return null;
    }
}
