package com.code2api.api;
public class Code2API11583233 {
    public static boolean isStringObject(Object object) {
        return object instanceof String;
    }
}
