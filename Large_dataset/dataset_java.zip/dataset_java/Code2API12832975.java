package com.code2api.api;
public class Code2API12832975 {
    public static String replaceLastChar(String str, char replacement) {
        return str.substring(0, str.length() - 1) + replacement;
    }
}
