package com.code2api.api;
import java.text.DecimalFormat;

public class Code2API12412743 {
    public static String formatNumberWithCommas(int number) {
        return new DecimalFormat("#,###,###").format(number);
    }
}
