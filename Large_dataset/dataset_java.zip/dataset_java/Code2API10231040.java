package com.code2api.api;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Code2API10231040 {
    public static List<String> convertStringArrayToList(String[] strings) {
        return new ArrayList<String>(Arrays.asList(strings));
    }
}
