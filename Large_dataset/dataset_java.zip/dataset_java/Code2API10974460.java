package com.code2api.api;
public class Code2API10974460 {
    public static String[] getBoatNamesArray() {
        String[] boatNames = null;
        if(boatNames != null){
            boatArray1 = new Boat[boatNames.length];
            if(boatNames.length > 0){
                try(BufferedWriter fileOut = Files.newBufferedWriter(outPath, Charset.forName("UTF-16"))){
                    for(j = 0 ; j < boatNames.length ; j++){
                        String delimiters = "[. ,]";
                        int limit = -1;
                        String[]tokens = boatNames[j].split(delimiters, limit);
                        for(k = 0 ; k < tokens.length ; ++k){
                            firstChar = tokens[k].charAt(0);
                            firstChar = Character.toUpperCase(firstChar);
                            char[] tokenArray = tokens[k].toCharArray();                            
                            String text = new String(tokenArray, 1, (tokenArray.length - 1) );                          
                            tokens[k] = firstChar + text;                   
                            result = result + tokens[k] + " ";
                            if(k != tokens.length - 1){
                                continue;
                            }else{
                                result = result.trim();
                                boatNames[k] = result;
                                result = " ";
                            }
                        }       
                        firstLetter = boatNames[j].charAt(0);
                        if((firstLetter == 'B') || (firstLetter == 'C') || (firstLetter == 'N')){
                            boatArray1[j] = new RaceBoat();
                        }else{
                            boatArray1[j] = new SailBoat();
                        }
                        boatArray1[j].christenBoat(boatNames[j]);               
                    }
                    System.out.println("\n");
                    for(l = 0 ; l < boatNames.length ; ++l){            
                        secondLetter = Character.toUpperCase(boatNames[l].charAt(1));
                        if((secondLetter == 'A') || (secondLetter == 'E')){
                            if(l > 0){
                                fileOut.newLine();
                            }
                            fileOut.write(boatArray1[l].goFast());
                        }else{
                            if(l > 0){
                                fileOut.newLine();
                            }
                            fileOut.write(boatArray1[l].goSlow());
                        }           
                        fileOut.newLine();
                        fileOut.write(boatArray1[l].launchBoat());
                        fileOut.newLine();
                        fileOut.write(boatArray1[l].whatIsBoatState());
                        fileOut.newLine();
                    }
                    boatArray2 = new Boat[3];
                    boatArray2[0] = new SailBoat();
                    boatArray2[1] = new RaceBoat("Endurance", true);
                    boatArray2[2] = new RaceBoat(false);
                    for(m = 0 ; m < boatArray2.length ; ++m){
                        fileOut.newLine();
                        fileOut.write(boatArray2[m].toString());
                        fileOut.newLine();
                        fileOut.write(boatArray2[m].launchBoat());
                        fileOut.newLine();
                        fileOut.write(boatArray2[m].whatIsBoatState());
                        fileOut.newLine();
                    }
                    fileOut.newLine();
                    fileOut.write("There are " + Boat.boatCount + " boats in the fleet this morning.");
                }catch(IOException e){
                    System.err.println("Error writing outPath: " + outPath);
                    e.printStackTrace();
                }
            }else{
                System.out.println("\n\n\nArgh!... you forgot to enter ship names scalawag!" +
                    "\n\n\n\tPlease try again!");
            }
            System.out.println("\nThe Fleet Registry is completed, press ENTER to continue.\n");
            try{
                System.in.read();
            } catch(IOException e){
                return;
            }
        }
        return boatNames;
    }
}
