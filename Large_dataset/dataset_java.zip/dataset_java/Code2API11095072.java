package com.code2api.api;
public class Code2API11095072 {
    public static String generateRandomHexValue(int range) {
        return String.format("%x",(int)(Math.random()*range));
    }
}
