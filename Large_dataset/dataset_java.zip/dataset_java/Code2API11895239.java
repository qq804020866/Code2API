package com.code2api.api;
public class Code2API11895239 {
    public static String capitalizeFirstLetterOfWords(String input) {
        String sString = input.toLowerCase();
        sString = Character.toString(sString.charAt(0)).toUpperCase()+sString.substring(1);
        return sString;
    }
}
