package com.code2api.api;
import java.util.ArrayList;
import java.util.Arrays;

public class Code2API10509014 {
    public static ArrayList convertSortedArrayToList(int[] sortedArray) {
        ArrayList list = new ArrayList(Arrays.asList(sortedArray));
        return list;
    }
}
