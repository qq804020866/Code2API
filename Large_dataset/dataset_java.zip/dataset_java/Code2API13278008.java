package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API13278008 {
    public static String extractUrlFromMessage(String message) {
        String regex = "((https?:\\/\\/)?(www.)?(([a-zA-Z0-9-]){2,}\\.){1,4}([a-zA-Z]){2,6}(\\/([a-zA-Z-_/.0-9#:+?%=&;,]*)?)?)";
        Matcher m = Pattern.compile(regex).matcher(message);
        if (m.find()) {
            return m.group();
        }
        return null;
    }
}
