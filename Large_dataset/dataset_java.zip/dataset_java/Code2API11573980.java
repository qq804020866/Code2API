package com.code2api.api;
public class Code2API11573980 {
    public static int countSpecialCharacter(String str, char specialChar) {
        int counter = 0;
        for (Character c: str.toCharArray()) {
            if (c.equals(specialChar)) {
                counter++;
            }
        }
        return counter;
    }
}
