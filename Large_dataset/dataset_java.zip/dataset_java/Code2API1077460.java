package com.code2api.api;
public class Code2API1077460 {
    public static String[] splitString(String optionsTxt) {
        return optionsTxt.split("(?<!\\\\);");
    }
}
