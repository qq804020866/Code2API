package com.code2api.api;
import java.util.Scanner;

public class Code2API11820761 {
    public static double getUserInputAsDouble() {
        Scanner sc = new Scanner(System.in);
        return sc.nextDouble();
    }
}
