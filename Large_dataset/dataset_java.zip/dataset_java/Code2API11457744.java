package com.code2api.api;
public class Code2API11457744 {
    public static void setThreadName() {
        Thread.currentThread().setName("MyThread");
    }
}
