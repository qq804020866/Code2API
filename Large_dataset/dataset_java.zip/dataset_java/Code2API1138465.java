package com.code2api.api;
public class Code2API1138465 {
    public static String[] splitStringIntoCharacters(String inputString) {
        return inputString.split("(?!^)");
    }
}
