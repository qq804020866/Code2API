package com.code2api.api;
import java.util.Calendar;

public class Code2API11858703 {
    public static void setFirstDayOfWeek() {
        Calendar cal = Calendar.getInstance();
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        int rec = cal.get(Calendar.WEEK_OF_MONTH);
        System.out.println(rec);
    }
}
