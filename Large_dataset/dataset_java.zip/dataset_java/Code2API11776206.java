package com.code2api.api;
public class Code2API11776206 {
    public static String parseAndAddTime(String time1, String time2) {
        String[] split1 = time1.split(":");
        String[] split2 = time2.split(":");

        int total = 60 * Integer.parseInt(split1[0]) +
                    Integer.parseInt(split1[1]) +
                    60 * Integer.parseInt(split2[0]) +
                    Integer.parseInt(split2[1]);

        int hours = total / 60;
        int minutes = total - hours * 60;
        return hours + ":" + minutes;
    }
}
