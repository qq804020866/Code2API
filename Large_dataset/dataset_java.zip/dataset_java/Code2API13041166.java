package com.code2api.api;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.SortedMap;

public class Code2API13041166 {
    public static void rewriteFileWithDifferentCharset(String inputFile, String inputEncoding, String outputFile, String outputEncoding) {
        try {
            FileInputStream fis = new FileInputStream(inputFile);
            InputStreamReader isr = new InputStreamReader(fis, inputEncoding);
            BufferedReader in = new BufferedReader(isr);

            FileOutputStream fos = new FileOutputStream(outputFile);
            OutputStreamWriter osw = new OutputStreamWriter(fos, outputEncoding);
            BufferedWriter out = new BufferedWriter(osw);

            String line;
            while ((line = in.readLine()) != null) {
                out.write(line);
                out.newLine();
            }

            in.close();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static SortedMap<String, Charset> getAvailableCharsets() {
        return Charset.availableCharsets();
    }
}
