package com.code2api.api;
public class Code2API12616361 {
    public static String getJdkVersion() {
        return System.getProperty("java.version");
    }
}
