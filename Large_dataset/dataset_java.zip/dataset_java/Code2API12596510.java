package com.code2api.api;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Code2API12596510 {
    public static void updateValueForKey(HashMap<String, Set<String>> map, String key, String value) {
        Set<String> setValue = map.get(key);
        if (setValue != null) {
            if (setValue.size() <= 1) {
                setValue.add(value);
            }
        } else {
            map.put(key, new HashSet<String>());
        }
    }
}
