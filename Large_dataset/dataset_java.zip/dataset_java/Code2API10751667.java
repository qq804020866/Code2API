package com.code2api.api;
public class Code2API10751667 {
    public static void insertValuesInTwoDimensionalArray(String[][] array, String value) {
        for(int i = 0; i < array.length; i++) {
            for(int y = 0; y < array[i].length; y++) {
                array[i][y] = value;
            }
        }
    }
}
