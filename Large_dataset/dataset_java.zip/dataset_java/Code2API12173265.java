package com.code2api.api;
import java.util.HashMap;
import java.util.Map;

public class Code2API12173265 {
    public static Map<String, Object> passDateParametersToJasperReport(Date fromDate, Date toDate) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("frm_date", new java.sql.Date(fromDate.getTime()));
        map.put("to_date", new java.sql.Date(toDate.getTime()));
        return map;
    }
}
