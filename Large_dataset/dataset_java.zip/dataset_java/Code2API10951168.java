package com.code2api.api;
import java.math.BigDecimal;

public class Code2API10951168 {
    public static boolean checkIfBigDecimalIsZero(BigDecimal price) {
        return price.compareTo(BigDecimal.ZERO) == 0;
    }
}
