package com.code2api.api;
import java.util.ArrayList;
import java.util.List;

public class Code2API10498845 {
    public static String addNewlineToString(TreeNode node) {
        String treeStructure = "TreeNode [key=" + node.getKey() +  "]";
        if(node.getChildren()!=null){
            for(TreeNode child:node.getChildren()){
                treeStructure = treeStructure + "\n" + "-->" + child.toString() + "\n";
            }
        }
        return treeStructure;
    }
}
