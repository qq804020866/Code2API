package com.code2api.api;
import javax.swing.JTable;

public class Code2API11715867 {
    public static JTable displayDataInTable(String start, String desc_text) {
        Object[][] arr = {{start, desc_text}};
        String[] header = {"start", "desc_text"};
        JTable table = new JTable(arr, header);
        return table;
    }
}
