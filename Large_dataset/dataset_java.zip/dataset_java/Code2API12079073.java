package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API12079073 {
    public static String getStringBetweenBrackets(String input) {
        Matcher m = Pattern.compile("\\]([^\\[]*)\\[").matcher(input);
        while (m.find()) {
            return m.group(1);
        }
        return null;
    }
}
