package com.code2api.api;
public class Code2API11579657 {
    public static String getSubstringUntilSecondDot(String input) {
        String[] split = input.split("\\.");
        return split[0] + "." + split[1];
    }
}
