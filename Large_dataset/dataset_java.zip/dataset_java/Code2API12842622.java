package com.code2api.api;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

public class Code2API12842622 {
    public static void simulateKeyboardKey(int keyEvent) throws AWTException {
        try { 
            Robot robot = new Robot(); 
            robot.keyPress(keyEvent); 
        } catch (AWTException e) { 
            e.printStackTrace(); 
        }
    }
}
