package com.code2api.api;
import java.util.ArrayList;
import java.util.HashMap;

public class Code2API10928109 {
    public static HashMap<String, ArrayList<String>> constructMap(List<DataObject> data) {
        HashMap<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();

        ArrayList<String> carList = new ArrayList<String>();
        carList.add("toyota");
        carList.add("bmw");
        carList.add("honda");

        map.put("car", carList);

        ArrayList<String> fruitList = new ArrayList<String>();
        fruitList.add("apple");
        fruitList.add("banana");

        map.put("fruit", fruitList);

        return map;
    }
}
