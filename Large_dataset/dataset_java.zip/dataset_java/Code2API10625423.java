package com.code2api.api;
import java.util.Locale;
import java.text.SimpleDateFormat;

public class Code2API10625423 {
    public static void getSpanishLocales() {
        Locale.setDefault(new Locale("ES"));
        Locale[] locales = SimpleDateFormat.getAvailableLocales();
        for(Locale l : locales) {
            System.out.println(l.getDisplayName());
        }
    }
}
