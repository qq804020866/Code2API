package com.code2api.api;
import java.io.IOException;

public class Code2API12908353 {
    public static void startMsAccessDatabase() throws IOException {
        String[] command = {"cmd", "/c", "start", "MSACCESS", "D:\\My Documents\\Database.accdb"};
        Runtime.getRuntime().exec(command);
    }
}
