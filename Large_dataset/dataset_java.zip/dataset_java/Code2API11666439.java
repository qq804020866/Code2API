package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API11666439 {
    public static void getRegexMatchedGroupValues(String time, String timeRegex) {
        Pattern pattern = Pattern.compile(timeRegex);
        Matcher matcher = pattern.matcher(time);
        if (matcher.matches()) {
            String hours = matcher.group(1);
            String minutes = matcher.group(2);
            String seconds = matcher.group(3);
            String miliSeconds = matcher.group(4);
            System.out.println(hours + ", " + minutes  + ", " + seconds + ", " + miliSeconds);
        }
    }
}
