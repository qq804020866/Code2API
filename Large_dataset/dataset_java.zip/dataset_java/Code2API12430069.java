package com.code2api.api;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Code2API12430069 {
    public static void runSSHCommand(String command) throws IOException {
        Process pr = Runtime.getRuntime().exec(command);
        BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));
        String line = null;

        while ((line = input.readLine()) != null)
            System.out.println(line);
    }
}
