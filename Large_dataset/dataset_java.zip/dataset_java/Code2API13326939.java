package com.code2api.api;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API13326939 {
    public static List<Integer> findQueryPositions(String documentText, String query) {
        List<Integer> positions = new ArrayList();
        Pattern p = Pattern.compile(query);  // insert your pattern here
        Matcher m = p.matcher(documentText);
        while (m.find()) {
           positions.add(m.start());
        }
        return positions;
    }
}
