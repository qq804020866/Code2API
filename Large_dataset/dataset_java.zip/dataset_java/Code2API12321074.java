package com.code2api.api;
public class Code2API12321074 {
    public static String getStringBeforeChar(String input, String delimiter) {
        return input.substring(0, input.indexOf(delimiter));
    }
}
