package com.code2api.api;
public class Code2API13138375 {
    public static String splitString(String input) {
        String str = input;
        return str.substring(0, 4) + '-' + str.substring(4);
    }
}
