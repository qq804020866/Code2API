package com.code2api.api;
import java.util.Calendar;
import java.util.Date;

public class Code2API12499122 {
    public static Date generateDateFromMonthAndYear(int month, int year) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.YEAR, year);
        return calendar.getTime();
    }
}
