package com.code2api.api;
public class Code2API12558329 {
    public static boolean isIntegerValue(Object value) {
        return (value == (int)value);
    }
}
