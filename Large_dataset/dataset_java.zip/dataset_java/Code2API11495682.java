package com.code2api.api;
public class Code2API11495682 {
    public static int getFractionalDigits(double number) {
        String numberStr = Double.toString(number);
        String fractionalStr = numberStr.substring(numberStr.indexOf('.')+1);
        int fractional = Integer.valueOf(fractionalStr);
        return fractional;
    }
}
