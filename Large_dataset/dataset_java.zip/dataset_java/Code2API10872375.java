package com.code2api.api;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;

public class Code2API10872375 {
    public static Shape createRotatedEllipse() {
        return AffineTransform.getRotateInstance(Math.PI / 4)
          .createTransformedShape(new Ellipse2D.Double(0, 0, 2, 1));
    }
}
