package com.code2api.api;
import javax.swing.JOptionPane;

public class Code2API12377938 {
    public static void countEqualWords(String input) {
        String[] wordList = input.split(" ");
        System.out.println("Place:\tWord:\tCount: ");
        int[] wordCount = new int[wordList.length];
        for (int i = 0; i < wordList.length; i++) {
            for (int j = 0; j < wordList.length; j++){
                if (i != j && wordList[i].compareTo(wordList[j]) == 0) {
                    wordCount[i]++;
                }
            }
            System.out.println(i + "\t" + wordList[i]+ "\t" + wordCount[i]);
        }
    }
}
