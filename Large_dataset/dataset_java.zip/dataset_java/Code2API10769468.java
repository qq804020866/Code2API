package com.code2api.api;
import java.util.ArrayList;
import java.util.Arrays;

public class Code2API10769468 {
    public static void convertArrayListToStringArray(ArrayList<ArrayList<String>> childrenSuperList) {
        String[][] array = new String[childrenSuperList.size()][];
        int i = 0, j = 0;
        for (ArrayList<String> row : childrenSuperList) {
            array[i] = new String[row.size()];
            j = 0;
            for (String str : row) {
                array[i][j] = str;
                j++;
            }
            i++;
        }
        System.out.println(Arrays.deepToString(array));
    }
}
