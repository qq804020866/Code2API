package com.code2api.api;
public class Code2API12133431 {
    public static void validateNull(String str) {
        if (str == null || str.length() == 0) {
            System.out.println("String is empty");
        } else { 
            System.out.println("String is not empty");
        }
    }
}
