package com.code2api.api;
public class Code2API12208914 {
    public static String escapeDollarSign(String input) {
        String x = "aaa XXX bbb";
        String replace = "XXX";
        String y = "xy$z";
        x = x.replace(replace, y);
        return x;
    }
}
