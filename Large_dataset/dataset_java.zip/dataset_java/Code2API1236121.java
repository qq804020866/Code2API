package com.code2api.api;
public class Code2API1236121 {
    public static String[] splitTextFileLine(String line) {
        return line.split("\\s+");
    }
}
