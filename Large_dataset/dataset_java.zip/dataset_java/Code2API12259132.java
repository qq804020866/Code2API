package com.code2api.api;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Code2API12259132 {
    public static Collection<Map<String, Object>> createJasperReportData(BigDecimal amount1, Double price1, BigDecimal amount2, Double price2) {
        Collection<Map<String, Object>> records = new ArrayList<Map<String,Object>>();

        Map<String, Object> record1 = new HashMap<String, Object>();

        record1.put("Name","dendi");
        record1.put("Amount",amount1); //amount1 is a BigDecimal for 150.0
        record1.put("Price", price1); // price1 is a Double for 12.500

        records.add(record1); // add each record to your map

        Map<String, Object> record2 = new HashMap<String, Object>();
        record2.put("Name","patricia");
        record2.put("Amount",amount2); //amount2 is a BigDecimal 
        record2.put("Price", price2); // price2 is a Double 

        records.add(record2); // add each record to your map
        
        return records;
    }
}
