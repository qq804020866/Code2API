package com.code2api.api;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Code2API11307663 {
    public static int getBloodDonationCount(String bloodgroup) throws Exception {
        String dataSourceName = "testSqlDb";
        String dbUrl = "jdbc:odbc:" + dataSourceName;
        try {
            bloodgroup = jTextField2.getText().trim();
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection con = DriverManager.getConnection(dbUrl, "", "");
            Statement s = con.createStatement();

            ResultSet rs;
            String query = "SELECT COUNT(*) FROM blood_donation WHERE blood_group='"
                + bloodgroup + "'";

            rs = s.executeQuery(query);

            while (rs.next()) {
                System.out.println("COUNT(*)=" + rs.getInt("COUNT(*)"));
            }

            s.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e.getMessage(), "erro",
                JOptionPane.ERROR_MESSAGE, null);
        }
    }
}
