package com.code2api.api;
public class Code2API10228400 {
    public static String getFolderPath(String filePath) {
        return filePath.substring(0, filePath.lastIndexOf("/") + 1);
    }
}
