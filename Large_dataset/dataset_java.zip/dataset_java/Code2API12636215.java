package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API12636215 {
    public static void findStringPattern(String inputString) {
        Pattern p = Pattern.compile("\\$\\[.*?\\]\\$");
        Matcher m = p.matcher(inputString);
        while(m.find()){
            String b =  m.group();
            System.out.println(">> " +b.substring(2, b.length()-2));
        }
    }
}
