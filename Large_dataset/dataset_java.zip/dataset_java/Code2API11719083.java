package com.code2api.api;
import java.util.Arrays;
import java.util.List;

public class Code2API11719083 {
    public static int getItemPosition(String[] items, String target) {
        List<String> list = Arrays.asList(items);
        return list.indexOf(target);
    }
}
