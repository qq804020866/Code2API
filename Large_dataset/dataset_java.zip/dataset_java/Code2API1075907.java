package com.code2api.api;
public class Code2API1075907 {
    public static void catchAllExceptions() {
        try {
            //...file IO...
        } catch(Exception e) {
            //...do stuff with e, such as check its type or log it...
        }
    }
}
