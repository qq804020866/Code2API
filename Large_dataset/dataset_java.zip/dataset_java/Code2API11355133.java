package com.code2api.api;
import java.util.TimeZone;
import java.util.Date;

public class Code2API11355133 {
    public static String deactivateDaylightSaving() {
        return TimeZone.getDefault().useDaylightTime() + "\n" + TimeZone.getDefault().inDaylightTime(new Date());
    }
}
