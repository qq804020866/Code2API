package com.code2api.api;
public class Code2API11610302 {
    public static String removeLastNumericCharacters(String input) {
        return input.replaceAll("\\d*$", "");
    }
}
