package com.code2api.api;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Code2API12958334 {
    public static String getPhoneticTranslation() {
        String letter;
        String phonetic;
        Map<String,String> codes = new HashMap<String,String>();
        codes.put("A","Alpha");
        codes.put("B","Bravo");
        codes.put("C","Charlie");
        codes.put("D","Delta");
        // not showing all "puts" to make it shorter
        codes.put("W","Whiskey");
        codes.put("X","X-Ray");
        codes.put("Y","Yankee");
        codes.put("Z","Zulu");
        codes.put("0","Zero");
        codes.put("1","One");
        // not showing all "puts" to make it shorter
        codes.put("9","Nine");    

        Scanner kb = new Scanner(System.in);

        System.out.print("Please enter a letter: ");
        letter = kb.next().toUpperCase(); // convert key to uppercase

        phonetic = codes.get(letter);  // search the value in the map using the key

        if (phonetic == null) {
            System.out.println("bad code : " + letter);
        } else {
            System.out.println("Phonetic: " + phonetic);
        }
        return null;
    }
}
