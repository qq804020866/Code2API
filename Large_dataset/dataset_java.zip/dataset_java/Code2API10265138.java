package com.code2api.api;
import javax.swing.JOptionPane;

public class Code2API10265138 {
    public static void displayMultipleValues() {
        String a=JOptionPane.showInputDialog(null,"Enter a number");
        int a1=Integer.parseInt(a);
        String b=JOptionPane.showInputDialog(null,"Enter a number");
        int b1=Integer.parseInt(b);

        int c=a1+b1;
        String s = "a1: "+a1+" b1: "+b1+"c: "+c;
        JOptionPane.showMessageDialog(null,s);
    }
}
