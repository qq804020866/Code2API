package com.code2api.api;
import java.util.regex.Pattern;

public class Code2API1138593 {
    public static String replaceStringInParentheses(String input) {
        return input.replaceAll("\\(.+\\)", "");
    }
}
