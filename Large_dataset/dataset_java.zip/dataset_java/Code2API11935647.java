package com.code2api.api;
import java.lang.System;

public class Code2API11935647 {
    public static String getServerRefValue() {
        return System.getProperty("server.ref");
    }
}
