package com.code2api.api;
import java.util.concurrent.TimeUnit;

public class Code2API12125340 {
    public static long convertMilliseconds(long milliseconds) {
        long days = TimeUnit.MILLISECONDS.toDays(milliseconds);
        return days;
    }
}
