package com.code2api.api;
public class Code2API12671471 {
    public static String replaceSpaceWithPercent20(String url) {
        url = url.replaceAll(" ", "%20");
        return url;
    }
}
