package com.code2api.api;
public class Code2API11502664 {
    public static boolean containsRTLCharacter(String s) {
        char[] chars = s.toCharArray();
        for(char c: chars){
            if(c >= 0x600 && c <= 0x6ff){
                return true;
            }
        }
        return false;
    }
}
