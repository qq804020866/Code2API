package com.code2api.api;
public class Code2API12980021 {
    public static String[] splitStringWithQuotes(String inputString) {
        String[] ar = inputString.replaceAll("\"", "").replace("[", "").replace("]", "").split(",");
        return ar;
    }
}
