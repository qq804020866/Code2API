package com.code2api.api;
import java.util.ArrayList;

public class Code2API10237345 {
    public static ArrayList<ArrayList<Integer>> convertTextLineToIntArray(ArrayList<String> names) {
        ArrayList<ArrayList<Integer>> allratings = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) {
            String line = names.get(i);
            if (i % 2 == 1) {
                String[] numbers = line.split(" ");
                ArrayList<Integer> inumbers = new ArrayList<Integer>();
                for (String s : numbers)
                    inumbers.add(Integer.parseInt(s));
                allratings.add(inumbers);
            }
        }
        return allratings;
    }
}
