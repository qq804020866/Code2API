package com.code2api.api;
import java.util.Calendar;

public class Code2API10428983 {
    public static int getNumberOfSpecificDay(int month, int year, int dayOfWeek) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.MONTH, month);
        c.set(Calendar.YEAR, year);
        int th = 0;
        int maxDayInMonth = c.getMaximum(Calendar.MONTH);
        for (int d = 1;  d <= maxDayInMonth;  d++) {
            c.set(Calendar.DAY_OF_MONTH, d);
            int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek == dayOfWeek) {
                th++;
            }
        }
        return th;
    }
}
