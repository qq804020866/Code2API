package com.code2api.api;
public class Code2API11877548 {
    public static void separatePunctuation(String sentence) {
        System.out.println(sentence.replaceAll("\\s*([,.?!\"'])\\s*", " $1 "));
    }
}
