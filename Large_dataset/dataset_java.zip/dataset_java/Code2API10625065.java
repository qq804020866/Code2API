package com.code2api.api;
import org.apache.log4j.Logger;

public class Code2API10625065 {
    public static Class getCallingClass() {
        /*
        Calls Thread.getStackTrace() and back traces until the class on the stack trace 
        != this.getClass(). 
        */
        return classFound;
    }
}
