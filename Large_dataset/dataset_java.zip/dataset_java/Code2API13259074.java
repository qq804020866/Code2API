package com.code2api.api;
import java.io.PrintStream;

public class Code2API13259074 {
    public static void printToConsole() {
        System.out.println();
    }
}
