package com.code2api.api;
public class Code2API10790073 {
    public static String useRegexToShowNumbers(String str) {
        return str.replaceAll("[\\P{L}\\p{N}\\p{Latin}/u&&[^\\d]]", " ");
    }
}
