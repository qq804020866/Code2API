package com.code2api.api;
import java.text.MessageFormat;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Code2API12138411 {
    public static String replaceValuesInProperties(String propertiesFilePath, String key, String value) throws IOException {
        Properties properties = new Properties();
        properties.load(new FileInputStream(propertiesFilePath));
        String calculatedValue = "120"; // replace with your calculated value
        String propertyValue = properties.getProperty(key);
        String replacedValue = MessageFormat.format(propertyValue, calculatedValue);
        return replacedValue;
    }
}
