package com.code2api.api;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import java.awt.Container;

public class Code2API10622986 {
    public static void positionButtonUnderTable(JFrame frame, JTable table, JButton button) {
        Container contentPane = frame.getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
        contentPane.add(button, BorderLayout.SOUTH);
    }
}
