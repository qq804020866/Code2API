package com.code2api.api;
public class Code2API1169868 {
    public static String escapeBackslashes(String input) {
        return input.replace("\\", "/");
    }
}
