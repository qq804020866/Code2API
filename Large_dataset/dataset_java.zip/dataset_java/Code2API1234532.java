package com.code2api.api;
import java.util.regex.Pattern;

public class Code2API1234532 {
    public static String replaceAmpersand(String input) {
        return input.replaceAll("&", "&amp;");
    }
}
