package com.code2api.api;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.StringTokenizer;

public class Code2API12242834 {
    public static void separateOutputDataWithLine(String fileName) throws FileNotFoundException, IOException {
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String strLine = null;
        StringTokenizer st = null;
        int lineNumber = 0, tokenNumber = 0;
        while ((fileName = br.readLine()) != null) {
            lineNumber++;
            strLine = strLine.replace(",", ",|,");
            st = new StringTokenizer(fileName, "|");
            while (st.hasMoreTokens()) {
                tokenNumber++;
                System.out.println("Line # " + lineNumber + " Token : " + st.nextToken());
            }
            tokenNumber = 0;
        }
    }
}
