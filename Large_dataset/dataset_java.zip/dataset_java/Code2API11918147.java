package com.code2api.api;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;

public class Code2API11918147 {
    public static String convertToHex(String decimal) throws IOException {
        BigInteger toHex = new BigInteger(decimal, 16);
        return toHex.toString(16);
    }
}
