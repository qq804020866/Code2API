package com.code2api.api;
public class Code2API12246911 {
    public static String extractPOS(String inputString) {
        return inputString.replaceAll("[^/]+/([^ ]+ ?)", "$1");
    }
}
