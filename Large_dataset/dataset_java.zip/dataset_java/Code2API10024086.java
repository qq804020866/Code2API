package com.code2api.api;
public class Code2API10024086 {
    public static String removeLastPortion(String inputString) {
        String newString = inputString;
        int indexOfLast = inputString.lastIndexOf(".");
        if(indexOfLast >= 0) newString = inputString.substring(0, indexOfLast);
        return newString;
    }
}
