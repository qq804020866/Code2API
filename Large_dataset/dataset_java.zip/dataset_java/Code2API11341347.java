package com.code2api.api;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

public class Code2API11341347 {
    public static List<String> createSynchronizedList() {
        return Collections.synchronizedList(new ArrayList<>());
    }
}
