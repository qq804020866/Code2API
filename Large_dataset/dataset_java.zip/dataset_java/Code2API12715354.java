package com.code2api.api;
public class Code2API12715354 {
    public static boolean checkCharacterType(String character) {
        boolean isChar = character.matches("[a-zA-z]{1}");
        return isChar;
    }
}
