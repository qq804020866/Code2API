package com.code2api.api;
public class Code2API11840104 {
    public static String trimFileExtension(String filename) {
        return filename.substring(0, filename.lastIndexOf('.'));
    }
}
