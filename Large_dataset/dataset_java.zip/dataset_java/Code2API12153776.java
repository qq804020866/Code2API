package com.code2api.api;
import java.awt.print.PrinterJob;

public class Code2API12153776 {
    public static void readDataFromPrnFile() {
        PrinterJob pj = PrinterJob.getPrinterJob();
        pj.printDialog();
    }
}
