package com.code2api.api;
public class Code2API13210640 {
    public static String checkPriceRange(int priceSell, int priceBuy) {
        if (Math.abs(priceSell-priceBuy)>(priceSell/10))
            return "the price isn't within 10%";
        else
            return "the price is within 10%";
    }
}
