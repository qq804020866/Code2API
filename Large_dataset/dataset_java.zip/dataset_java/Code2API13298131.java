package com.code2api.api;
public class Code2API13298131 {
    public static void displayHexValue(int value) {
        System.out.println(Integer.toHexString(value));
    }
}
