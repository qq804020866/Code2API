package com.code2api.api;
public class Code2API1276096 {
    public static String formatFloatingNumbers(double value) {
        return String.format("%.2f", value);
    }
}
