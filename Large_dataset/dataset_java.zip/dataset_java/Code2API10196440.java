package com.code2api.api;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Code2API10196440 {
    public static void readFileAndPrintContent(String filePath) throws FileNotFoundException {
        try { 
            BufferedReader fIn = new BufferedReader(new FileReader(filePath));
            String in;
            try {
                while((in = fIn.readLine()) != null) {
                    System.out.println(in);
                }
                fIn.close();
            }
            catch (IOException ex) {
                Logger.getLogger(WordProcessor.class.getName()).log(Level.SEVERE, null, ex);
            }

            try {
                fIn.close();
            }
            catch (IOException ex) {
                Logger.getLogger(WordProcessor.class.getName()).log(Level.SEVERE, null, ex);
            }

        } 
        catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "File does not exist");
        }
    }
}
