package com.code2api.api;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Iterator;

public class Code2API11649404 {
    public static Object getFirstElement(Map<Integer, Integer> m) {
        Set<Map.Entry<Integer, Integer>> s = m.entrySet();
        Iterator<Map.Entry<Integer, Integer>> i = s.iterator();
        if (i.hasNext()) {
            return i.next();
        }
        return null;
    }
}
