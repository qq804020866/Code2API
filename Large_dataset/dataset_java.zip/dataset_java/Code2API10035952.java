package com.code2api.api;
public class Code2API10035952 {
    public static void continueTimerInBackground() {
        // The easiest way to do what you want is to save the current system time when your activity is stopped.
        // When it is resumed again just check how long it passed and update the timer accordingly.
        // To get the current time use
        long currentTime = System.currentTimeMillis();

        // Have a long member variable that takes the value of current time in onStop.
        // Make sure it's also saved in onSaveInstanceState and restored in onRestoreInstanceState.
        // Once you are in onResume the timer value must be set to old value + (currentTime - savedTime).
    }
}
