package com.code2api.api;
import java.util.Set;
import java.util.TreeSet;

public class Code2API12314773 {
    public static Set<String> getOrderedSet() {
        Set<String> s = new TreeSet<String>();
        s.add("B");
        s.add("C");
        s.add("A");
        return s;
    }
}
