package com.code2api.api;
import javax.swing.JFrame;

public class Code2API12961362 {
    public static void minimizeJWindow(JWindow window) {
        window.setUndecorated(true);
    }
}
