package com.code2api.api;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;
import javax.swing.ButtonGroup;

public class Code2API11256467 {
    public static void addRadioButtonsToForm(JFrame frame, String radioButton1Text, String radioButton2Text) {
        JPanel contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout(0, 0));
        frame.setContentPane(contentPane);
        
        JRadioButton rb1 = new JRadioButton(radioButton1Text);
        JRadioButton rb2 = new JRadioButton(radioButton2Text);
        
        ButtonGroup group = new ButtonGroup();
        group.add(rb1);
        group.add(rb2);
        
        contentPane.add(rb1);
        contentPane.add(rb2);
    }
}
