package com.code2api.api;
public class Code2API11880573 {
    public static void concatenateStrings(String data) {
        StringBuilder out = new StringBuilder();
        for (String set : data.split("\n\n\n")) {
            for (String line : set.split("\n")) {
                out.append(line).append(',');
            }
            out.setCharAt(out.length(), '\n');
        }
        System.out.println(out);
    }
}
