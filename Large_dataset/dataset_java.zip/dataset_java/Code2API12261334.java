package com.code2api.api;
public class Code2API12261334 {
    public static void printShorthand(int a, int b) {
        System.out.println(a < b ? "a < b" : "a >= b");
    }
}
