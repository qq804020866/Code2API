package com.code2api.api;
import java.lang.NumberFormatException;

public class Code2API10367296 {
    public static void trapNumberFormatException(String numStr) throws NumberFormatException {
        try {
            int num = Integer.parseInt(numStr);
        } catch (NumberFormatException nfe) {
            // not a number
        }
    }
}
