package com.code2api.api;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.GridLayout;

public class Code2API11933909 {
    public static void showGridlineInGridLayout(JPanel panel) {
        panel.setLayout(new GridLayout(10, 10, -1, -1));
        panel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));

        for (int i = 0; i < (10 * 10); i++) {
            final JLabel label = new JLabel("Label");
            label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            panel.add(label);
        }
    }
}
