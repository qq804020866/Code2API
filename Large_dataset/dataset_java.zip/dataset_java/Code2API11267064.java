package com.code2api.api;
import com.sun.javafx.runtime.VersionInfo;

public class Code2API11267064 {
    public static String getJavaFXVersion() {
        return VersionInfo.getRuntimeVersion();
    }
}
