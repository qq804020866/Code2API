package com.code2api.api;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Code2API10409516 {
    public static void readFromStandardInputNonBlocking() throws IOException {
        long end = System.currentTimeMillis() + 60 * 10;
        InputStreamReader fileInputStream = new InputStreamReader(System.in);
        BufferedReader bufferedReader = new BufferedReader(fileInputStream);
        try {
            while (System.currentTimeMillis() < end) {
                if (bufferedReader.ready()) {
                    System.out.println(bufferedReader.readLine());
                }
            }
        } finally {
            if (bufferedReader != null) {
                bufferedReader.close();
            }
        }
    }
}
