package com.code2api.api;
public class Code2API12555369 {
    public static void subtractIfCharNotFound(char[] secretCh, char guessCh) {
        boolean found = false;
        for(int i = 0; i < secretCh.length; i++) { // loop through each character in the secretCh array
            if (secretCh[i] == guessCh) {
                found = true;
                break;
            }
        }
        if (found)
            System.out.println("guessCh is a letter in the secret word.");
    }
}
