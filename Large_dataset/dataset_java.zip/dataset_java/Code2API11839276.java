package com.code2api.api;
import java.sql.Timestamp;
import java.util.Date;

public class Code2API11839276 {
    public static Date convertTimeStampToDate(Timestamp timeStamp) {
        return new Date(timeStamp.getTime());
    }
}
