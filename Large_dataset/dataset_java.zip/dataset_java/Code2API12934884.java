package com.code2api.api;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;

public class Code2API12934884 {
    public static Rectangle getWindowBounds() {
        return GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
    }
}
