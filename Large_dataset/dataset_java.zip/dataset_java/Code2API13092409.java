package com.code2api.api;
public class Code2API13092409 {
    public static String getWindowsDomains() {
        return System.getenv("USERDOMAIN");
    }
}
