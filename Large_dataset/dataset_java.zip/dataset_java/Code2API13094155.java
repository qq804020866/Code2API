package com.code2api.api;
public class Code2API13094155 {
    public static void displayMultiplicationTable() {
        for (int i=1;i<=10;i++){
            for (int j=1;j<=10;j++)
                System.out.print("\t"+i*j);
            System.out.println(); 
        }
    }
}
