package com.code2api.api;
public class Code2API11576443 {
    public static String[] splitAndRemoveBrackets(String myString) {
        return myString.substring(1, myString.length() - 1).split(";");
    }
}
