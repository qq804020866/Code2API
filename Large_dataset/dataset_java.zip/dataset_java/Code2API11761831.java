package com.code2api.api;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Code2API11761831 {
    public static List<Integer> getDistinctRandomValues(int min, int max) {
        List<Integer> list = new ArrayList<>();
        for(int i = min; i <= max; i++) list.add(i);
        Collections.shuffle(list);
        return list;
    }
}
