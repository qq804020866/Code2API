package com.code2api.api;
import java.io.IOException;
import java.net.ServerSocket;

public class Code2API12264270 {
    public static boolean skipPortIfInUse(int portNumber) throws IOException {
        boolean portTaken = false;
        ServerSocket socket = null;
        try {
            socket = new ServerSocket(portNumber);
        } catch (IOException e) {
            portTaken = true;
        }
        return portTaken;
    }
}
