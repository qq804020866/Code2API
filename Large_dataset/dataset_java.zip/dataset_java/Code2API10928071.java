package com.code2api.api;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Arrays;

public class Code2API10928071 {
    public static Map<String, List<String>> constructDataMap(List<DataObject> dataObjects) {
        Map<String, List<String>> data = new HashMap<String, List<String>>();
        data.put("car", Arrays.asList("toyota", "bmw", "honda"));
        data.put("fruit", Arrays.asList("apple","banana"));
        data.put("computer", Arrays.asList("acer","asus","ibm"));
        return data;
    }
}
