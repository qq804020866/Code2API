package com.code2api.api;
public class Code2API10706091 {
    public static String[] readLinesFromString(String inputString) {
        return inputString.split("\0");
    }
}
