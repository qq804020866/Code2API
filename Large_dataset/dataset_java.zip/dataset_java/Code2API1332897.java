package com.code2api.api;
import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import javax.swing.JPanel;

public class Code2API1332897 {
    public static void createInvisibleArea(JPanel mainPnl) {
        JPanel invisibleArea = new JPanel();
        invisibleArea.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        invisibleArea.setPreferredSize(new Dimension(100, 100));
        mainPnl.add(invisibleArea, BorderLayout.WEST);
    }
}
