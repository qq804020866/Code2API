package com.code2api.api;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Collections;

public class Code2API12855211 {
    public static void explainCode(String[] stringList) {
        List<String> al = Arrays.asList(stringList);
        Set<String> uniqueList = new HashSet<String>(al);
        for (String strCount : uniqueList) {
            System.out.println(strCount + ": " + Collections.frequency(al, strCount));
        }
    }
}
