package com.code2api.api;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

public class Code2API12958492 {
    public static void setJSpinnerNonEditable(JSpinner spinner) {
        spinner.setEditor(new JSpinner.DefaultEditor(spinner));
    }
}
