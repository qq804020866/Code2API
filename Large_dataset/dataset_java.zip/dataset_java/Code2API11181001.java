package com.code2api.api;
public class Code2API11181001 {
    public static String countStringObjects() {
        return "the empty String literal: \"\";\n" +
                "the String literal \"a\";\n" +
                "the copy of the String literal \"a\": new String(\"a\");\n" +
                "the String created by concatenating s and the copy of \"a\";\n" +
                "the String literal \"b\"\n" +
                "the String created by concatenating s and \"b\";";
    }
}
