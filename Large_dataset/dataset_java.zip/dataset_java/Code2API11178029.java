package com.code2api.api;
public class Code2API11178029 {
    public static Integer createIntegerObject(int value) {
        return new Integer(value);
    }
}
