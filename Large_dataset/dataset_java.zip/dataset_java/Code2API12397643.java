package com.code2api.api;
import javax.swing.JEditorPane;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;

public class Code2API12397643 {
    public static void keepWhitespaces(JEditorPane editorPane, String sString) {
        editorPane.setText(sString.replaceAll(" ", "&nbsp;"));
    }
}
