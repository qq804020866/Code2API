package com.code2api.api;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Code2API10000284 {
    public static Map<String, String> getCastedNestedHashMap(ArrayList<HashMap<String, Object>> data, int position) {
        HashMap<String, Object> parentHash = data.get(position);
        HashMap<String, String> childHash = (HashMap<String, String>) parentHash.get("children");
        return childHash;
    }
}
