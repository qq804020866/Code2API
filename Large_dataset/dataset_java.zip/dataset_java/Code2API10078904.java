package com.code2api.api;
import java.util.Arrays;

public class Code2API10078904 {
    public static int[] initializeArray(int size, int value) {
        int[] array = new int[size];
        Arrays.fill(array, value);
        return array;
    }
}
