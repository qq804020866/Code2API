package com.code2api.api;
public class Code2API10233278 {
    public static byte convertToIntToByte(int number) {
        return (byte) number;
    }
}
