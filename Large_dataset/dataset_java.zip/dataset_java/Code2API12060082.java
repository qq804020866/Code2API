package com.code2api.api;
public class Code2API12060082 {
    public static void testEmptyString() {
        char noChars[] = new char[0];
        String str = new String(noChars);
        // now str is the empty String
    }
}
