package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API10571089 {
    public static void filterEmail(String input) {
        input = input.substring(3); // filter TO:
        System.out.println(input);
        // Use DOTALL pattern  
        Pattern p = Pattern.compile("(.*?)<([^>]+)>\\s*,?",Pattern.DOTALL);

        Matcher m = p.matcher(input);

        while(m.find()) {
            // filter newline
            String name = m.group(1).replaceAll("[\\n\\r]+", ""); 
            String email = m.group(2).replaceAll("[\\n\\r]+", "");
            System.out.println(name + " -> " + email);
        }
    }
}
