package com.code2api.api;
public class Code2API12581679 {
    public static String getPartOfString(String completeWord, String delimiter) {
        String[] parts = completeWord.split(delimiter);
        return parts[1].trim();
    }
}
