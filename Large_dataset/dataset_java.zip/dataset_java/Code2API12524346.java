package com.code2api.api;
import java.util.ArrayList;

public class Code2API12524346 {
    public static void increaseArraySize(ArrayList<String> list) {
        list.add("some string");
    }
}
