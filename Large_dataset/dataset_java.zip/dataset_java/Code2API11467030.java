package com.code2api.api;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Code2API11467030 {
    public static Connection connectToOracleDB(String serverName, String portNumber, String sid, String username, String password) throws ClassNotFoundException, SQLException {
        Connection connection = null;
        try {
            // Load the JDBC driver
            String driverName = "oracle.jdbc.driver.OracleDriver";
            Class.forName(driverName);

            // Create a connection to the database
            String url = "jdbc:oracle:thin:@" + serverName + ":" + portNumber + ":" + sid;
            connection = DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException e) {
            // Could not find the database driver
            throw e;
        } catch (SQLException e) {
            // Could not connect to the database
            throw e;
        }
        return connection;
    }
}
