package com.code2api.api;
public class Code2API12122928 {
    public static void setSocksProxy(String proxyHost, int proxyPort) {
        System.getProperties().put( "proxySet", "true" );
        System.getProperties().put( "socksProxyHost", proxyHost );
        System.getProperties().put( "socksProxyPort", String.valueOf(proxyPort) );
    }
}
