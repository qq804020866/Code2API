package com.code2api.api;
import java.io.File;

public class Code2API13316725 {
    public static String getPlatformIndependentFilePath() {
        return System.getProperty("user.home");
    }
}
