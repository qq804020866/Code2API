package com.code2api.api;
public class Code2API12114597 {
    public static int calculateFactorial(int from, int n) {
        int fromNum = from;
        int toNum = n;
        int result = 1;
        int offset = 0;

        while (offset < toNum - fromNum) {
            offset++;
            result *= fromNum + offset;
        }

        return result;
    }
}
