package com.code2api.api;
public class Code2API1018367 {
    public static double roundDouble(double num) {
        return Math.floor(num * 100 + 0.5) / 100;
    }
}
