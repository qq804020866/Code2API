package com.code2api.api;
public class Code2API12803844 {
    public static void replaceSlashWithUnderscore(String file) throws IOException {
        file = file.replaceAll("/", "_");
        System.out.println(file);
    }
}
