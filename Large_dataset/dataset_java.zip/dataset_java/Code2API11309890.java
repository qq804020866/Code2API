package com.code2api.api;
import java.util.Calendar;
import java.util.Date;

public class Code2API11309890 {
    public static Calendar getCalendarFromDate(Date date) {
        Calendar aDay = Calendar.getInstance();
        aDay.setTime(date);
        return aDay;
    }
}
