package com.code2api.api;
import java.util.Calendar;

public class Code2API11785265 {
    public static int getCurrentMilliseconds() {
        return Calendar.getInstance().get(Calendar.MILLISECOND);
    }
}
