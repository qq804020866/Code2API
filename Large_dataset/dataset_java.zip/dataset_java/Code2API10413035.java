package com.code2api.api;
import java.util.ArrayList;
import java.util.List;

public class Code2API10413035 {
    public static void continueExecutionAfterException(List<String> list) {
        for(String str: list) {
            try {
                System.out.println(str);
                throw new Exception("Exception for string " + str);
            } catch(Exception ex) {
                System.out.println("Caught exception");
            }
        }
    }
}
