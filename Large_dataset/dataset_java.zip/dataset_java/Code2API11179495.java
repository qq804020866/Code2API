package com.code2api.api;
public class Code2API11179495 {
    public static String convertBinaryToString(String binary) {
        final StringBuilder b = new StringBuilder();
        for (int i = 0; i < binary.length(); i+=8) 
          b.append((char)Integer.parseInt(binary.substring(i,i+8),2));
        return b.toString();
    }
}
