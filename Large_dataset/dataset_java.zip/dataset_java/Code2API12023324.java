package com.code2api.api;
import java.awt.KeyboardFocusManager;

public class Code2API12023324 {
    public static void catchEnterAndChangeEventToTab() {
        KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
        manager.focusNextComponent();
    }
}
