package com.code2api.api;
import java.util.ArrayList;
import java.util.List;

public class Code2API11638153 {
    public static void addPos(List<Integer> list, int position, int value) {
        list.add(position, value);
    }
}
