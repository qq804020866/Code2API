package com.code2api.api;
public class Code2API13030000 {
    public static boolean isAssertionsEnabled() {
        boolean assertOn = false;
        // *assigns* true if assertions are on.
        assert assertOn = true; 
        return assertOn;
    }
}
