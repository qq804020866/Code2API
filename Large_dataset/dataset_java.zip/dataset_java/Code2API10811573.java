package com.code2api.api;
import java.util.HashMap;
import java.util.Map;

public class Code2API10811573 {
    public static Map<Object, Object> createDataCollection() {
        Map<Object, Object> map = new HashMap<Object, Object>();
        map.put("username", "test@test.com");
        map.put("city", arrayOfCity);
        return map;
    }
}
