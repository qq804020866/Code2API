package com.code2api.api;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Code2API13365583 {
    public static boolean isLowerCaseString(String inputString) {
        String regex = "[a-z]*";
        Pattern pattern1 = Pattern.compile(regex);
        Matcher matcher1 = pattern1.matcher(inputString);
        return matcher1.matches();
    }
}
