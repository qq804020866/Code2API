package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API12870383 {
    public static void printRegexGroups(String regex, String line) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(line);
        if (matcher.matches()) {
            System.out.println(matcher.group(1) + "\t" + matcher.group(2));
        }
    }
}
