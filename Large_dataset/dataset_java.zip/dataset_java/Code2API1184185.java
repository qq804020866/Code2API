package com.code2api.api;
public class Code2API1184185 {
    public static String safelyEncodeStringAsFilename(String s) {
        return s.replaceAll("\\W+", "");
    }
}
