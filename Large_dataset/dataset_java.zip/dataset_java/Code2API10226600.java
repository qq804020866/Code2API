package com.code2api.api;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Code2API10226600 {
    public static BufferedImage convert16BitTo8BitImage(BufferedImage bi) {
        BufferedImage dest = new BufferedImage(bi.getWidth(),bi.getHeight(),BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D g2 = dest.createGraphics();
        g2.drawImage(bi, 0, 0, null);
        return dest;
    }
}
