package com.code2api.api;
public class Code2API11343673 {
    public static String removeJunkFromString(String input) {
        return input.replaceFirst("(.*?)\\)\\].*?(\\(.*?\\))\\].*", "$1 $2");
    }
}
