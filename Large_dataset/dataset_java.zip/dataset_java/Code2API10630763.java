package com.code2api.api;
import javax.swing.JButton;

public class Code2API10630763 {
    public static void setStringFont(JButton button, float fontSize) {
        button.setFont(button.getFont().deriveFont(fontSize));
    }
}
