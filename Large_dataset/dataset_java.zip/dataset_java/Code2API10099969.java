package com.code2api.api;
public class Code2API10099969 {
    public static String removeUnwantedCharacters(String input) {
        return input.replaceAll("\\<.*?>","");
    }
}
