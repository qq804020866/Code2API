package com.code2api.api;
import java.util.Currency;
import java.util.Locale;

public class Code2API13321983 {
    public static Currency createCurrencyInstance(Locale locale) {
        if (locale.getCountry().equals("UK")) {
            locale = new Locale(locale.getLanguage(), "GB");
        }
        Currency cur = Currency.getInstance(locale);
        return cur;
    }
}
