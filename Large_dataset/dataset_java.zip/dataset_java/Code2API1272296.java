package com.code2api.api;
import javax.swing.Icon;
import javax.swing.UIDefaults;
import javax.swing.UIManager;

public class Code2API1272296 {
    public static Icon getFileIcon() {
        UIDefaults defaults = UIManager.getDefaults();
        return defaults.getIcon("FileView.fileIcon");
    }
}
