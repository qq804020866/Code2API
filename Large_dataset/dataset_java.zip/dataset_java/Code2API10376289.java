package com.code2api.api;
public class Code2API10376289 {
    public static int handleOverflowInHashCode(double d, int prime, int result) {
        long t = Double.doubleToLongBits(d);
        result = prime * result + (int) (t ^ (t >>> 32));
        return result;
    }
}
