package com.code2api.api;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Code2API12787924 {
    public static void extractVariablePortion(String data) {
        Pattern namePtrn = Pattern.compile("age:(\\w+)");
        Matcher nameMtchr = namePtrn.matcher(data);

        while (nameMtchr.find()) {
            String find = nameMtchr.group(1);
            System.out.println("\t" + find);
        }
    }
}
