package com.code2api.api;
import java.util.ArrayList;
import java.util.Scanner;

public class Code2API13002380 {
    public static void printArrayList() {
        int yil, bolum = 0, kalan;
        Scanner klavye = new Scanner(System.in);
        ArrayList<Integer> liste = new ArrayList<>();

        System.out.println("Yıl Girin: ");
        yil = klavye.nextInt();

        do {
            kalan = yil % 10;
            liste.add(kalan);
            bolum = yil / 10;
            yil = bolum;
        } while (bolum != 0);

        System.out.println("Sayının Basamak Sayısı: " + liste);
        klavye.close();
    }
}
