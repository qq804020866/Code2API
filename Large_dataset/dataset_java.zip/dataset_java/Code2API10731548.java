package com.code2api.api;
import java.io.PrintStream;

public class Code2API10731548 {
    public static void setTextInterfaceToGUI(PrintStream printStream) {
        System.setOut(printStream);
    }
}
