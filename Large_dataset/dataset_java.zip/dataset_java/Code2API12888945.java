package com.code2api.api;
public class Code2API12888945 {
    public static void excludeZeroInLoop(int userInputValue) {
        for(int die2 = 1; die2 <= 6 ; die2++) {
            for(int die1 = 1; die1 <= 6 ; die1++) {
                System.out.println("Die 2: " + (die2 * userInputValue) + " " + "Die 1: " + (die1 * userInputValue));
            }
        }
    }
}
