package com.code2api.api;
public class Code2API11657428 {
    public static void initializeVariablesInForStatement() {
        for (int a = 1, b = 2, c = 3 ; ; ) {
            break;
        }
    }
}
