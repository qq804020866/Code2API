package com.code2api.api;
public class Code2API12161405 {
    public static float rotateVertex(float centerX, float centerY, float point2X, float point2Y, float x) {
        float newX = centerX + (point2X-centerX)*Math.cos(x) - (point2Y-centerY)*Math.sin(x);
        float newY = centerY + (point2X-centerX)*Math.sin(x) + (point2Y-centerY)*Math.cos(x);
        return newX;
    }
}
