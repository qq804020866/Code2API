package com.code2api.api;
public class Code2API11807027 {
    public static String getBinaryStringWithAtLeast4Bits(int value) {
        return Integer.toBinaryString(value + 0b10000).substring(1);
    }
}
