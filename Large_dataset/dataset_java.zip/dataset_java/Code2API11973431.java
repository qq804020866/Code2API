package com.code2api.api;
public class Code2API11973431 {
    public static int parseNumberString(String numberString) {
        return Integer.parseInt(numberString.replaceAll(",", ""));
    }
}
