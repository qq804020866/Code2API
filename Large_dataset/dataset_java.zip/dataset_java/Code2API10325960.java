package com.code2api.api;
import java.util.Scanner;

public class Code2API10325960 {
    public static String[] getStringArray(String input) {
        return input.split(" ");
    }
}
