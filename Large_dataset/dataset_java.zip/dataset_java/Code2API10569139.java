package com.code2api.api;
import java.io.IOException;

public class Code2API10569139 {
    public static void openNotepadFile(String fileName) throws IOException {
        String[] commands = {"cmd", "/c", fileName};
        try {
            Runtime.getRuntime().exec(commands);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
