package com.code2api.api;
import java.lang.System;

public class Code2API11717770 {
    public static String splitStringWithEmptyLine(String text) {
        return System.getProperty("line.separator");
    }
}
