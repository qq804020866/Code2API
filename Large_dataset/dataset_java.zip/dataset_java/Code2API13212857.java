package com.code2api.api;
import java.io.ByteArrayInputStream;

public class Code2API13212857 {
    public static void acceptUserInput(String inputData) {
        System.setIn(new java.io.ByteArrayInputStream(inputData.getBytes()));
    }
}
