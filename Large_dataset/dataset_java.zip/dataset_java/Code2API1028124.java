package com.code2api.api;
public class Code2API1028124 {
    public static String exchangeFirstAndLastChars(String str) {
        char[] charArray = str.toCharArray();
        char temp = charArray[0];
        charArray[0] = charArray[str.length() - 1];
        charArray[str.length() - 1] = temp;
        String exchangedStr = new String(charArray);
        return exchangedStr;
    }
}
