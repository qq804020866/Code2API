package com.code2api.api;
import java.awt.*;
import javax.swing.*;

public class Code2API11623336 {
    public static void setHalfScreenPanels(JFrame myFrame, JPanel jp, JPanel jp2) {
        myFrame.setLocation(100, 100);
        myFrame.setSize(new Dimension(1024, 800));

        GridLayout layout = new GridLayout(2, 1);
        myFrame.setLayout(layout);

        jp.setBackground(new Color(0x00FF00FF));

        jp2.setBackground(new Color(0x00000000));

        myFrame.add(jp);
        myFrame.add(jp2);

        myFrame.setVisible(true);
    }
}
