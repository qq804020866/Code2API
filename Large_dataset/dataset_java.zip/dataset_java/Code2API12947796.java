package com.code2api.api;
import java.util.ArrayList;

public class Code2API12947796 {
    public static String[] getStringArray() {
        ArrayList<String> list = new ArrayList<>();

        for (int i = 0; i < 100; i++)
            list.add("stuff");

        String[] strArray = new String[list.size()];

        for (int j = 0; j < strArray.length; j++)
            strArray[j] = list.get(j).toString();

        return strArray;
    }
}
