package com.code2api.api;
public class Code2API12815148 {
    public static void printDataInNewLine(String input) {
        System.out.println(input.replace("|", "\n"));
    }
}
