package com.code2api.api;
public class Code2API12512744 {
    public static void changeString(String str) {
        str = "hello";
    }
}
