package com.code2api.api;
public class Code2API10499033 {
    public static String removeCarriageReturn(String input) {
        return input.replaceAll( "PACKAGE\\s*NFY", "PACKAGE NFY" );
    }
}
