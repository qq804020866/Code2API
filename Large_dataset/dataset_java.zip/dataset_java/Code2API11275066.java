package com.code2api.api;
import java.io.IOException;

public class Code2API11275066 {
    public static void runLinuxCommand(String command) throws IOException {
        try {
            Runtime.getRuntime().exec(command);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
