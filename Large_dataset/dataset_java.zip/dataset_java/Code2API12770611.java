package com.code2api.api;
import java.util.HashSet;
import java.util.Set;

public class Code2API12770611 {
    public static void copyNonDuplicatedValues(int[] array) {
        Set<Integer> uniqueSet = new HashSet<Integer>();
        uniqueSet.addAll(array);
        // now uniqueSet contains only unique elements from the array.
    }
}
