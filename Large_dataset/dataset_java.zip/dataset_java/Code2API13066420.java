package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API13066420 {
    public static float getFloatValueFromString(String input) {
        Pattern p = Pattern.compile("^.*\\s(\\d+\\.\\d)N.*$");
        Matcher matcher = p.matcher(input);
        if (matcher.matches()) {
            return Float.valueOf(matcher.group(1));
        }
        return 0.0f;
    }
}
