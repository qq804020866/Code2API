package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API1130022 {
    public static int getRegularExpressionMatchIndex(String inputString, String regex) throws IllegalStateException {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(inputString);
        if(matcher.matches()) {
            return matcher.start(1);
        }
        throw new IllegalStateException("No match found");
    }
}
