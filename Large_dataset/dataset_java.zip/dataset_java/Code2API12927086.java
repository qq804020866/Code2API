package com.code2api.api;
public class Code2API12927086 {
    public static char getAlphabetFromValue(int value) {
        return (char)(value+'A'-1);
    }
}
