package com.code2api.api;
public class Code2API10547433 {
    public static String removeHyphens(String fileName) {
        return fileName.replaceAll("-", "");
    }
}
