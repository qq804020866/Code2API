package com.code2api.api;
import java.lang.reflect.Array;

public class Code2API12309805 {
    public static Object createArrayInstance(Class<?> yourClass, int dimensions) {
        Object array = Array.newInstance(yourClass, dimensions);
        return array;
    }
}
