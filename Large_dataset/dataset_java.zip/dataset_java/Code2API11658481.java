package com.code2api.api;
public class Code2API11658481 {
    public static String[] convertStringToArray(String inputString) {
        return inputString.split("");
    }
}
