package com.code2api.api;
import java.awt.Component;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.swing.JOptionPane;
import javax.swing.ProgressMonitorInputStream;

public class Code2API13395076 {
    public static void copyFileWithProgressBar(Component parentComponent, File srcFolder, File destFolder) throws IOException {
        if (!srcFolder.exists()) {
            JOptionPane.showMessageDialog(null, "Directory does not exist.");
            System.exit(0);
        } else {
            try {
                copyFolder(srcFolder, destFolder);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(0);
            }
        }

        JOptionPane.showMessageDialog(null, "Back up request has been completed");
    }

    public static void copyFolder(File src, File dest) throws IOException {
        if (src.isDirectory()) {
            if (!dest.exists()) {
                dest.mkdir();
            }

            String files[] = src.list();

            for (String file : files) {
                File srcFile = new File(src, file);
                File destFile = new File(dest, file);
                copyFolder(srcFile, destFile);
            }
        } else {
            InputStream in = new BufferedInputStream(
                    new ProgressMonitorInputStream(parentComponent, "Reading " + src, new FileInputStream(src)));

            OutputStream out = new FileOutputStream(dest);

            byte[] buffer = new byte[1024];

            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }

            in.close();
            out.close();
        }
    }
}
