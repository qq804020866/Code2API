package com.code2api.api;
import java.sql.Timestamp;
import java.util.Date;

public class Code2API11377080 {
    public static Timestamp writeTimestamp() {
        return new Timestamp(new Date().getTime());
    }
}
