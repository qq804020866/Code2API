package com.code2api.api;
public class Code2API1022312 {
    public static String[] splitPolynomialTerms(String polynomial) {
        return polynomial.split("[-+]");
    }
}
