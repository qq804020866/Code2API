package com.code2api.api;
public class Code2API11673789 {
    public static int[] getViolatingValues() {
        return new int[]{Integer.MIN_VALUE, 0};
    }
}
