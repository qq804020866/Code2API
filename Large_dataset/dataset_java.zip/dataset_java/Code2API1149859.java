package com.code2api.api;
public class Code2API1149859 {
    public static String capitalizeFirstLetterOfWords(String input) {
        final StringBuilder result = new StringBuilder(input.length());
        String[] words = input.split("\\s");
        for(int i=0,l=words.length;i<l;++i) {
            if(i>0) result.append(" ");      
            result.append(Character.toUpperCase(words[i].charAt(0)))
                .append(words[i].substring(1));
        }
        return result.toString();
    }
}
