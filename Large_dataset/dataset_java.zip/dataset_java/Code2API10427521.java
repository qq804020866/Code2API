package com.code2api.api;
import java.util.ArrayList;
import java.util.List;

public class Code2API10427521 {
    public static List<Integer> copyListValues(List<Integer> listA) {
        return new ArrayList<Integer>(listA);
    }
}
