package com.code2api.api;
import java.util.concurrent.TimeUnit;

public class Code2API10224110 {
    public static String convertMillisecondsToReadableFormat(long startTime, long endTime) {
        long diff=endTime-startTime;       
        long hours=TimeUnit.MILLISECONDS.toHours(diff);
        diff=diff-(hours*60*60*1000);
        long min=TimeUnit.MILLISECONDS.toMinutes(diff);
        diff=diff-(min*60*1000);
        long seconds=TimeUnit.MILLISECONDS.toSeconds(diff);
        return hours + " hours, " + min + " mins, " + seconds + " seconds";
    }
}
