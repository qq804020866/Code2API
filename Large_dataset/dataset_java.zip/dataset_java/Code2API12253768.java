package com.code2api.api;
import java.text.DateFormatSymbols;
import java.util.Calendar;

public class Code2API12253768 {
    public static String getMonthName() {
        String[] monthNames = new DateFormatSymbols().getShortMonths();
        int month = Calendar.getInstance().get(Calendar.MONTH);
        String myMonth = monthNames[month];
        return myMonth;
    }
}
