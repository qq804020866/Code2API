package com.code2api.api;
import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Collections;

public class Code2API10596173 {
    public static Map<Integer, List<String>> iterateHashMapInReverseOrder(Map<Integer, List<String>> map) throws Exception {
        Map<Integer, List<String>> sortedMap = new TreeMap<Integer, List<String>>(Collections.reverseOrder());
        return sortedMap;
    }
}
