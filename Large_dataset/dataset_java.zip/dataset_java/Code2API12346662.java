package com.code2api.api;
import com.sun.management.OperatingSystemMXBean;
import java.lang.management.ManagementFactory;

public class Code2API12346662 {
    public static long getPhysicalMemorySize() {
        OperatingSystemMXBean os = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
        long physicalMemorySize = os.getTotalPhysicalMemorySize();
        return physicalMemorySize;
    }
}
