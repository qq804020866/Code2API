package com.code2api.api;
public class Code2API10393817 {
    public static boolean compareStringsIgnoreCase(String str1, String str2) {
        int compareValue = str1.compareToIgnoreCase(str2);
        return compareValue == 0;
    }
}
