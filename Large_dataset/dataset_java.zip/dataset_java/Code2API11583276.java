package com.code2api.api;
public class Code2API11583276 {
    public static void isStringObject(Object object) {
        if(object instanceof String){
            System.out.println("String object");
            // continue your code here
        }
        else{
             System.out.println("it is not a String");
        }
    }
}
