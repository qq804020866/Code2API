package com.code2api.api;
public class Code2API10735884 {
    public static String[] splitStringByLimit(String message, int limit) {
        String[] temp = message.split("(?<=^.{1," + limit + "}) ");
        String part1 = message.substring(0, message.length() - temp[temp.length - 1].length() - 1);
        String part2 = message.substring(message.length() - temp[temp.length - 1].length());
        return new String[]{part1, part2};
    }
}
