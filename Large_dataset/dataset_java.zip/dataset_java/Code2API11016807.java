package com.code2api.api;
public class Code2API11016807 {
    public static String[] extractStringsFromArray(String input) {
        String[] s = input.split("\\s+");
        return s;
    }
}
