package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API10446402 {
    public static String extractSubstring(String input) {
        Pattern p = Pattern.compile("\".*\"");
        Matcher m = p.matcher(input);

        if(m.find()){
            String resultString = m.group();
            return resultString;
        }
        return null;
    }
}
