package com.code2api.api;
public class Code2API12995494 {
    public static void setProxyForJVM() {
        System.getProperties().put("http.proxyHost", "someProxyURL");
        System.getProperties().put("http.proxyPort", "someProxyPort");
        System.getProperties().put("http.proxyUser", "someUserName");
        System.getProperties().put("http.proxyPassword", "somePassword");
    }
}
