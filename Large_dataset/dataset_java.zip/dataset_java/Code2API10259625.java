package com.code2api.api;
import java.util.ArrayList;

public class Code2API10259625 {
    public static String getArrayListElement(ArrayList list, int index) {
        return (String) list.get(index);
    }
}
