package com.code2api.api;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Code2API12045745 {
    public static void printUniqueTitles(String[] titles) {
        final Set<String> set = new HashSet<>(Arrays.asList(titles));
        for (final String title : set) {
            /* title is unique */
            System.out.println(title);
        }
    }
}
