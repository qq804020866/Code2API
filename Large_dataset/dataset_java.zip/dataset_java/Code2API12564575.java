package com.code2api.api;
public class Code2API12564575 {
    public static String replaceBackslash(String original) {
        return original.replaceAll("\\\\", "\\\\\\\\");
    }
}
