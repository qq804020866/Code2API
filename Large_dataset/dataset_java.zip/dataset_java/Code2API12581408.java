package com.code2api.api;
import java.lang.String;

public class Code2API12581408 {
    public static String formatString(String format, String value) {
        return String.format(format, value);
    }
}
