package com.code2api.api;
public class Code2API12333631 {
    public static boolean checkForMultiplePossibleValues(String contents) {
        return contents.equals("chicken roll") || contents.equals("toasted chicken");
    }
}
