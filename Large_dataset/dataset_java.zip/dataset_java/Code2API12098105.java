package com.code2api.api;
public class Code2API12098105 {
    public static boolean checkDivision(int i, int x) {
        return (i - x) % 16 == 0;
    }
}
