package com.code2api.api;
public class Code2API11579666 {
    public static String getSubstringUntilSecondDot(String input) {
        String[] parts = input.split("\\.", 3);
        String front = parts[0]+"."+parts[1];
        return front;
    }
}
