package com.code2api.api;
public class Code2API1130025 {
    public static int getIndexOfSubstring(String inputString, String substring) {
        return inputString.indexOf(substring);
    }
}
