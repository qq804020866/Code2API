package com.code2api.api;
public class Code2API12486066 {
    public static void refreshAdd(String wav) {
        add = wav + " " + "Grapes";
    }
}
