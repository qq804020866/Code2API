package com.code2api.api;
public class Code2API1138482 {
    public static String[] splitStringIntoChars(String input) {
        return input.split("");
    }
}
