package com.code2api.api;
public class Code2API13245693 {
    public static int countCharacterOccurrences(String input, char character) {
        return input.replaceAll("[^"+ character +"]", "").length();
    }
}
