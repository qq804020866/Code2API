package com.code2api.api;
public class Code2API13140102 {
    public static void splitStringOnConditions(String inputString) {
        String[] split = inputString.split(":::");
        String end = split[split.length - 1];

        String[] names = split[1].split("::");

        for (String name : names)
            System.out.println(name + " -- " + end);
    }
}
