package com.code2api.api;
public class Code2API1149905 {
    public static boolean likeOperator(String text, String pattern) {
        return text.startsWith(pattern.replace("%", "")) || 
               text.endsWith(pattern.replace("%", "")) || 
               text.contains(pattern.replace("%", ""));
    }
}
