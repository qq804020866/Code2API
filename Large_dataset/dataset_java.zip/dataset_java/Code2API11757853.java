package com.code2api.api;
public class Code2API11757853 {
    public static void allocateTwoDimensionalArray() {
        String[][] str = null;
        str = new String[3][3];
    }
}
