package com.code2api.api;
import java.lang.Double;

public class Code2API12557984 {
    public static int convertDoubleToInt(String doubleString) {
        return (int) Double.parseDouble(doubleString);
    }
}
