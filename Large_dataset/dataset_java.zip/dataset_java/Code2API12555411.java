package com.code2api.api;
public class Code2API12555411 {
    private static void subtractIfCharNotFound(char guessCh, String secretStr, int nTurnsLeft) {
        if(secretStr.indexOf(guessCh) < 0) nTurnsLeft--;
    }
}
