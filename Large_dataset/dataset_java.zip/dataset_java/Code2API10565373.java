package com.code2api.api;
public class Code2API10565373 {
    public static String[] getValuesAsArray(String userInput) {
        return userInput.split(",");
    }
}
