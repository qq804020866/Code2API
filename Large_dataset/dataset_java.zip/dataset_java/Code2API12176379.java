package com.code2api.api;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.BorderFactory;

public class Code2API12176379 {
    public static void addChartPanelToJPanel(JPanel parentPanel, JPanel childPanel, ChartPanel yourChartPanel) {
        JFrame frame = new JFrame();

        parentPanel.setBorder(BorderFactory.createTitledBorder("parent panel"));

        childPanel.setBorder(BorderFactory.createTitledBorder("child panel"));
        // Add a button to the child panel
        childPanel.add(new JButton("button"));
        // In the instruction below you have to create and add your ChartPanel
        childPanel.add(yourChartPanel);
        parentPanel.add(childPanel);

        frame.add(parentPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
