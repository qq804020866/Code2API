package com.code2api.api;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Code2API10732308 {
    public static Date parseDateString(String dateString) throws ParseException {
        dateString = dateString.replaceFirst("-(\\d{2})$", "-20$1");
        SimpleDateFormat fm = new SimpleDateFormat("dd-MM-yy");
        return fm.parse(dateString);
    }
}
