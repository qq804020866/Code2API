package com.code2api.api;
import java.lang.Double;

public class Code2API12557991 {
    public static int convertDoubleToInt(String doubleString) {
        double val = Double.parseDouble(doubleString);  
        int intVal = (int) Math.floor(val);   
        return intVal;
    }
}
