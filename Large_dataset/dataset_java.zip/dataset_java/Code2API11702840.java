package com.code2api.api;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Code2API11702840 {
    public static boolean performPartialMatch(String expr, String string) {
        Pattern p = Pattern.compile(expr);
        Matcher m = p.matcher(string);
        return m.find();
    }
}
