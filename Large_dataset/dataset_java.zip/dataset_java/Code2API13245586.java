package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API13245586 {
    public static int countCharacterOccurrences(String inputString, char character) throws IllegalArgumentException {
        if (inputString == null || inputString.isEmpty()) {
            throw new IllegalArgumentException("Input string cannot be null or empty");
        }
        
        Pattern pattern = Pattern.compile("([" + character + character + "])"); //case insensitive, use [g] for only lower
        Matcher matcher = pattern.matcher(inputString);
        int count = 0;
        while (matcher.find()) count++;
        return count;
    }
}
