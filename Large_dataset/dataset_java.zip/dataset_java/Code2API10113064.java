package com.code2api.api;
import javax.swing.JOptionPane;

public class Code2API10113064 {
    public static void checkSIN(String cmd, String[] p, Student[] student, FileWriter inrec) {
        if (cmd.equals("pay") && p.length == 3) { // first word is "pay";three terms (cmd, sin, $)
            System.out.println("pay");
            // Pay: decreases student payment, notifies of overpayment
            String stuSin = p[1];
            double stupay = Double.parseDouble(p[2]);
            for (int i = 0; i < student.length; i++) {
                Student x1 = student[i];
                String curSin = x1.getSin();
                if (curSin.equals(stuSin)) {
                    double curpay = x1.getBal();
                    double newBal = curpay - stupay;
                    if (stupay > curpay) {
                        JOptionPane.showMessageDialog(null, "Overpayment");
                        System.exit(0);
                    }
                    x1.setBal(newBal);
                    System.out.println(x1.getBal());

                    write(student, inrec);
                } else if (!curSin.equals(stuSin)) {
                    JOptionPane.showMessageDialog(null, "SIN not found"); // sin not found
                    System.exit(0);
                }
            }// end of for loop
        }
    }
}
