package com.code2api.api;
public class Code2API10265437 {
    public static void removeQuotationMarksFromArray(String[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].contains("\"")) {
                array[i] = array[i].replace("\"", "");
            }
        }
    }
}
