package com.code2api.api;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class Code2API10883502 {
    public static String handleRoundingErrors(String number, int precision) {
        BigDecimal bd = new BigDecimal(number).setScale(precision, RoundingMode.HALF_UP);
        return bd.toPlainString();
    }
}
