package com.code2api.api;
import java.util.HashMap;
import java.util.Map;

public class Code2API12650204 {
    public static void addToMap(ResultSet rs) {
        Map<Integer, Map<Integer, String>> map = new HashMap<Integer, Map<Integer,String>>();
    }
}
