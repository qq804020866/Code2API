package com.code2api.api;
public class Code2API10374612 {
    public static String printStringsSideBySide(String string1, String string2, String string3) {
        String output = String.format("%-25s%-25s%-25s\n", string1, string2, string3);
        return output;
    }
}
