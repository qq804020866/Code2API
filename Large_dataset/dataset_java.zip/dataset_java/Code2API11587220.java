package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API11587220 {
    public static void validateStringForAtSymbol(String userid) {
        if(userid.contains("@")){
            //Do something.
        }
    }
}
