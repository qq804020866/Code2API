package com.code2api.api;
public class Code2API12643259 {
    public static String capitalizeFirstLetterOfWords(String input) {
        StringBuilder result = new StringBuilder(input.length());
        String words[] = input.split("\\ ");
        for (int i = 0; i < words.length; i++) {
            if (i > 0) {
                result.append(" ");
            }   
            result.append(Character.toUpperCase(words[i].charAt(0))).append(words[i].substring(1));   
        }
        return result.toString();
    }
}
