package com.code2api.api;
public class Code2API10377337 {
    public static String createDirectory() {
        return System.getProperty("user.home");
    }
}
