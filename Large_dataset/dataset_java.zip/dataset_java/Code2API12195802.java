package com.code2api.api;
import java.lang.StackTraceElement;

public class Code2API12195802 {
    public static String getCallingClassName() {
        StackTraceElement[] trace = Thread.currentThread().getStackTrace();
        return trace[2].getClassName();
    }
}
