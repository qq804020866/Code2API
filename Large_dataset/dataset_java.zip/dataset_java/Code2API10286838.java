package com.code2api.api;
public class Code2API10286838 {
    public static String checkForRepeatingSequence(String str) {
        String rep = str.replaceAll(".*(.+)\\1.*","$1");
        if (rep.equals(str))
            return str + " has no repetition";
        else
            return str + " has repetition " + rep;
    }
}
