package com.code2api.api;
public class Code2API12082526 {
    public static boolean hasMultipleDots(String myString) {
        return myString.indexOf(".") != myString.lastIndexOf(".");
    }
}
