package com.code2api.api;
import java.util.Calendar;

public class Code2API11135826 {
    public static Date createSimpleDateFromYear(String year) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Integer.parseInt(year), 0, 1);          
        return calendar.getTime();
    }
}
