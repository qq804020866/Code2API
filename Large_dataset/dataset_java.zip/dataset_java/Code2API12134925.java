package com.code2api.api;
public class Code2API12134925 {
    public static int getCharPosition(String inputString, char targetChar) {
        return inputString.indexOf(targetChar);
    }
}
