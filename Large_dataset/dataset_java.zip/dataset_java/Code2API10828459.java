package com.code2api.api;
import java.util.Calendar;
import java.util.Date;

public class Code2API10828459 {
    public static Date[] getPreviousMonthDates(Date currentDate) throws Exception {
        Calendar cal = Calendar.getInstance();
        cal.setTime(currentDate);
        cal.add(Calendar.MONTH, -1);
        cal.set(Calendar.DATE, 1);
        Date firstDateOfPreviousMonth = cal.getTime();

        cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
        Date lastDateOfPreviousMonth = cal.getTime();

        return new Date[] {firstDateOfPreviousMonth, lastDateOfPreviousMonth};
    }
}
