package com.code2api.api;
public class Code2API11260677 {
    public static String replaceExceptFirst(String str) {
        String[] parts = str.split(":", 2);
        str = parts[0] + ":" + parts[1].replaceAll(":", "");
        return str;
    }
}
