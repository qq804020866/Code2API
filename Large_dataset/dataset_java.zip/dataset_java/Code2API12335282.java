package com.code2api.api;
public class Code2API12335282 {
    public static String[] splitStringByComma(String inputString) {
        return inputString.split(", ");
    }
}
