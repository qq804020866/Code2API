package com.code2api.api;
import java.io.PrintStream;

public class Code2API10759036 {
    public static void executeIfElse() {
        if (System.out.printf("%s","Hello ") == null) {
            System.out.println("Hello");
        } else {
            System.out.println("World");
        }
    }
}
