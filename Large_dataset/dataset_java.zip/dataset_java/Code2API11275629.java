package com.code2api.api;
public class Code2API11275629 {
    public static void printProgramExecutionTime() {
        long start = System.currentTimeMillis();
        // portion of code
        long stop = System.currentTimeMillis();

        System.out.println("Time: " + (stop - start) + " ms");
    }
}
