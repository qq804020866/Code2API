package com.code2api.api;
public class Code2API13280115 {
    public static int getRandomNumber() {
        return (int) Math.random()*100 % 3;
    }
}
