package com.code2api.api;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Code2API11361420 {
    public static void scheduleMethodAtSpecificTime() throws InterruptedException {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 10);
        calendar.set(Calendar.MINUTE, 30);
        calendar.set(Calendar.SECOND, 0);

        Date alarmTime = calendar.getTime();

        Timer _timer = new Timer();
        _timer.schedule(foo, alarmTime);
    }
}
