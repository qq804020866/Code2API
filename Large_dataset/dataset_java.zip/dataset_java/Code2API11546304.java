package com.code2api.api;
import java.util.Scanner;

public class Code2API11546304 {
    public static String changeLineSeparator(String input) {
        return input.replaceAll("(\\\\r)?\\\\n", System.getProperty("line.separator"));
    }
}
