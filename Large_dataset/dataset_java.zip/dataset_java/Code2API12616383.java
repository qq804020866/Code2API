package com.code2api.api;
public class Code2API12616383 {
    public static String getJdkVersion() {
        return System.getProperty("java.specification.version");
    }
}
