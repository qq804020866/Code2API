package com.code2api.api;
public class Code2API10150062 {
    public static void iterateFromArray(Object[] array, int startIndex) {
        for(int i = startIndex; i < array.length; i++) {
            // Iteration operation
        }
    }
}
