package com.code2api.api;
public class Code2API12261360 {
    public static String getShorthandResult(int a, int b) {
        String s = (a < 4) ? "a<b" : "a>=b";
        return s;
    }
}
