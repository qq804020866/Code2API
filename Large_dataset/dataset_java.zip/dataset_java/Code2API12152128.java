package com.code2api.api;
public class Code2API12152128 {
    public static void checkCommandLineArguments(String[] args) {
        if( args.length != 2 ){
            System.out.println("usage: Greetin <firstName> <lastName>");
        }
        else{
            String firstName = args[0];
            String lastName = args[1];
            System.out.println("Hello, " + firstName + " " + lastName);
            System.out.println("Congratulations on your second program!");
        }
    }
}
