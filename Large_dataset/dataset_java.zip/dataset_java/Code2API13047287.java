package com.code2api.api;
public class Code2API13047287 {
    public static void findJdkLocation() {
        try {
            Thread.sleep(60000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
