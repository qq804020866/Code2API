package com.code2api.api;
public class Code2API12595076 {
    public static String getStringBetweenCharacters(String s, char startChar, char endChar) {
        int start = 0; // '(' position in string
        int end = 0; // ')' position in string
        for(int i = 0; i < s.length(); i++) { 
            if(s.charAt(i) == startChar) // Looking for '(' position in string
               start = i;
            else if(s.charAt(i) == endChar) // Looking for ')' position in  string
               end = i;
        }
        return s.substring(start+1, end); // you take value between start and end
    }
}
