package com.code2api.api;
public class Code2API12196687 {
    public static String replaceFirstLine(String line, String yourValue) {
        return line.replaceFirst("some_property=.*$", "some_property=\"" + yourValue + "\"");
    }
}
