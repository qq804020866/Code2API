package com.code2api.api;
public class Code2API10500360 {
    public static String getFormattedSql(String columnName, String tableName) {
        return String.format("SELECT MAX(%s) FROM %s ", columnName, tableName);
    }
}
