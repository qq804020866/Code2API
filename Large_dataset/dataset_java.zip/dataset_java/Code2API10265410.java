package com.code2api.api;
public class Code2API10265410 {
    public static String removeQuotesFromString(String input) {
        return input.replace("\"", "");
    }
}
