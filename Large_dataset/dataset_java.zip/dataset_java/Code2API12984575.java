package com.code2api.api;
public class Code2API12984575 {
    public static boolean checkStringContains(String s1, String s2) {
        return s1.matches("(?i).*" + s2+ ".*");
    }
}
