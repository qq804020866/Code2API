package com.code2api.api;
import java.math.BigDecimal;

public class Code2API11095069 {
    public static void outputDoubleWith20DecimalPlaces() {
        BigDecimal test = new BigDecimal("1.000000000000000000000000000000001");
        System.out.println(test);
    }
}
