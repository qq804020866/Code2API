package com.code2api.api;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Code2API12772470 {
    public static void changeArrayListElementValue(ArrayList<Integer> list) {
        ListIterator<Integer> i = list.listIterator();
        if (i.hasNext()) {
            i.next();
            i.set(Integer.valueOf(9));
        }
        Iterator<Integer> iter = list.iterator();
        while (iter.hasNext())
            System.out.print(iter.next());
    }
}
