package com.code2api.api;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

public class Code2API12632243 {
    public static void removeDuplicates(double[] items, int numItems) {
        double[] tempa = new double[items.length];
        int counter = 0;
        for (int i = 0; i < numItems; i++) {
            for (int j = i + 1; j < numItems; j++) {
                if (items[i] == items[j]) {
                    tempa[counter] = j;
                    counter++;
                }
            }
        }

        double[] tempb = new double[items.length];
        int counter2 = 0;
        int j = 0;
        for (int i = 0; i < numItems; i++) {
            if (i != tempa[j]) {
                tempb[counter2] = items[i];
                counter2++;
            } else {
                j++;
            }
        }

        items = tempb;
        numItems = counter2;
    }
}
