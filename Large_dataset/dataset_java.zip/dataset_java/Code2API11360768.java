package com.code2api.api;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Locale;

public class Code2API11360768 {
    public static void readDictionaryFile(String filePath) {
        try {
            FileInputStream fstream1 = new FileInputStream(filePath);
            DataInputStream in = new DataInputStream(fstream1);
            BufferedReader br = new BufferedReader(new InputStreamReader(in,"UTF-8"));

            String str;
            while ((str = br.readLine()) != null) {
                String str_uc = str.trim().toUpperCase(Locale.GERMAN);
                if (hasApostrophe(str_uc)) {
                    allletters.add(str_uc);
                    if (str.length() == 3)
                        threeletter.add(str_uc);
                    else if (str.length() == 4)
                        fourletter.add(str_uc);
                    else if (str.length() == 5)
                        fiveletter.add(str_uc);
                    else if (str.length() == 6)
                        sixletter.add(str_uc);
                    else if (str.length() == 7)
                        sevenletter.add(str_uc);
                }
            }
            in.close();
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}
