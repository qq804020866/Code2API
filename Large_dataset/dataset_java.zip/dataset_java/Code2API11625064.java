package com.code2api.api;
import java.math.BigDecimal;

public class Code2API11625064 {
    public static String checkForNegativeValue(String text) {
        BigDecimal number = new BigDecimal(text);
        if (number.compareTo(BigDecimal.ZERO) <= 0) {
            text = "--";
        }
        return text;
    }
}
