package com.code2api.api;
public class Code2API10142140 {
    public static void shiftCasesToAnotherFile(Enum result) {
        switch(result) {
            case 1:
            case 3:
            case 5:
                System.out.println("Odd");
                break;
            case 2:
            case 4:
            case 6:
                System.out.println("Even");
                break;
        }
    }
}
