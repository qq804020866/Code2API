package com.code2api.api;
public class Code2API13007007 {
    public static String getJmxPortDetails() {
        String jmx1 = System.getProperty("com.sun.management.jmxremote");
        String jmx2 = System.getProperty("com.sun.management.jmxremote.port");
        String jmx3 = System.getProperty("com.sun.management.jmxremote.authenticate");
        String jmx4 = System.getProperty("com.sun.management.jmxremote.ssl");
        String jmx5 = System.getProperty("java.rmi.server.hostname");
        return jmx1 + "\n" + jmx2 + "\n" + jmx3 + "\n" + jmx4 + "\n" + jmx5;
    }
}
