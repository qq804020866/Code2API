package com.code2api.api;
public class Code2API12833075 {
    public static String replaceLastChar(String input, char replacement) {
        String updatedString = input.substring(0, input.length()-1) + replacement;
        return updatedString;
    }
}
