package com.code2api.api;
public class Code2API13258845 {
    public static void displayImageFolderLocation() {
        System.out.println(System.getProperty("user.dir"));
    }
}
