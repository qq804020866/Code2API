package com.code2api.api;
public class Code2API13268944 {
    public static int concatenateIntValues(int a, int b, int c, int d, int e) {
        return Integer.valueOf(String.valueOf(a) + String.valueOf(b) + String.valueOf(c) + String.valueOf(d) + String.valueOf(e));
    }
}
