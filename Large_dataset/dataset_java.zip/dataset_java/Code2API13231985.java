package com.code2api.api;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Code2API13231985 {
    public static ArrayList<String[][]> getFiledArrayList() throws SQLException {
        ArrayList<String[][]> fieldsList = new ArrayList<>();
        ResultSet result;

        String sql = "select id, name_of from field";
        result = database.exeQueryStatement(sql);
        try {
            while(result.next()) {
                String[][] tempRow = new String[1][2];
                tempRow[0][0] = result.getString("id");
                tempRow[0][1] = result.getString("name_of");
                fieldsList.add(tempRow);
                System.out.println(fieldsList.get(0)[0][1]);
            }
        } catch (SQLException ex) {
            Logger.getLogger(FieldManage.class.getName()).log(Level.SEVERE, null, ex);
        }

        return fieldsList;
    }
}
