package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API13153595 {
    public static String getFloatValueFromString(String inputString) {
        Pattern p = Pattern.compile("([-+]?[0-9]*\\.?[0-9]+)");
        Matcher m = p.matcher(inputString);

        if (m.find()) {
            return m.group(1);
        }

        return null;
    }
}
