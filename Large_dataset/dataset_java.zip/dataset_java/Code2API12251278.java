package com.code2api.api;
public class Code2API12251278 {
    public static String replaceLogicalOperators(String expression) {
        return expression.replace("||", " OR ");
    }
}
