package com.code2api.api;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Code2API12908482 {
    public static void addPanelToFrame(JFrame frame, JPanel panel) {
        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }
}
