package com.code2api.api;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API10333001 {
    public static String replaceSubstrings(String input, Map<String, String> replacements) {
        final Pattern pattern = Pattern.compile("%.*?%");
        final Matcher matcher = pattern.matcher(input);
        final StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            final String found = matcher.group();
            final String withoutPercents = found.substring(1, found.length() - 1);
            matcher.appendReplacement(sb, replacements.get(withoutPercents));
            // instead of map.get(), there could be session.getAttribute(withoutPercents)
        }
        matcher.appendTail(sb);
        return sb.toString();
    }
}
