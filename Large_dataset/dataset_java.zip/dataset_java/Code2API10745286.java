package com.code2api.api;
import java.awt.FileDialog;

public class Code2API10745286 {
    public static void useDefaultFileChooser() {
        new FileDialog((java.awt.Frame) null).setVisible(true);
    }
}
