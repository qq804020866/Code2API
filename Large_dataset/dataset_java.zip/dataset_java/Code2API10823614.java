package com.code2api.api;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Code2API10823614 {
    public static void showCard(JPanel cardPanel, String cardName) {
        CardLayout cardLayout = (CardLayout)(cardPanel.getLayout());
        cardLayout.show(cardPanel, cardName);
    }
    
    public static void main(String[] args) {
        CardLayoutTest frame = new CardLayoutTest();

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    } 
}
