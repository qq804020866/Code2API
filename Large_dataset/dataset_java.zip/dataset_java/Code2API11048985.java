package com.code2api.api;
import java.util.Calendar;

public class Code2API11048985 {
    public static void getWorkingDaysBetweenDates(Date startDate, int noOfDaysBetween) {
        Calendar cal  = Calendar.getInstance();
        cal.setTime(startDate);

        for(int index = 0 ; index < noOfDaysBetween; index++){
            int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
            if( dayOfWeek!=Calendar.SUNDAY && dayOfWeek!=Calendar.SATURDAY) {
                System.out.println(cal.getTime());
            }
            cal.add(Calendar.DATE, 1);
        }
    }
}
