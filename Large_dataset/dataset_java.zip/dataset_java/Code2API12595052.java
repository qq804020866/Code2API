package com.code2api.api;
public class Code2API12595052 {
    public static String getStringBetweenCharacters(String input, char startChar, char endChar) {
        String s = input.substring(input.indexOf(startChar) + 1);
        s = s.substring(0, s.indexOf(endChar));
        return s;
    }
}
