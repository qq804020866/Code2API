package com.code2api.api;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Code2API10261501 {
    public static void makeImageSelection(JButton buttonSelection, JLabel playerA, JLabel playerB) {
        if (playerA == null) {
            playerA = buttonSelection;
        } else {
            playerB = buttonSelection;
        }
    }
}
