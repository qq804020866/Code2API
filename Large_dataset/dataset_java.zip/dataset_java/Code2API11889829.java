package com.code2api.api;
import java.io.InputStream;

public class Code2API11889829 {
    public static InputStream readResourceFile() {
        return ClassLoader.getSystemResourceAsStream("res.txt");
    }
}
