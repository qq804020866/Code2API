package com.code2api.api;
public class Code2API13276633 {
    public static void replaceWithN(int n) {
        System.out.printf("%" + n + "s","Hello");
    }
}
