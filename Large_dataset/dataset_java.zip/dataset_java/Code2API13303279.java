package com.code2api.api;
import java.util.HashMap;
import java.util.Map;

public class Code2API13303279 {
    public static String convertMapValuesToString(Map<String, String> map) {
        return map.get("email");
    }
}
