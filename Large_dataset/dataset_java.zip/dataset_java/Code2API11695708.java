package com.code2api.api;
public class Code2API11695708 {
    public static void printWithBrokenPipeException() {
        while(!System.out.checkError()) {
            System.out.println("hi");
        }
    }
}
