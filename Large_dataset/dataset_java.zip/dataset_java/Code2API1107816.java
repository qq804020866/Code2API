package com.code2api.api;
public class Code2API1107816 {
    public static boolean checkStringStartsWithNumber(String s) {
        return Character.isDigit(s.charAt(0));
    }
}
