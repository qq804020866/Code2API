package com.code2api.api;
public class Code2API10908917 {
    public static String[] splitStringWithDelimiters(String input, String delimiter) {
        return input.split(delimiter, -1);
    }
}
