package com.code2api.api;
public class Code2API12216305 {
    public static String extractNumericValues(String inputString) {
        String str_rep1=" abc d ";
        String str_rep2="pqr ";
        String result1=inputString.replaceAll("", str_rep1);
        String result2=inputString.replaceAll(",",str_rep2);
        return result2;
    }
}
