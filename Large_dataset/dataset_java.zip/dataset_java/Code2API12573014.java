package com.code2api.api;
import java.util.Date;

public class Code2API12573014 {
    public static int compareTime(Date date1, Date date2) {
        return date1.compareTo(date2);
    }
}
