package com.code2api.api;
public class Code2API1269597 {
    public static void printHexadecimalNumbers(int x) {
        for (int i = 1; i <= x; i++) {
            System.out.printf("%02x\n", i);
        }
    }
}
