package com.code2api.api;
public class Code2API10922519 {
    public static int[] initializeIntArrayInSwitch(int something) {
        int[] array;
        switch (something) {
            case 0: array = new int[] {1, 2, 3}; break;
            default: array = new int[] {3, 2, 1};
        }
        return array;
    }
}
