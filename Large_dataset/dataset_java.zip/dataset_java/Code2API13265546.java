package com.code2api.api;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.BorderLayout;

public class Code2API13265546 {
    public static void increasePanelWidth() {
        JTextField studIdText = new JTextField(20);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints r1 = new GridBagConstraints();

        r1.fill = GridBagConstraints.HORIZONTAL;
        r1.weightx = 0.0;
        r1.gridx = 0;
        r1.gridy = 0;
        panel.add(studId,r1);

        r1.weightx = 0.5;
        r1.gridx = 1;
        r1.gridwidth = GridBagConstraints.REMAINDER; 
        panel.add(studIdText,r1);
    }
}
