package com.code2api.api;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Code2API11367413 {
    public static BufferedImage scaleBufferedImage(BufferedImage image, int newWidth, int newHeight) {
        BufferedImage resizedImage = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB); 
        Graphics2D g = resizedImage.createGraphics();
        g.drawImage(image, 0, 0, newWidth, newHeight, null);
        g.dispose();
        return resizedImage;
    }
}
