package com.code2api.api;
import javax.swing.UIManager;

public class Code2API10745344 {
    public static void useDefaultFileChooser() throws Exception {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }catch(Exception ex) {
            ex.printStackTrace();
        }
    }
}
