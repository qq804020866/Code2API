package com.code2api.api;
import java.util.Arrays;
import java.util.List;

public class Code2API10231009 {
    public static List<String> convertStringArrayToList(String[] array) {
        return Arrays.asList(array);
    }
}
