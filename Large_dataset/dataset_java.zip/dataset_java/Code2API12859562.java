package com.code2api.api;
public class Code2API12859562 {
    public static long getDifferenceAsLong(int intValue1, int intValue2) {
        return (long) intValue2 - intValue1;
    }
}
