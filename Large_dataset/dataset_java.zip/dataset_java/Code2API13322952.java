package com.code2api.api;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Code2API13322952 {
    public static Date convertTimestampToSqlDate(Timestamp timestamp) {
        java.util.Date today = new java.util.Date();
        long t = timestamp.getTime();
        java.sql.Date dt = new java.sql.Date(t);
        return dt;
    }
}
