package com.code2api.api;
public class Code2API11579663 {
    public static String getSubstringUntilSecondDot(String input) {
        int dot1 = input.indexOf(".");
        int dot2 = input.indexOf(".", dot1 + 1);
        String substr = input.substring(0, dot2);
        return substr;
    }
}
