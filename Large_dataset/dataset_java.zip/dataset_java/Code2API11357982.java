package com.code2api.api;
public class Code2API11357982 {
    public static String removeTrailingCharacters(String input) {
        return input.replaceAll("([^A-Za-z0-9 ])", "");
    }
}
