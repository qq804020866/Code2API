package com.code2api.api;
import javax.swing.filechooser.FileSystemView;
import javax.swing.Icon;

public class Code2API1272227 {
    public static Icon getFileIcon(File file) {
        FileSystemView view = FileSystemView.getFileSystemView();    
        return view.getSystemIcon(file);    
    }
}
