package com.code2api.api;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class Code2API13315784 {
    public static int convertUTCToLocalTime(long utcTime) {
        Calendar c = new GregorianCalendar(TimeZone.getTimeZone("EST"));
        c.setTimeInMillis(utcTime);
        return c.get(Calendar.HOUR_OF_DAY);
    }
}
