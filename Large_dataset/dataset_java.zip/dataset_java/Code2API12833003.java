package com.code2api.api;
public class Code2API12833003 {
    public static void replaceLastChar(String input, String replacement) {
        String replaceEnd = input.replaceAll(".$", replacement);
        System.out.println(replaceEnd);
    }
}
