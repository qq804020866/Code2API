package com.code2api.api;
import java.util.Calendar;
import java.util.TimeZone;

public class Code2API10636276 {
    public static Date getCurrentDateTimeInUTC() {
        return Calendar.getInstance(TimeZone.getTimeZone("UTC")).getTime();
    }
}
