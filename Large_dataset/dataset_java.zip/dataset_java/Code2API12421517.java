package com.code2api.api;
public class Code2API12421517 {
    public static String formatNumber(int number) {
        return String.format("%02d", number);
    }
}
