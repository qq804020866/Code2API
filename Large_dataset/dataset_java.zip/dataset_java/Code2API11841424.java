package com.code2api.api;
public class Code2API11841424 {
    public static String makeLineBreaks() {
        return System.getProperty("line.separator");
    }
}
