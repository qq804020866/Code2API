package com.code2api.api;
public class Code2API11341375 {
    public static String removeControlChars(String value) {
        return value.replaceAll("\\p{Cntrl}", "");
    }
}
