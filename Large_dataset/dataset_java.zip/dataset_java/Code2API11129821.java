package com.code2api.api;
import java.lang.Math;

public class Code2API11129821 {
    public static double roundToDecimalPlaces(double data, int decimalPlaces) {
        double roundBase = Math.pow(10, decimalPlaces);
        data = (double)(Math.round(data * roundBase)) / roundBase;
        return data;
    }
}
