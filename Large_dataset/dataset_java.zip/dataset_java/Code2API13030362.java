package com.code2api.api;
public class Code2API13030362 {
    public static boolean isAssertionsEnabled() {
        boolean assertsEnabled = false;
        assert assertsEnabled = true; // Intentional side-effect!!!
        return assertsEnabled;
    }
}
