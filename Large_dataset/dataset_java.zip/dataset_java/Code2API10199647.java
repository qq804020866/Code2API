package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API10199647 {
    public static void excludeLeadingSingleQuote(String[] lines) {
        String regex = "^[^']*\\.Transaction\\s*=\\s*GlobalCommArea";
        Pattern p = Pattern.compile(regex);

        for (int i = 0; i <= lines.length; i++) {
            Matcher m = p.matcher(lines[i]);

            if (m.find()) {
                System.out.print("Yes\t");
            } else {
                System.out.print("No\t");
            }

            System.out.println(lines[i]);
        }
    }
}
