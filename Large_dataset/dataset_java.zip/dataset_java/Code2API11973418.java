package com.code2api.api;
public class Code2API11973418 {
    public static String parseNumberString(String numberString) {
        return numberString.replaceAll(",", "");
    }
}
