package com.code2api.api;
import java.nio.file.FileSystems;
import java.nio.file.PathMatcher;

public class Code2API13185555 {
    public static boolean validatePathName(String glob, String filename) {
        PathMatcher matcher = FileSystems.getDefault().getPathMatcher(glob);
        return matcher.matches(filename);
    }
}
