package com.code2api.api;
public class Code2API12671500 {
    public static String replaceSpaceWithURLEncoding(String url) {
        url = url.replaceAll(" ", "%20");
        return url;
    }
}
