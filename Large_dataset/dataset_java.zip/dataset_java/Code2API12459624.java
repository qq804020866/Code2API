package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API12459624 {
    public static void extractSubstring(String inputStr, String patternStr) {
        Pattern pattern = Pattern.compile(patternStr);
        Matcher matcher = pattern.matcher(inputStr);
        boolean matchFound = matcher.find();

        if (matchFound) {
            for (int i=0; i<=matcher.groupCount(); i++) {
                String groupStr = matcher.group(i);
                System.out.println(groupStr);
            }
        }
    }
}
