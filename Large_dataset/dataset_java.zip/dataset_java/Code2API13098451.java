package com.code2api.api;
public class Code2API13098451 {
    public static int generateRandomIntInRange(int x, int y) {
        int i = (int) (Math.random() * (y - x));
        return x + (i % (y - x));
    }
}
