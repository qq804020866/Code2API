package com.code2api.api;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;

public class Code2API13350733 {
    public static void readWriteUTF8File(String inputFile, String outputFile) throws IOException {
        try {
            Reader reader = new InputStreamReader(new FileInputStream(inputFile), "UTF-8");
            BufferedReader fin = new BufferedReader(reader);
            Writer writer = new OutputStreamWriter(new FileOutputStream(outputFile), "UTF-8");
            BufferedWriter fout = new BufferedWriter(writer);
            String s;
            while ((s = fin.readLine()) != null) {
                fout.write(s);
                fout.newLine();
            }
            fin.close();
            fout.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
