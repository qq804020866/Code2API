package com.code2api.api;
import java.lang.Integer;

public class Code2API10179008 {
    public static int convertBinaryToInt(String binary) {
        return Integer.parseInt(binary, 2);
    }
}
