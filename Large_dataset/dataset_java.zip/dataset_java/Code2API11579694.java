package com.code2api.api;
import java.util.Arrays;

public class Code2API11579694 {
    public static String getSubstringUntilSecondDot(String yourDotString) {
        String[] yourArray = yourDotString.split("\\.");
        String firstTwoSubstrings = yourArray[0] + "." + yourArray[1];
        return firstTwoSubstrings;
    }
}
