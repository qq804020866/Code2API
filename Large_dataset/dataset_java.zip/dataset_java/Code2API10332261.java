package com.code2api.api;
import java.util.Map;

public class Code2API10332261 {
    public static String replaceSubstrings(String input, Map<String, String> replacements) {
        String formatted = input;
        for (Map.Entry<String, String> entry : replacements.entrySet()) {
            String key = "%" + entry.getKey() + "%";
            String value = entry.getValue();
            formatted = formatted.replace(key, value);
        }
        return formatted;
    }
}
