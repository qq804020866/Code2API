package com.code2api.api;
public class Code2API12711682 {
    public static String extractSecondsFromTimeString(String time) {
        return time.substring(time.lastIndexOf("m") + 1, time.lastIndexOf("s"));
    }
}
