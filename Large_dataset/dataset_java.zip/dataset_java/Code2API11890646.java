package com.code2api.api;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Code2API11890646 {
    public static String replaceDoubleQuotes(String input) {
        return input.replace("\"\"", "\"");
    }
}
