package com.code2api.api;
public class Code2API11221554 {
    public static String convertToSingleLine(String input) {
        return input.replaceAll("[\r\n]+", " ");
    }
}
