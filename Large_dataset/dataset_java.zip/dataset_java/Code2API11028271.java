package com.code2api.api;
public class Code2API11028271 {
    public static String tokenizeString(String myString) {
        return myString.replaceAll("(?i)(anchor)(text)", "$1 $2");
    }
}
