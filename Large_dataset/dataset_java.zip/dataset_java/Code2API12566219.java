package com.code2api.api;
public class Code2API12566219 {
    public static void callMethodsInLoop(Object obj, int N) {
        for (int i=0;i<N;i++) {
            try {
                obj.getClass().getMethod("method"+i).invoke(obj);
            } catch (Exception e) {
                // give up
                break;
            }
        }
    }
}
