package com.code2api.api;
public class Code2API10774432 {
    public static void setJnaLibraryPath(String libraryPath) {
        System.getProperties().setProperty("jna.library.path", libraryPath);
    }
}
