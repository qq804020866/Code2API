package com.code2api.api;
public class Code2API12049651 {
    public static String convertLongToTime(long timeInSeconds) {
        int h = timeInSeconds / 3600;
        int m = (timeInSeconds / 60) % 60;
        int s = (timeInSeconds % 60);

        String time = String.format("%02d:%02d:%02d", h, m, s);
        return time;
    }
}
