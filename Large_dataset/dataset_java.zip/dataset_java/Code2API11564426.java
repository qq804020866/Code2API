package com.code2api.api;
import java.util.Calendar;
import java.util.Date;

public class Code2API11564426 {
    public static void manipulateYear(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int year = cal.get(Calendar.YEAR);
        if(year < 2000)
            cal.add(Calendar.YEAR, 2000); // add two thousand years
    }
}
