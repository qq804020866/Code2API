package com.code2api.api;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Code2API10307791 {
    public static void openNewWindow(JFrame frame) {
        JOptionPane.showMessageDialog(frame, "Breakout! v1.0");
    }
}
