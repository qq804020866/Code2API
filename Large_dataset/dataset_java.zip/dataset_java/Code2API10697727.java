package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API10697727 {
    public static String getExecutionStatusValue(String input) {
        String pattern = "[0-9]+";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(input);
        if (m.find()) {
            return m.group(0);
        } else {
            return null;
        }
    }
}
