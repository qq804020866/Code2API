package com.code2api.api;
import java.util.LinkedList;
import java.util.List;
import java.util.Arrays;

public class Code2API10344043 {
    public static List<Double> initializeLinkedList(List<Double> values) {
        return new LinkedList<Double>(values);
    }
}
