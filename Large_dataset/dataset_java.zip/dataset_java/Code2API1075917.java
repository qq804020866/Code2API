package com.code2api.api;
public class Code2API1075917 {
    public static void catchAllExceptions() {
        try {
            //Read/write file
        } catch (Exception ex) {
            //catches all exceptions extended from Exception (which is everything)
        }
    }
}
