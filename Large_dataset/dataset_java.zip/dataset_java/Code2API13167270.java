package com.code2api.api;
import java.util.Scanner;

public class Code2API13167270 {
    public static void validateUserInput(Scanner input, GraphicsScreen graphics) {
        String next;
        String[] one;

        do {
            System.out.print("Enter a command (\"stop\") to finish : ");
            System.out.print("Type 'help' for a list of commands ");
            next = input.nextLine();
            one = next.split(" ");

            String command = one[0];

            if(next.contains("help")) {
                System.out.println("Type 'move' followed by an X and Y co-ordinate to move the graphical pointer.");
                System.out.println("Type 'circle' followed by a radius value to output a circle.");
                System.out.println("Type 'line' followed by an X and Y co-ordinate to draw a line.");
                System.out.println("Type 'clear' to reset the graphical canvas.");
            }

            if(next.contains("move")) {
                int x = 0;
                int y = 0;
                x = Integer.parseInt(one[1]);
                y= Integer.parseInt(one[2]);
                graphics.moveTo(x, y);
            } 

            if( command.equalsIgnoreCase("circle")) {
                int radius = 0;
                radius = Integer.parseInt(one[1]);
                graphics.circle(radius);
            } 

            if(command.equalsIgnoreCase("line")) {
                int x = 0;
                int y = 0;
                x = Integer.parseInt(one[1]);
                y= Integer.parseInt(one[2]);
                graphics.lineTo(x,y);
            }

            if(next.contains("clear")) {
                graphics.clear();
            }

        } while ( next.equalsIgnoreCase("stop") == false );

        System.out.println("You have decided to stop entering commands. Program terminated!");

        graphics.close();
    }
}
