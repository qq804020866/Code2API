package com.code2api.api;
import java.lang.Character;

public class Code2API1107803 {
    public static boolean checkStringStartsWithNumber(String myString) {
        return Character.isDigit(myString.charAt(0));
    }
}
