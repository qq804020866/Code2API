package com.code2api.api;
public class Code2API11927697 {
    public static void printArrayReferences(String[][] array1, String[][] array2) {
        array1[0][0] = "some string";
        array2 = array1;
        array1[0][0] = "another string";
        System.out.println("array2: " + array2[0][0]);
        array2[0][0] = "a third string";
        System.out.println("array1: " + array1[0][0]);
    }
}
