package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API13365579 {
    public static boolean isLowerCaseString(String inputString) {
        String regex = "[a-z]+";
        Pattern pattern1 = Pattern.compile(regex);
        Matcher matcher1 = pattern1.matcher(inputString);
        return matcher1.matches();
    }
}
