package com.code2api.api;
import javax.swing.JLabel;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.geom.Rectangle2D;

public class Code2API1171842 {
    public static int getMinimumSizeWithoutEllipsis(JLabel label) {
        FontMetrics fontMetrics = label.getFontMetrics(label.getFont());
        Rectangle2D stringBounds = fontMetrics.getStringBounds(label.getText(), label.getGraphics());
        int minWidth = (int) (stringBounds.getWidth() + label.getInsets().left + label.getInsets().right);
        int minHeight = (int) (stringBounds.getHeight() + label.getInsets().top + label.getInsets().bottom);
        return minWidth;
    }
}
