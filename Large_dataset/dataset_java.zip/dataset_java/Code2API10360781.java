package com.code2api.api;
import javax.swing.UIManager;

public class Code2API10360781 {
    public static void changeLookAndFeel() throws Exception {
        try { 
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel"); 
        } catch (Exception ex) { 
            ex.printStackTrace(); 
        }
    }
}
