package com.code2api.api;
import java.awt.Font;
import javax.swing.JButton;

public class Code2API10630798 {
    public static void setStringFont(JButton button, String text, String fontName, int fontStyle, int fontSize) {
        button.setText(text);
        button.setFont(new Font(fontName, fontStyle, fontSize));
    }
}
