package com.code2api.api;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class Code2API1305384 {
    public static Date getCurrentDateTime() {
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("Europe/Madrid"));
        return calendar.getTime();
    }
}
