package com.code2api.api;
public class Code2API11672177 {
    public static String extractString(String input, String start, String end) {
        return input.substring(input.lastIndexOf(start) + start.length(), input.lastIndexOf(end));
    }
}
