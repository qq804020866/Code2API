package com.code2api.api;
import java.util.ArrayList;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Code2API10556570 {
    public static ArrayList<DocumentModel> setColumnNameForColumnN(String code, String date, String dateFinal) throws GeneralException{
        ArrayList<DocumentModel> docs = new ArrayList<DocumentModel>();
        String d1 = date;
        String delimiter = "-";
        String[]temp = d1.split(delimiter);
        String[]temp2 = dateFinal.split("-");
        String num="";
        String alfa="";
        if (code.compareTo("")!=0){
            String[] c1 = code.split(",");
            num = c1[0];
            alfa = c1[1];
        }

        try{
            String sql = "SELECT max(issuedate) as MaxIssueDate, airlineOid as airlineNumericCode FROM Document  WHERE ";

            if (alfa.compareTo("")!=0) sql+=" airlineOid='"+alfa+"' and ";

            sql+=" convert(varchar,issueDate,112) >= '" + temp[0]+ temp[1] +"00'  AND convert(varchar,issueDate,112) < '"+ temp2[0]+ temp2[1] +"32' group by airlineOid";

            String sql2="select d.*,'"+num+"' as airlineNumericCode from document d,("+sql+") as t where t.airlineOid=d.airlineOid and t.issueDate=d.issueDate ORDER BY issueDate DESC ";

            ResultSet rs = this.executeQuery(sql2);
            while(rs.next()){
                docs.add((DocumentModel)this.build(rs));
            }
            if(docs != null){
                return docs;
            } else {
                return docs = null;
            }
        } catch (SQLException ex){
            throw new GeneralException(ex);
        }
    }
}
