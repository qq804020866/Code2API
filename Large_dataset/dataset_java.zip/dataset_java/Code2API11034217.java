package com.code2api.api;
public class Code2API11034217 {
    public static void checkEndOfString(String myString) {
        for (char c : myString.toCharArray()) {
            System.out.println("Character is " + c);
        }

        for (int i = 0; i < myString.length(); i++) {
            System.out.println("Character is " + myString.charAt(i));
        }
    }
}
