package com.code2api.api;
import java.util.ArrayList;
import java.util.List;

public class Code2API1073933 {
    public static List<Integer> convertIntArrayToList(int[] array) {
        List<Integer> intList = new ArrayList<Integer>(array.length);
        for (int i : array)
        {
            intList.add(i);
        }
        return intList;
    }
}
