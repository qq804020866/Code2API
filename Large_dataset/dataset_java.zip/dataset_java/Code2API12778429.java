package com.code2api.api;
import java.io.IOException;

public class Code2API12778429 {
    public static void setFolderPermission(String folderPath) throws IOException {
        Runtime rt = Runtime.getRuntime();
        Process proc;
        int exitVal = -1;
        try {
            proc =  rt.exec("chmod 777 " + folderPath);
            exitVal = proc.waitFor();
        } catch (Exception e) {}
    }
}
