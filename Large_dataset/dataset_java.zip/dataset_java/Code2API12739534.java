package com.code2api.api;
public class Code2API12739534 {
    public static void sortArrayByNearestValue(int[] array) {
        for(int i = 0; i < array.length; i++) {
            int currentValue = array[i];
            int distance = Integer.MAX_VALUE;
            for(int j = i+1; j < array.length ; j++) {
                if(Math.abs(array[j] - currentValue) < distance ) {
                    distance = Math.abs(array[j] - currentValue);
                    int temp = array[i+1];
                    array[i+1] = array[j];
                    array[j] = temp;
                }
            }
        }
    }
}
