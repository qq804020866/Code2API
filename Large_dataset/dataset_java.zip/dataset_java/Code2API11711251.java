package com.code2api.api;
public class Code2API11711251 {
    public static char[] initCharArray(String str) {
        return str.toCharArray();
    }
}
