package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API10731421 {
    public static int getIdParameter(String url) {
        Pattern pattern = Pattern.compile("id=([^&]*?)$|id=([^&]*?)&");
        Matcher matcher = pattern.matcher(url);
        if (matcher.matches()) {
            int idg1 = Integer.parseInt(matcher.group(1));
            int idg2 = Integer.parseInt(matcher.group(2));
            if (idg1 != 0) {
                return idg1;
            } else {
                return idg2;
            }
        }
        return 0;
    }
}
