package com.code2api.api;
import acm.program.*;

public class Code2API11813453 {
    public static int calculateSumOfOddIntegers(int n) {
        int b = 0;
        for (int i = 0; i < n; i++) {
            b += (2*i + 1);
        }
        return b;
    }
}
