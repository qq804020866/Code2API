package com.code2api.api;
import java.text.NumberFormat;
import java.text.ParseException;

public class Code2API1102905 {
    public static boolean isNumeric(String value) throws ParseException {
        try {
            NumberFormat.getInstance().parse(value);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
}
