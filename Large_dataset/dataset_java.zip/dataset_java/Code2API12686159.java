package com.code2api.api;
import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;
import java.io.IOException;

public class Code2API12686159 {
    public static void compileJavaProgram(String filePath) throws IOException {
        JavaCompiler javac = ToolProvider.getSystemJavaCompiler();
        String[] arguments = {filePath};
        javac.run(null, null, null, arguments);
    }
}
