package com.code2api.api;
import java.io.FilePermission;
import java.security.AccessController;
import java.security.AccessControlException;

public class Code2API11902036 {
    public static boolean isFileReadable(String filePath) {
        try {
            FilePermission fp = new FilePermission(filePath, "read");
            AccessController.checkPermission(fp);
            return true;
        } catch (AccessControlException e) {
            return false;
        }
    }
}
