package com.code2api.api;
public class Code2API11555623 {
    public static char[] convertCsvToByteArray(String csv) {
        String[] numbers = csv.split(", ");
        char[] chars = new char[numbers.length];
        for (int i = 0; i < numbers.length; i++)
            chars[i] = (char)Integer.parseInt(numbers[i]);
        return chars;
    }
}
