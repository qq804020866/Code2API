package com.code2api.api;
public class Code2API12682507 {
    public static String formatWithThousandsSeparator(String number) {
        return String.format("%,d", Integer.parseInt(number));
    }
}
