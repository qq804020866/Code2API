package com.code2api.api;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.JTextPane;
import javax.swing.text.DefaultStyledDocument;
import java.awt.Font;

public class Code2API12145335 {
    public static void changeTextPaneFontAndAlignment(JTextPane textPane, Font font) {
        StyleContext context = new StyleContext();
        StyledDocument document = new DefaultStyledDocument(context);
        Style style = context.getStyle(StyleContext.DEFAULT_STYLE);
        StyleConstants.setAlignment(style, StyleConstants.ALIGN_CENTER);
        textPane.setStyledDocument(document);
        textPane.setFont(font);
    }
}
