package com.code2api.api;
public class Code2API10368488 {
    public static void checkForCarry(short s1, short s2) {
        int i = s1 + s2;
        short s = (short)i;
        if (i != s) { /* overflow */ }
    }
}
