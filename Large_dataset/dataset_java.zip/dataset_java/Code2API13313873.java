package com.code2api.api;
import java.util.StringTokenizer;

public class Code2API13313873 {
    public static int getWordCount(String myString) {
        return new StringTokenizer(myString," ").countTokens();
    }
}
