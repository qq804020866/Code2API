package com.code2api.api;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Code2API12443366 {
    public static void checkForTabCharacter(String filePath) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line = br.readLine();
        while (line != null) {
            for (char ch : line.toCharArray()) {
                if (ch == '\t') {
                    System.err.println("BINGO!!");
                }
            }
            line = br.readLine();
        }
        br.close();
    }
}
