package com.code2api.api;
public class Code2API12711779 {
    public static int extractSecondsFromTimeString(String timeStr) {
        return Integer.parseInt(timeStr.substring(6,7));
    }
}
