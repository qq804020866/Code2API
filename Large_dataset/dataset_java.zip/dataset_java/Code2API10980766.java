package com.code2api.api;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Code2API10980766 {
    public static List<String> findItemsByProperty(List<String> itemList) {
        List<String> numbersOnlyList = new ArrayList<>();
        for (String s : itemList) {
            try {
                Integer.valueOf(s);
                numbersOnlyList.add(s);
            } catch (NumberFormatException ignored) {
            }
        }
        return numbersOnlyList;
    }
}
