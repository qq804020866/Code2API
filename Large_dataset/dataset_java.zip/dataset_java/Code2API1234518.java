package com.code2api.api;
public class Code2API1234518 {
    public static String replaceCharacter(String input, String character, String replacement) {
        return input.replace(character, replacement);
    }
}
