package com.code2api.api;
public class Code2API10147698 {
    public static String[] splitStringWithoutSpacesOrEmptyValues(String input) {
        String[] emailList = input.replace(" ", "").split("[;,]+");
        return emailList;
    }
}
