package com.code2api.api;
import java.util.StringTokenizer;

public class Code2API1022309 {
    public static StringTokenizer splitPolynomial(String polynomial, String delimiters) {
        return new StringTokenizer(polynomial, delimiters, true);
    }
}
