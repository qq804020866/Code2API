package com.code2api.api;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class Code2API12888885 {
    public static Date getCurrentTimeInTimeZone(TimeZone timeZone) {
        return new GregorianCalendar(timeZone).getTime();
    }
}
