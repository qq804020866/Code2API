package com.code2api.api;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Code2API10231014 {
    public static List<String> convertStringArrayToList(String[] filesOrig) {
        List<String> myList = new ArrayList<>();
        Collections.addAll(myList, filesOrig);
        return myList;
    }
}
