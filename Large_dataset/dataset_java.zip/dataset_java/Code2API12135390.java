package com.code2api.api;
public class Code2API12135390 {
    public static String replaceCharsByPosition(String input, char replacement) {
        int counter = 0;
        char[] inputArray = input.toCharArray();
        for(char ch : inputArray) {
            if(ch == 'o') {
                inputArray[counter] = replacement;
            }
            counter += 1;
        }
        String output = new String(inputArray);
        return output;
    }
}
