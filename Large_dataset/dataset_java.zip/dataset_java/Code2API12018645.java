package com.code2api.api;
import javax.swing.JProgressBar;

public class Code2API12018645 {
    public static void showUserStorageStatus(int totalAvailableStorage, int occupiedStorage) {
        JProgressBar progress = new JProgressBar(0, totalAvailableStorage);
        progress.setValue(occupiedStorage);
        
        // Add progress bar to its container and call progress.setValue() whenever needed
    }
}
