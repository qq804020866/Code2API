package com.code2api.api;
import java.util.regex.Pattern;

public class Code2API10601768 {
    public static String replaceEncodedString(String subjectString) {
        return subjectString.replaceAll(
            "(?x)(       # Match and capture in backreference number 1:\n" +
            " [^\\s:]+   #  one or more characters except spaces or colons\n" +
            ")           # End of capturing group 1\n" +
            ":           # Match a colon\n" +
            "(           # Match and capture in backreference number 2:\n" +
            " [^\\s:]+   #  one or more characters except spaces or colons\n" +
            ")           # End of capturing group 2", 
            "\"$1\" = '$2'");
    }
}
