package com.code2api.api;
public class Code2API10374564 {
    public static void printStringsSideBySide(String field1, String field2, String field3) {
        System.out.printf("%-20s%-s20s%-20s%n", field1, field2, field3);
    }
}
