package com.code2api.api;
import java.util.Formatter;

public class Code2API12581447 {
    public static String formatString(String format, Object... args) {
        return String.format(format, args);
    }
}
