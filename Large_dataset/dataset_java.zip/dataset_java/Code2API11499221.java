package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API11499221 {
    public static void findPartialMatching(String search, String text) {
        Matcher m = Pattern.compile("(?<=^|\\s)\\Q" + search + "\\E(?=\\s|$)").matcher(text);
        while (m.find()) {
            System.out.println("Found match! :'" + m.group() + "'");
        }
    }
}
