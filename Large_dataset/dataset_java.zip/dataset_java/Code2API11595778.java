package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API11595778 {
    public static void getStringsFromData(String data) {
        Pattern p = Pattern.compile("s:64:\"([^\"]*)\".*s:64:\"([^\"]*)\"");
        Matcher m = p.matcher(data);
        if (m.find()) {
            System.out.println("First string: '" + m.group(1) + "'");
            System.out.println("Second string: '" + m.group(2) + "'");
        }
    }
}
