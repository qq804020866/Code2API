package com.code2api.api;
public class Code2API12833868 {
    public static String putValuesInNewLine(String originalString) {
        return originalString.replaceAll(" ", " \n");
    }
}
