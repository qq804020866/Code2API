package com.code2api.api;
public class Code2API13141115 {
    public static long getCurrentTime() {
        return System.currentTimeMillis();
    }
}
