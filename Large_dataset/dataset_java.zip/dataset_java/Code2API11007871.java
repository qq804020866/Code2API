package com.code2api.api;
import java.util.HashMap;

public class Code2API11007871 {
    public static void dumpHashMapContents(HashMap<Object, Object> hashMap) {
        System.out.println("HASH MAP DUMP: " + hashMap.toString());
    }
}
