package com.code2api.api;
import java.util.Collections;
import java.util.LinkedList;

public class Code2API10953500 {
    public static void toastNumbers() {
        LinkedList<Integer> ar = new LinkedList<Integer>();
        int[] number = { 0, 1, 2, 3, 4, 5 };
        for (int i : number) 
            ar.add(i);
        Collections.shuffle(ar);

        //every time you click:
        if (ar.isEmpty()) { 
            //toast finished
        } else {
            Integer pop = ar.pop();
            //toast pop
        }
    }
}
