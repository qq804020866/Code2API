package com.code2api.api;
public class Code2API12200527 {
    public static void separateAndAdd(String notseparated) {
        String[] parts = notseparated.split(" ");
        for (int i = 0; i < parts.length; i++) {
            if (!"".equals(parts[i])) {
                thearray.add(parts[i]);
            }
        }
    }
}
