package com.code2api.api;
import java.lang.System;

public class Code2API11101130 {
    public static void setSystemVariables(String propertyName, String propertyValue) {
        System.setProperty(propertyName, propertyValue);
    }
}
