package com.code2api.api;
public class Code2API10296933 {
    public static float calculateVelocity(int s, int t) {
        return 1d * s / t;
    }
}
