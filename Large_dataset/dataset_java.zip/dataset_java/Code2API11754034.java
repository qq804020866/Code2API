package com.code2api.api;
public class Code2API11754034 {
    public static String getSubstringWithOneBasedIndexes(String source, int start, int end) {
        String result = source.substring(start - 1, end - 1);
        return result;
    }
}
