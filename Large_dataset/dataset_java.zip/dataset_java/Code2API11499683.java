package com.code2api.api;
public class Code2API11499683 {
    public static String removeWordAfterSlash(String text) {
        return text.replaceAll("/\\S*", "");
    }
}
