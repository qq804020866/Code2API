package com.code2api.api;
public class Code2API10200845 {
    public static void storeTrillion() {
        long temp = 1;
        if (...) {
            temp = 1000000000000L;
        }
        return;
    }
}
