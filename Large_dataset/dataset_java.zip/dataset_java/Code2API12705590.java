package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API12705590 {
    public static void searchStringPattern(String paragraph, String pattern) {
        Pattern p = Pattern.compile(pattern);
        Matcher matcher = p.matcher(paragraph);
        while (matcher.find()) {
            System.out.println(matcher.group());
        }
    }
}
