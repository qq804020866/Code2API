package com.code2api.api;
public class Code2API10565377 {
    public static String[] getNumbersArray(String input) {
        return input.split("\\s*,\\s*");
    }
}
