package com.code2api.api;
import java.lang.StringBuilder;

public class Code2API13025923 {
    public static void reverseNumber(int number) {
        System.out.println(new StringBuilder(String.valueOf(number)).reverse());
    }
}
