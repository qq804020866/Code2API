package com.code2api.api;
import java.util.ArrayList;
import java.util.List;

public class Code2API12242035 {
    public static List<byte[][]> convertCharacterToBooleanArray(String str) {
        List<byte[][]> codedString = new ArrayList<byte[][]>();

        for ( char c : str.toCharArray() ) {

            switch ( c ) {

                case 'A':
                    codedString.add( new byte[][]{
                        { 0, 0, 1, 0, 0 },
                        { 0, 1, 0, 1, 0 },
                        { 0, 1, 0, 1, 0 },
                        { 1, 0, 0, 0, 1 },
                        { 1, 1, 1, 1, 1 },
                        { 1, 0, 0, 0, 1 },
                        { 0, 0, 0, 0, 0 } } );
                    break;

                case 'B':
                    codedString.add( new byte[][]{
                        { 1, 1, 1, 1, 0 },
                        { 1, 0, 0, 0, 1 },
                        { 1, 0, 0, 0, 1 },
                        { 1, 1, 1, 1, 0 },
                        { 1, 0, 0, 0, 1 },
                        { 1, 0, 0, 0, 1 },
                        { 1, 1, 1, 1, 0 } } );
                    break;

                case 'C':
                    codedString.add( new byte[][]{
                        { 0, 1, 1, 1, 0 },
                        { 1, 0, 0, 0, 1 },
                        { 1, 0, 0, 0, 0 },
                        { 1, 0, 0, 0, 0 },
                        { 1, 0, 0, 0, 0 },
                        { 1, 0, 0, 0, 1 },
                        { 0, 1, 1, 1, 0 } } );
                    break;

            }

        }
        
        return codedString;
    }
}
