package com.code2api.api;
public class Code2API13150139 {
    public static void printDigitsBackwards(int number) {
        while (number != 0) {
            int lastDigit = number % 10;
            number /= 10;
            System.out.println(lastDigit);
        }
    }
}
