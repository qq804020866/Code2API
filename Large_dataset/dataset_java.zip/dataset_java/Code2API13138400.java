package com.code2api.api;
public class Code2API13138400 {
    public static String splitString(String str) {
        str = str.substring(0, 4) + "-" + str.substring(4);
        return str;
    }
}
