package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Code2API10065174 {
    public static void disregardNumbers(String filename) throws IOException {
        if (filename == null)
            throw new IllegalArgumentException("Null filename");
        else {
            try {
                BufferedReader in = new BufferedReader(new FileReader(filename));
                String str;
                int numLines = 0;
                while ((str = in.readLine()) != null) {
                    numLines++;
                }
                String[] words = new String[numLines];
                for (int i = 0; i < words.length; i++) {
                    words[i] = in.readLine();
                }

                in.close();
            } catch (IOException e) {
            }
        }
    }
    
    public static void main(String[] args) {
        Pattern p = Pattern.compile("[^0-9\\s]+");
        String s = "1 apple 2 oranges";

        Matcher m = p.matcher(s);

        while (m.find()) {
            System.out.println(m.group(0));
        }
    }
}
