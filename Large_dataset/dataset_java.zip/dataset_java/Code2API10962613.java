package com.code2api.api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class Code2API10962613 {
    public static void stopThread(Thread thread) {
        if (thread != null) {
            thread.interrupt();
        }
    }
}
