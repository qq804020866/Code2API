package com.code2api.api;
import java.io.IOException;

public class Code2API12803843 {
    public static void replaceSlashWithUnderscore(String file) throws IOException {
        file = file.replaceAll("/", "_");
        System.out.println(file);
    }
}
