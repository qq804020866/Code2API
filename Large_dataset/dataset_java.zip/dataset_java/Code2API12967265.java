package com.code2api.api;
import java.math.BigInteger;

public class Code2API12967265 {
    public static BigInteger convertStringToLong(String longString) {
        return new BigInteger(longString);
    }
}
