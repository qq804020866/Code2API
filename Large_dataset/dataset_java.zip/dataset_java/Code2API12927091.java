package com.code2api.api;
public class Code2API12927091 {
    public static char getAlphabetFromNumber(int number) {
        return (char)(number+64);
    }
}
