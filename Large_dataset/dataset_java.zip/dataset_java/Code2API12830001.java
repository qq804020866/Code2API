package com.code2api.api;
public class Code2API12830001 {
    public static void throwExceptionForDivisionByZero(double rise, double run) throws IllegalArgumentException {
        if (run == 0) {
            throw new IllegalArgumentException("Divide by zero error");
        }
    }
}
