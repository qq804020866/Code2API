package com.code2api.api;
import javax.swing.UIManager;

public class Code2API11977997 {
    public static void setButtonBackgroundColor() throws Exception {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
