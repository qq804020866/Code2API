package com.code2api.api;
public class Code2API10428900 {
    public static void refactorLogicCodes(List<String> deletedInfo, List<String> addedInfo) {
        if (deletedInfo.isEmpty()) {
            if (addedInfo.isEmpty()) {
                // some logic codes
            } else {
                // some logic codes
            }
        } else {
            if (addedInfo.isEmpty()) {
                // some logic codes
            } else {
                // some logic codes
            }
        }
    }
}
