package com.code2api.api;
public class Code2API1305110 {
    public static long convertIntToLong(Integer number) {
        return number.longValue();
    }
}
