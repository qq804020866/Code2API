package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API13245582 {
    public static int countCharacter(String input, char character) {
        Pattern pattern = Pattern.compile("[" + character + "]");
        Matcher matcher = pattern.matcher(input);
        int countCharacter = 0;
        while(matcher.find()) {
            countCharacter++;
        }
        return countCharacter;
    }
}
