package com.code2api.api;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class Code2API10768198 {
    public static List<List<String>> create2DStringArrayList() {
        List<List<String>> ls2d = new ArrayList<List<String>>();
        List<String> x = new ArrayList<String>();
        x.add("Hello");
        x.add("world!");
        ls2d.add(x);
        return ls2d;
    }
}
