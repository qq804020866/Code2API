package com.code2api.api;
public class Code2API13349823 {
    public static Object[][] initializeStaticArrayOfObjects() {
        return new Object[][] {{1, "first"}, {2, "second"}};
    }
}
