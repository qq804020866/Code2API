package com.code2api.api;
import java.io.PrintWriter;
import java.io.File;

public class Code2API11496730 {
    public static void createAndWriteToFile(File file, String content) {
        PrintWriter printWriter = new PrintWriter(file);
        printWriter.println(content);
        printWriter.close();
    }
}
