package com.code2api.api;
public class Code2API13009862 {
    public static void formatIntegerWithTwoDigits(int number) {
        System.out.println(String.format("%02d", number));
    }
}
