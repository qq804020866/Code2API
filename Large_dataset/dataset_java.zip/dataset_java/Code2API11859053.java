package com.code2api.api;
import java.math.BigDecimal;

public class Code2API11859053 {
    public static String truncateNumberBeforeDecimal(String number) {
        BigDecimal myNumber = new BigDecimal(number);
        BigDecimal truncatedNumber = myNumber.setScale(3, BigDecimal.ROUND_HALF_UP);
        return truncatedNumber.toString();
    }
}
