package com.code2api.api;
public class Code2API13009765 {
    public static void formatIntegerWithTwoDigits(int number) {
        System.out.format("%02d\n", number);
    }
}
