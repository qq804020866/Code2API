package com.code2api.api;
import java.util.Calendar;

public class Code2API12524757 {
    public static long getIntervalBetweenTimes() {
        Calendar current = Calendar.getInstance();
        Calendar usertime = Calendar.getInstance();
        usertime.set(Calendar.HOUR_OF_DAY, 20);
        usertime.set(Calendar.MINUTE, 12);

        long diffInMilisecond = Math.abs(usertime.getTimeInMillis()-current.getTimeInMillis());
        return diffInMilisecond;
    }
}
