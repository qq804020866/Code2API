package com.code2api.api;
import java.util.ArrayList;
import java.util.Collections;

public class Code2API10251692 {
    public static ArrayList<String> cloneArrayList(ArrayList<String> original) {
        ArrayList<String> copy = new ArrayList<>(original.size());
        Collections.copy(copy, original);
        return copy;
    }
}
