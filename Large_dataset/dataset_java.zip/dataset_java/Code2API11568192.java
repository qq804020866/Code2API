package com.code2api.api;
public class Code2API11568192 {
    public static String parseSpecialChars(String input) {
        String s = input.replace( (char)145, (char)'\'');
        s = s.replace( (char)8216, (char)'\''); // left single quote
        s = s.replace( (char)146, (char)'\'');
        s = s.replace( (char)8217, (char)'\''); // right single quote
        s = s.replace( (char)147, (char)'\"');
        s = s.replace( (char)148, (char)'\"');
        s = s.replace( (char)8220, (char)'\"'); // left double
        s = s.replace( (char)8221, (char)'\"'); // right double
        s = s.replace( (char)8211, (char)'-' ); // em dash??    
        s = s.replace( (char)150, (char)'-' );
        return s;
    }
}
