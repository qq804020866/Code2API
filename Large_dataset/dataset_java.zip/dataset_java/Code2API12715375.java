package com.code2api.api;
public class Code2API12715375 {
    public static void checkCharacterType(String character) {
        char charInt = character.charAt(0);
        if (charInt >= 48 && charInt <= 57) {
            System.out.println("not character");
        } else {
            System.out.println("Character");
        }
    }
}
