package com.code2api.api;
public class Code2API12925894 {
    public static String getEndOfString(String inputString, String splitString) {
        int index = inputString.lastIndexOf(splitString);
        String result= null;
        if(index > -1){
            result = inputString.substring(index+splitString.length());
        }
        return result;
    }
}
