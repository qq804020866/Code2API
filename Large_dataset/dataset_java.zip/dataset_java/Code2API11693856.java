package com.code2api.api;
public class Code2API11693856 {
    public static String escapeSingleQuote(String term) {
        return term.replaceAll("'", "''");
    }
}
