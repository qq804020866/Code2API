package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API11225576 {
    public static String getImagePaths(String image) {
        String image2 = image;
        final boolean hasUndersore = image2.indexOf("_") > 0;
        if (hasUndersore) {
            image2 = image2.replaceAll("_highlight(\\.[^\\.]+)$", "_selected$1");
        } else {
            final String[] words = image2.split("\\.");
            image2 = words[0].concat("_selected.") + words[1];
        }
        return image2;
    }
}
