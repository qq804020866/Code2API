package com.code2api.api;
import android.widget.ArrayAdapter;

public class Code2API11168213 {
    public static String replaceSpecialCharacter(String str) {
        return str.replace("&quot;", " ");
    }
}
