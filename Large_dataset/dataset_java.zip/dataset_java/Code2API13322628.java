package com.code2api.api;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Code2API13322628 {
    public static void insertTimestampIntoMsAccess(String saleDetails, String saleTotal, Timestamp saleTimestamp) 
                        throws ClassNotFoundException, SQLException {

        Statement myStatement = getConnection();
        String sql = "INSERT INTO Sale (SaleDetails, SaleTotal, SaleTimestamp)"
                + " VALUES ('"+saleDetails+"','"+saleTotal+"','"+saleTimestamp+"')";

        myStatement.executeUpdate(sql);
        closeConnection();
    }
}
