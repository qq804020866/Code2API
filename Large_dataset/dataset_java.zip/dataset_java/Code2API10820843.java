package com.code2api.api;
public class Code2API10820843 {
    public static void getArrayTreatment() {
        int[] hello = new int[5]; // reference hello is on stack, the object is on the heap.
        hello[0] = 2; // Java puts this value directly in same slot and doesn't 
                      // create a wrapping object.
    }
}
