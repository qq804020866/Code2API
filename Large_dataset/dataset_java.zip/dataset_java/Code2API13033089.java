package com.code2api.api;
public class Code2API13033089 {
    public static String chooseOverloadedMethod() {
        return "The String overload here is chosen because the Java compiler picks the most specific overload, as per section 15.12.2.5 of the JLS. In particular:\n\nThe informal intuition is that one method is more specific than another if any invocation handled by the first method could be passed on to the other one without a compile-time type error.\n\nIn your second case, both methods are still applicable, but neither String nor StringBuffer is more specific than the other, therefore neither method is more specific than the other, hence the compiler error.";
    }
}
