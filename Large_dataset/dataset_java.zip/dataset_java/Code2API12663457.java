package com.code2api.api;
public class Code2API12663457 {
    public static String deletePunctuation(String input) {
        input = input.replaceAll("[\\p{Punct}]+", "");
        return input;
    }
}
