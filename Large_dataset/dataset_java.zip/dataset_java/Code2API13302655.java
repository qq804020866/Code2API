package com.code2api.api;
public class Code2API13302655 {
    public static void printFormattedString(int spaceCount) {
        String formattedString = String.format("%" + spaceCount + "s", " ");
        System.out.println(formattedString);
    }
}
