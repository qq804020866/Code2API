package com.code2api.api;
import java.util.TimeZone;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Code2API12889140 {
    public static Date getTimeFromTimeZone() {
        TimeZone defaultTimezone = TimeZone.getDefault();
        Calendar calendar = new GregorianCalendar(defaultTimezone);
        return calendar.getTime();
    }
}
