package com.code2api.api;
public class Code2API13386131 {
    public static String removeCharacterAtIndex(String str, int index) {
        return str.substring(0, index) + str.substring(index + 1);
    }
}
