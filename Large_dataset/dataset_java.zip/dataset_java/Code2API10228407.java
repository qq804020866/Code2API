package com.code2api.api;
public class Code2API10228407 {
    public static String getFolderPath(String filePath) {
        int lastSlash = filePath.lastIndexOf("/");
        String result = filePath.substring(0, lastSlash);
        return result;
    }
}
