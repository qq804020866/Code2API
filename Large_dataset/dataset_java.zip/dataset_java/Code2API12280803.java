package com.code2api.api;
public class Code2API12280803 {
    public static String associateJsonToString() {
        return "{"
                + "    \"employees\": ["
                + "        {"
                + "            \"firstName\": \"Peter\","
                + "            \"lastName\": \"Jones\""
                + "        }"
                + "    ]}";
    }
}
