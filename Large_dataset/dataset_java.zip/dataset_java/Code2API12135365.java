package com.code2api.api;
import java.lang.String;

public class Code2API12135365 {
    public static String replaceCharsByPosition(String input, char targetChar, String replacement) {
        return input.replaceAll(String.valueOf(targetChar), replacement);
    }
}
