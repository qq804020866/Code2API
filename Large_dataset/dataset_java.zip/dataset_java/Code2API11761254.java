package com.code2api.api;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Code2API11761254 {
    public static void getDistinctRandomValues(int[] nums, int percentage) {
        Random random = new Random();

        int numsFound = 0;
        int targetCount = (int)(nums.length * (percentage / 100.0));
        List<Integer> usedIndices = new ArrayList<Integer>();
        while (numsFound < targetCount) {
            int index = random.nextInt(nums.length);

            if (!usedIndices.contains(index)) { // not already used?
                System.out.println(nums[index]);
                usedIndices.add(index);
                numsFound++;
            }
        }
    }
}
