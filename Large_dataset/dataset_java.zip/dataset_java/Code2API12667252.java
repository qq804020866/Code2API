package com.code2api.api;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Code2API12667252 {
    public static BufferedReader readFromFile() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        return br;
    }
}
