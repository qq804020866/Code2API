package com.code2api.api;
import java.io.StringBufferInputStream;
import java.io.InputStream;

public class Code2API13028681 {
    public static void setSystemInValue(String value) {
        System.setIn(new StringBufferInputStream(value));
    }
}
