package com.code2api.api;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API12459662 {
    public static String extractSubstring(String s, String r) {
        Pattern p = Pattern.compile(r);
        Matcher m = p.matcher(s);
        if (m.find()) {
            String extracted = m.group();
            return extracted;
        }
        return null;
    }
}
