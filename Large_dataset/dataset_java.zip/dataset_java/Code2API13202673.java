package com.code2api.api;
public class Code2API13202673 {
    public static int compareStrings(String str1, String str2) {
        return str1.compareTo(str2);
    }
}
