package com.code2api.api;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Code2API11429698 {
    public static void stopCallable(Future<Integer> future) {
        for(int i = 0; i < 1000; i++){
            // Uses isInterrupted() to keep interrupted status set
            if (Thread.currentThread().isInterrupted()) {
                // Cannot use InterruptedException since it's checked
                throw new RuntimeException(); 
            }
            System.out.println(i);
        }
    }
}
