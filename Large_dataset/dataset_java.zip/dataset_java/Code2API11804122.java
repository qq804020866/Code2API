package com.code2api.api;
public class Code2API11804122 {
    public static void getPropertiesFromJVM() {
        System.getProperty("cloud.db.username");
        System.getProperty("cloud.db.password");
    }
}
