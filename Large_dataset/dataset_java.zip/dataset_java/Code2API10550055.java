package com.code2api.api;
import java.net.MalformedURLException;

public class Code2API10550055 {
    public static void resolveMalformedURLException(String url) throws MalformedURLException {
        url = url.replaceAll(" ", "%20");
    }
}
