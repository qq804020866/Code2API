package com.code2api.api;
public class Code2API11440830 {
    public static String[] splitStringByDelimiter(String line, String delimiter) {
        return line.split(delimiter, -1);
    }
}
