package com.code2api.api;
public class Code2API11852120 {
    public static boolean isBooleanType(String value) {
        return value.equalsIgnoreCase("true") ? true : false;
    }
}
