package com.code2api.api;
import java.util.Scanner;

public class Code2API11385873 {
    public static int countWordsInSentence(String sentence) {
        int spaceCount = sentence.length() - sentence.replaceAll(" ", "").length();
        int vowelCount = sentence.length() - sentence.replaceAll("(?i)[aeiou]", "").length();
        int consonantCount = sentence.length() - sentence.replaceAll("(?i)(?=[a-z])[^aeiou]", "").length();
        int specialCount = sentence.length() - sentence.replaceAll("(?i)[^a-z ]", "").length();
        int wordCount = sentence.trim().split("\\s+").length;
        return wordCount;
    }
}
