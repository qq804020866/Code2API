package com.code2api.api;
public class Code2API12652361 {
    public static boolean findWordInString(String str1, String str2) {
        return str1.contains(str2);
    }
}
