package com.code2api.api;
import javax.swing.JMenuItem;
import javax.swing.SwingConstants;

public class Code2API13141260 {
    public static void changeMenuItemAlignment(JMenuItem item1, JMenuItem item2, JMenuItem item3) {
        item1.setHorizontalAlignment(SwingConstants.RIGHT);
        item3.setHorizontalAlignment(SwingConstants.CENTER);
    }
}
