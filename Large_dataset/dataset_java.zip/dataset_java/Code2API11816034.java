package com.code2api.api;
import acm.program.*;

public class Code2API11816034 {
    public static int calculateSumOfOddIntegers(int n) {
        int b=1, sum = 0;
        for (int i = 1; i <=n; i++){
            sum+=b;
            b+=2;
        }
        return sum;
    }
}
