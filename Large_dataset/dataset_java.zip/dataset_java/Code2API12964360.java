package com.code2api.api;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Code2API12964360 {
    public static void openFileWithoutSaving() throws IOException {
        String tempDir = System.getProperty("java.io.tmpdir") + "\\BONotifier\\";
        File parentFile = new File(tempDir);
        if (!parentFile.exists()) {
            parentFile.mkdirs();
        }
        File outputFile = new File(parentFile, "template.xml");
        InputStream inputStream = getClass().getResourceAsStream("/resources/template.xml");
        int size = 4096;
        try (OutputStream out = new FileOutputStream(outputFile)) {
            byte[] buffer = new byte[size];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
            inputStream.close();
        }
        java.awt.Desktop.getDesktop().open(outputFile);
    }
}
