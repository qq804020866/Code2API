package com.code2api.api;
public class Code2API10751663 {
    public static void insertValuesInTwoDimensionalArray(int intSize, String value) {
        String[][] shades = new String[intSize][intSize];
        for (int r=0; r<shades.length; r++) {
            for (int c=0; c<shades[r].length; c++) {
                shades[r][c] = value;
            }
        }
    }
}
