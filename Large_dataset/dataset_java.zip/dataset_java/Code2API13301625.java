package com.code2api.api;
import java.math.BigDecimal;

public class Code2API13301625 {
    public static BigDecimal roundBigNumber(String number) {
        return new BigDecimal(number);
    }
}
