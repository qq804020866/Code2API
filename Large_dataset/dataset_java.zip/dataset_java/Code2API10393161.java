package com.code2api.api;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Code2API10393161 {
    public static List<String> getSubstrings(String input) {
        Pattern p = Pattern.compile("#(\\w+)#");
        Matcher m = p.matcher(input);

        List<String> parts = new ArrayList<String>();
        while (m.find())
        {
            parts.add(m.group(1));
        }
        return parts;
    }
}
