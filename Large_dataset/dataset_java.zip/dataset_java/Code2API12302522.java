package com.code2api.api;
public class Code2API12302522 {
    public static String createNewLineBetweenDateFormat() {
        return "Thus ,Sep 6" + "\\n" + "4:25pm";
    }
}
