package com.code2api.api;
import javax.swing.BorderFactory;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;

public class Code2API11875085 {
    public static void setPanelTitle(JPanel panel, String title) {
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(BevelBorder.LOWERED), title));
    }
}
