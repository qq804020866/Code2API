package com.code2api.api;
import java.util.Random;
import java.util.Set;
import java.util.HashSet;

public class Code2API10217300 {
    public static Set<Double> generateUniqueRandomNumbers(int n) {
        Set<Double> numbers = new HashSet<Double>();
        Random generator = new Random();
        while (numbers.size() < n)
            numbers.add(generator.nextDouble());
        return numbers;
    }
}
