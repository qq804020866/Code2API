package com.code2api.api;
import java.util.Date;
import java.util.Random;

public class Code2API11016445 {
    public static Date generateRandomTimestamp() {
        Random r = new Random();
        long unixtime = (long) (1293861599 + r.nextDouble() * 60 * 60 * 24 * 365);
        return new Date(unixtime);
    }
}
