package com.code2api.api;
public class Code2API1234762 {
    public static String replaceCharacter(String text, char oldChar, String newString) {
        return text.replace(Character.toString(oldChar), newString);
    }
}
