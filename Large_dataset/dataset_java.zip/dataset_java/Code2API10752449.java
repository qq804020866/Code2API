package com.code2api.api;
import java.util.GregorianCalendar;

public class Code2API10752449 {
    public static long calculateUTCFromYearAndDayOfYear(int year, int dayOfYear) {
        GregorianCalendar gc=new GregorianCalendar();
        gc.set(GregorianCalendar.YEAR, year);
        gc.set(GregorianCalendar.DAY_OF_YEAR, dayOfYear);
        return gc.getTimeInMillis()/1000/60;
    }
}
