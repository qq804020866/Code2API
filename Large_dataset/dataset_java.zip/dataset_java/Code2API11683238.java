package com.code2api.api;
import java.text.DecimalFormat;

public class Code2API11683238 {
    public static String getDisplayString(double number) {
        return new DecimalFormat("#.##").format(number);
    }
}
